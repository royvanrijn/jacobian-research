from pathlib import Path
import sys,json
from sage.all import QQ,ZZ,PolynomialRing,EllipticCurve,gcd,prod
ROOT=Path(__file__).resolve().parents[4];sys.path.insert(0,str(ROOT/'elliptic-curves/cas'))
import certify_compact_r17_candidates as cert
import compact_mw16_specialization as spec
from research_runtime.store import checkpoint
out=Path(__file__).resolve().parent
bounds=cert.read(out/'result.json');atlas=cert.read(spec.ATLAS);R=PolynomialRing(QQ,'t');factors={}
for f in atlas['families']:
 A=R([QQ(q) for q in f['A_coefficients_low_to_high']]);B=R([QQ(q) for q in f['B_coefficients_low_to_high']]);D=-16*(4*A**3+27*B**2)
 fs=D.factor();assert fs.prod()==D
 factors[f['fibration_id']]=[(g,e) for g,e in fs if e>=2]
rows=[]
for row in bounds['rows']:
 if row['family'] not in factors:continue
 t=QQ(row['parameter']);remaining=ZZ(row['unprocessed_cofactor']);upper=ZZ(row['conductor_upper_bound']);c4=ZZ(EllipticCurve([QQ(q) for q in row['curve']]).c4().numerator());steps=[]
 for g,e in factors[row['family']]:
  val=abs(ZZ(g(t).numerator()));h=gcd(val,remaining);h=gcd(h,remaining//h)
  while gcd(h,c4)>1:h//=gcd(h,c4)
  if h>1:
   assert remaining%(h*h)==0 and gcd(h,c4)==1
   # All remaining primes exceed10000. Unit c4 implies multiplicative reduction,
   # hence f_p=1 and replacing a known square h^2 by h preserves an upper bound.
   remaining//=h;upper//=h
  steps.append({'factor':list(map(str,g.list())),'exponent':int(e),'value_numerator':str(val),'removed_square_root':str(h)})
 benchmark=ZZ(bounds['benchmarks'][str(row['rank_lower_bound'])]['conductor'])
 rows.append({'family':row['family'],'parameter':row['parameter'],'rank_lower_bound':row['rank_lower_bound'],'steps':steps,'refined_conductor_upper_bound':str(upper),'strictly_below_listed_benchmark':bool(upper<benchmark)})
 print('REFINED UPPER',row['family'],row['parameter'],'rank',row['rank_lower_bound'],'digits',len(str(upper)),'removed',[s['removed_square_root'] for s in steps],'beats benchmark',upper<benchmark,flush=True)
checkpoint(out/'repeated-factor-refinement.json',{'scope':'Only exact square divisors coprime to c4 and supported on unprocessed primes>10000 are removed. Multiplicative reduction gives conductor exponent1. These are upper bounds, not exact conductors.','source_sha256':cert.hashed(Path(__file__).resolve()),'rows':rows})
