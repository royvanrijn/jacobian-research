from pathlib import Path
import json,hashlib,zipfile,shutil
ROOT=Path(__file__).resolve().parents[4];ART=ROOT/'artifacts/generated-results/elliptic-curves'
manifest=ART/'prospective_mw16_followup_diagnostics_v1.json';archive=manifest.with_suffix('.zip')
if manifest.exists() or archive.exists():raise FileExistsError('preserve diagnostic bundle')
base=Path(__file__).resolve().parent;paths={Path(__file__).resolve(),base/'candidate-00/result.json'}
paths.update(p for p in base.glob('*') if p.is_file() and p.suffix in ('.json','.log'))
for name in ['prospective-mw16-initial-ambiguities-v1','rank25-discriminant-geometry-v1','new-curve-conductor-bounds-v1']:
 folder=ROOT/'artifacts/local/elliptic-curves'/name
 paths.update(p for p in folder.rglob('*') if p.is_file() and p.suffix in ('.json','.log','.sage','.py'))
protocol=json.loads((base/'protocol.json').read_text());paths.add(ROOT/protocol['input_path']);paths.update(ROOT/name for name in protocol['sources'])
paths.update(ART.glob('prospective_mw16_initial_ambiguities_*_v1.json'))
for name in ['replay_prospective_mw16_followup.py','audit_prospective_mw16_ambiguities.py','audit_rank25_discriminant_geometry.sage','audit_new_curve_conductor_bounds.sage']:
 paths.add(ROOT/'elliptic-curves/cas'/name)
for p in list(ART.glob('prospective_mw16_initial_ambiguities_*_v1.json')):
 paths.update(ROOT/name for name in json.loads(p.read_text())['sources'])
def hashed(p):
 h=hashlib.sha256()
 with p.open('rb') as stream:
  for chunk in iter(lambda:stream.read(1<<20),b''):h.update(chunk)
 return h.hexdigest()
rows=[]
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(paths):
  name=str(p.relative_to(ROOT));info=zipfile.ZipInfo(name,(2026,9,5,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16
  with p.open('rb') as source,z.open(info,'w') as sink:shutil.copyfileobj(source,sink,1<<20)
  rows.append({'path':name,'bytes':p.stat().st_size,'sha256':hashed(p)})
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for row in rows:
  h=hashlib.sha256()
  with z.open(row['path']) as stream:
   for chunk in iter(lambda:stream.read(1<<20),b''):h.update(chunk)
  assert h.hexdigest()==row['sha256']
manifest.write_text(json.dumps({'schema':'elliptic-curves.prospective-mw16-followup-diagnostics.v1','archive':str(archive.relative_to(ROOT)),'archive_sha256':hashed(archive),'archive_bytes':archive.stat().st_size,'files':rows,'retained_charts':301,'replay':'All301 adaptive charts passed exact replay, keeping rank lower bound25. The original1500-second worker stopped at281 charts; a separately declared300-second continuation completed the remaining20. Four initial mod3/mod5 ambiguity audits and their replays found no additional independent direction.','claim_boundary':'Bounded negative experiments, not rank upper bounds. Exact conductors remain unknown after bounded discriminant and local-conductor screens. No conductor record is established. The earlier281-chart full stopped snapshot remains in the ignored local previous/ directory; this portable archive retains the complete final301-chart transcript, stopped-worker logs and snapshot hash.'},indent=2)+'\n')
print('PACKAGED MW16 DIAGNOSTICS',len(rows),archive.stat().st_size,flush=True)
