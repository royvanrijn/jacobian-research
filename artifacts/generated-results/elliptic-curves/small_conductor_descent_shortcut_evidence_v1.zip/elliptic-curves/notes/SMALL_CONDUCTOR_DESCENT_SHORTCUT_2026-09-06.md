# MW16 at 3/17: targeted 2-descent preparation

Mathematical status is recorded in `MATH_STATUS.json` under
`EC-SMALL-CONDUCTOR-DESCENT-SHORTCUT-20260906`. The
[curve certificate](NEW_SMALL_CONDUCTOR_CURVE_2026-09-05.md) still proves
rank **at least 22**, with no rank upper bound. This study specializes a
known class-group criterion and tests better norm coordinates; it does not
complete a 2-descent or exhibit another point.

## What was already reached

The [relative class-group retry](R17_MW29_RELATIVE_SCLASS_RETRY_2026-09-04.md),
[BNF-free residual machinery](BNF_FREE_RESIDUAL_2SELMER.md), and
[small-field laboratory](R17_SMALL_FIELD_CLASS_QUOTIENT_LAB.md) already
identify the difficulty: certified global generation and productive principal
relations. Factor hints, maximal-order caches, mod-2 linear algebra and
relative/local descent are existing machinery. Recommending those again
would not resolve the obstruction. The earlier 180-second `ellrankinit`
attempt on this particular curve also returned no upper bound.

The new diagnostic isolates setup from relation collection. All arms use
one worker, a 1.5 GiB RSS limit and a 512 MB PARI stack. The field arm has a
30-second cap; the three class-group arms have 30, 30 and 60 seconds.
PARI 2.17.3, scripts, logs, supervisor records and hashes are retained under
`artifacts/local/elliptic-curves/small-conductor-descent-profile-v1/`.

| Arm | Observed field setup | Terminal result |
| --- | ---: | --- |
| Factored discriminant, maximal order only | 1 ms; certification 1 ms | Complete; 0.081 seconds including process overhead |
| Cold `ellrankinit` | 6,543 ms | 30-second timeout |
| Factor-hinted `ellrankinit` | 4 ms | 30-second timeout |
| Cached maximal order, `bnfinit` flag 0 | 0 ms | 60-second timeout |

Termination grace accounts for about one extra second in timeout wall times.
The three class arms each use 3,878 factor-base ideals and remain in relation
collection. No BNF certificate is reached. The old profile's `gp_error` boolean
matches normal debug text containing `***`; timeout outcomes and retained logs,
not that boolean, determine the interpretation.

## Exact stopping target

Write `g = dim_F2 Cl(K)[2]`, where the cubic 2-division field is

```text
K = Q[z] / (z^3 + z^2 - 2919231625641258502793755607986240*z
             + 45440201616242830029801770634418828098464819545088).
```

Its maximal-order discriminant is

```text
128900477062442043600727490102612931938219670661531295245188752203875468
```

The Brumer–Kramer bound, in the notation of
[Klagsbrun–Sherman–Weigandt, Proposition 3.1](https://arxiv.org/html/1606.07178#S3.SS1),
specializes to

```text
22 <= rank E(Q) <= dim_F2 Sel_2(E/Q) <= g + 7.
```

Here `u=2`. The multiplicative primes with even minimal discriminant valuation
are `2,5,13,19,71`, contributing five. The sole additive prime is 17 and has
one prime above it in K, contributing zero. An exact Newton polygon of
`F(z+11)` has vertex endpoints `(0,2),(3,0)` and coefficient valuations
`[2,2,1,0]` at 17. Its slope proves irreducibility and total ramification of
the cubic over Q_17, independently of the number-field calculation.

The global root number is +1 and rational 2-torsion is trivial. The proved
2-parity theorem makes the **2-Selmer dimension even**; see
[Dokchitser–Dokchitser, Theorem 1.4](https://annals.math.princeton.edu/2010/172-1/p11)
and its explicit finite-Selmer formulation in
[Klagsbrun–Sherman–Weigandt, Appendix A](https://arxiv.org/html/1606.07178#A1).
This is not an assertion of unconditional algebraic rank parity.

Consequently `g >= 15` unconditionally, and **any certified `g <= 16` implies
exact rank 22**: the Selmer bound is at most 23, hence at most 22 by parity.
Conversely rank at least 23 would force Selmer dimension at least 24 and
therefore `g >= 17`. A future GRH-dependent class-group upper bound would
yield a GRH-dependent rank statement. No such upper bound currently exists.

## Productive norm coordinates

Constructing a binary cubic from the maximal-order multiplication table and
reducing its positive Hessian gives

```text
F_red(m,n) = -582653777472000*m^3
            -69418898236910689*m^2*n
            +2253317262489553494*m*n^2
            +28630981474137424362*n^3.
```

The maximum coefficient size falls from 165 to 65 bits. This uses a
nonmonic binary form: `polredabs` on the original monic polynomial merely
changes the generator's sign. Binary-cubic reduction is an established
number-field sieve technique, also used in the cited high-rank computations;
the new result here is its exact implementation and measured yield on this
specific field.

The certificate retains the integral basis, multiplication table, determinant-one
coordinate matrix M, and element w. With `a=-582653777472000`, set

```text
(u,v) = M * (m,n)
beta = a*u + v*w
Norm(beta) = a^2 * F_red(m,n).
```

The fixed square factor **a² is included** in every ideal relation. Discriminant
identities alone do not certify maximality: a separate `nfcertify` replay
does that. The pure rational checker verifies the complete polynomial norm
identity and the exact coordinate transport.

Before execution, the pilot fixes all 5,039 coprime pairs with
`-64 <= m <= 64`, `1 <= n <= 64`, and smoothness bound 400,000. Repeated gcd
with the exact primorial removes supported factors; unresolved remainders
are saved without expensive factorization. Each arm is capped at 120 seconds
with one worker and 1.5 GiB; checkpoints occur every eight m values.

| Norm polynomial | Completely smooth values | Observed arithmetic time |
| --- | ---: | ---: |
| Original monic cubic | 0 / 5,039 | 4.504 seconds |
| Reduced maximal-order binary cubic | 18 / 5,039 | 2.378 seconds |

These are different, explicitly specified sets of principal elements, so the
comparison measures this finite choice of coordinates, not a universal speedup.
An exact ideal-factorization audit verifies all 18 principal relations,
including the fixed norm factor. On the displayed finite ideal columns their
parity rows add **18 independent rows modulo the canonical rational-prime
relations**. This means additional relations, not independent class-group
elements. The columns are not proved to generate the class group modulo squares.

## Remaining gate and reuse

Preparation and a productive small pilot now take seconds. Full 2-descent
runtime is still unmeasured. Before a larger run, choose and justify a generating
factor base for `Cl(K)/2`, then feed these exact norm relations into the existing
mod-2 engine. With generation established, enough relations to leave matrix
nullity at most 16 suffice; a complete class-group structure is unnecessary.
If the residual bound is larger, more relations or tighter local Selmer
conditions may still be needed. A larger bound does not prove another point.

An unconditional generating-set certificate remains the principal proof gate.
A GRH-based bound must be explicitly labelled as conditional throughout.
The sieve bound 400,000 in this pilot is only a finite smoothness cutoff, not
a proved generation certificate. No larger sieve or sweep of previous curves
was launched. Reuse should proceed only after a further bounded batch shows
sustained independent relation yield on a justified factor base; each new
field also needs its own arithmetic and local correction terms.

## Replay

The aggregate checker replays the original rank/conductor proof, theorem
specialization, root numbers, integral norm identity, every pilot value, and
all principal-ideal identities and parity ranks. It checks historical profile
hashes rather than rerunning the timed-out class jobs.

```bash
sage -python elliptic-curves/cas/check_small_conductor_descent_shortcut.sage --check
```

Inputs and outputs are retained in the
[aggregate certificate](../../artifacts/generated-results/elliptic-curves/small_conductor_descent_shortcut_v1.json)
and its source bindings. The
[evidence archive](../../artifacts/generated-results/elliptic-curves/small_conductor_descent_shortcut_evidence_v1.zip)
contains the replay inputs; the
[isolated replay report](../../artifacts/generated-results/elliptic-curves/small_conductor_descent_shortcut_portable_replay_v1.json)
records verification from a fresh extracted directory. Replay requires Sage
with PARI 2.17.3 and the pinned `/usr/bin/gp` used for root numbers.
