# The Generalized Vanishing Conjecture: The Two-Variable Theorem and the First Failing Dimension

Build from the extracted archive:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error -jobname=generalized-vanishing-two-variables main.tex
```

The sources require the standard TeX Live packages used by pdfLaTeX, BibTeX and latexmk. The article states its mathematical and formalization scope; finite computational replay, where supplied, is separate from the all-order proof. Review and publication records are maintained with the repository edition rather than duplicated inside this source archive.
