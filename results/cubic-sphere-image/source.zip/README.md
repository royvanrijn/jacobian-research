# Cubic sphere moments and the two-pair Image problem

Standalone source bundle by Roy van Rijn.

Build with a standard TeX Live installation:

    latexmk -pdf -interaction=nonstopmode -halt-on-error -jobname=cubic-sphere-image main.tex

Exact arithmetic replay with Python 3.12:

    python -m pip install -r requirements.txt
    python verify.py

Every essential new argument and finite algebraic input is in the article.
The verifier supplies exact algebra and local coordinate checks, not a
formalization of the geometric proof. External human review and independent
external replay have not occurred. The larger research workspace and
polynomial certificate files are not required to compile or run this bundle.
