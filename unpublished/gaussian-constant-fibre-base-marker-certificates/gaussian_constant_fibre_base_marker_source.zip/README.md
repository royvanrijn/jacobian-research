# Constant Quadratic Fibres: Base-Marker Operator Certificates

**Unpublished · partial draft.**

For $P=aY^2+B(U)Y+g(U)$ with constant $a$, every original polynomial marker reduces to finitely many markers in the base variables, using time derivatives and polynomial time coefficients. The theorem holds over a field; over a general Q-algebra it retains the explicit coefficient-content condition. It gives a marker reduction and a sufficient degree transfer, while purity-to-safety over two base variables remains open.

[PDF](gaussian_constant_fibre_base_marker_certificates.pdf) · [LaTeX](main.tex) · [Metadata](metadata.json) · [Verification](verification.json) · [Source bundle](gaussian_constant_fibre_base_marker_source.zip)

This all-degree structural reduction complements the unrestricted low-degree results in the [dimension-degree boundary paper](../gaussian-boundary/). The [one-base Jordan-cancellation paper](../gaussian-quadratic-fibre-jordan-cancellation/) settles the corresponding one-base family. The [ring-defect note](../gaussian-marker-generation-ring-defect/) explains why field specializations cannot remove the coefficient condition.

Build from this directory with:

```sh
latexmk -pdf -jobname=gaussian_constant_fibre_base_marker_certificates -interaction=nonstopmode -halt-on-error main.tex
```

This writes `gaussian_constant_fibre_base_marker_certificates.pdf`. Only `main.tex` is required to compile; use a TeX installation with `latexmk`, `pdflatex`, and the packages listed in its preamble. The verification record identifies the current source and PDF and describes the checks performed. Earlier audit receipts in a source bundle, where present, retain their original scope and were not replayed during this revision.

Independent mathematical review and formal verification remain pending. Next: Review the universal operator identities and sufficient degree bound. Determine whether the two-base purity-to-safety question can be settled; base-marker generation alone does not settle it.
