# All-Degree Gaussian Quadratic Fibres: Jordan Cancellation and Unit Rigidity

**Unpublished · partial draft.**

For $P(u,Y)=Y^TAY+B(u)^TY+g(u)$ with one ordinary Gaussian base variable and constant symmetric $A$, the manuscript proves equivalence of pure-moment vanishing, polynomiality of every marked period, and finite rational identities. It treats arbitrary Jordan blocks, supplies a sufficient mixed-moment bound, and includes the formal stationary proof used in the reduction. Two base variables with one quadratic fibre remain outside its conclusion.

[PDF](gaussian_quadratic_fibre_jordan_cancellation.pdf) · [LaTeX](main.tex) · [Metadata](metadata.json) · [Verification](verification.json) · [Source bundle](gaussian_quadratic_fibre_jordan_source.zip)

This theorem allows arbitrary degrees within a structured family; the [dimension-degree boundary paper](../gaussian-boundary/) studies all phases within specified dimension and degree bounds. The [base-marker paper](../gaussian-constant-fibre-base-marker-certificates/) gives the remaining two-base/one-fibre family a marker reduction, without settling purity-to-safety.

Build from this directory with:

```sh
latexmk -pdf -jobname=gaussian_quadratic_fibre_jordan_cancellation -interaction=nonstopmode -halt-on-error main.tex
```

This writes `gaussian_quadratic_fibre_jordan_cancellation.pdf`. Only `main.tex` is required to compile; use a TeX installation with `latexmk`, `pdflatex`, and the packages listed in its preamble. The verification record identifies the current source and PDF and describes the checks performed. Earlier audit receipts in a source bundle, where present, retain their original scope and were not replayed during this revision.

Independent mathematical review and formal verification remain pending. Next: Review the full formal stationary theorem and its application to a polynomial unit period. Review the Jordan-block rigidity, polynomial precision matrix, and sufficient mixed-moment bound.
