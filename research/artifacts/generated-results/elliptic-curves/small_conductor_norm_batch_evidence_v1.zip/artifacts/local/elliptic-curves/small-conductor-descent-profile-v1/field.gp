default(realprecision,80);setrand(1);f=x^3+x^2+(-2919231625641258502793755607986240)*x+(45440201616242830029801770634418828098464819545088);E=ellinit([1,0,0,-182451976602578656424609725499140,710003150253794219215652666162794189038512805392]);P=[2,3,5,13,17,19,29,71,2465779087453622652131442949,519784438179112504122441050306814600881];

addprimes(P);gettime();print("STAGE|nfinit_start");
nf=nfinit([f,P]);print("MS|nfinit|",gettime());
print("FIELD_DISCRIMINANT|",nf.disc);print("FIELD_SIGNATURE|",nf.sign);
print("FIELD_INDEX|",nf.index);print("FIELD_BASIS|",nf.zk);
print("CERTIFY_ORDER|",nfcertify(nf));print("MS|order_certify|",gettime());
writebin("/home/royvanrijn/src/jacobian-research/artifacts/local/elliptic-curves/small-conductor-descent-profile-v1/nf.bin",nf);
R=polredabs(nf,1);print("REDUCED|",R);print("MS|polredabs|",gettime());
write("/home/royvanrijn/src/jacobian-research/artifacts/local/elliptic-curves/small-conductor-descent-profile-v1/reduced.gp",R);
for(i=1,#P,Q=idealprimedec(nf,P[i]);print("SPLIT|",P[i],"|",vector(#Q,j,[Q[j].e,Q[j].f])));
print("DONE|field");quit
