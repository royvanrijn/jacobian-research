default(realprecision,80);setrand(1);f=x^3+x^2+(-2919231625641258502793755607986240)*x+(45440201616242830029801770634418828098464819545088);E=ellinit([1,0,0,-182451976602578656424609725499140,710003150253794219215652666162794189038512805392]);P=[2,3,5,13,17,19,29,71,2465779087453622652131442949,519784438179112504122441050306814600881];

addprimes(P);nf=read("/home/royvanrijn/src/jacobian-research/artifacts/local/elliptic-curves/small-conductor-descent-profile-v1/nf.bin");setdebug("bnf",3);
gettime();print("STAGE|bnfinit_start");b=bnfinit(nf,0);
print("MS|bnfinit|",gettime());print("COMPUTED_CYCLIC_FACTORS|",b.cyc);
writebin("/home/royvanrijn/src/jacobian-research/artifacts/local/elliptic-curves/small-conductor-descent-profile-v1/uncertified_bnf.bin",b);
print("STAGE|bnfcertify_quotient_start");C=bnfcertify(b,1);
print("CLASS_QUOTIENT_CERTIFIED|",C);print("MS|bnfcertify_quotient|",gettime());
print("DONE|prepared_bnf");quit
