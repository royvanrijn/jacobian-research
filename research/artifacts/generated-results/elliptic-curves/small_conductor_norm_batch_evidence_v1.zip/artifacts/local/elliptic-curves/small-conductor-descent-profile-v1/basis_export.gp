n=read("/home/royvanrijn/src/jacobian-research/artifacts/local/elliptic-curves/small-conductor-descent-profile-v1/nf.bin");print(vector(3,i,vector(3,j,Str(polcoef(n.zk[i],j-1)))));quit
