from sage.all import QQ,ZZ,PolynomialRing,gcd,lcm,prime_range
from pathlib import Path
import json,hashlib
ROOT=Path.cwd();directory=Path(__file__).resolve().parent
source=ROOT/'artifacts/local/elliptic-curves/r17-prime-local-base-v1/103b2.json'
data=json.loads(source.read_text());R=PolynomialRing(QQ,'t')
polys=[]
for key in ['A_coefficients_low_to_high','B_coefficients_low_to_high']:
 f=R(list(map(QQ,data[key])));den=lcm(q.denominator() for q in f);f=R(f*den);f=f/gcd(ZZ(q) for q in f);polys.append(f)
A,B=polys
numbers=[ZZ(A.discriminant()),ZZ(B.discriminant()),ZZ(A.resultant(B))]
common=abs(gcd(numbers));remainder=common;small=[]
for p in prime_range(10000):
 e=remainder.valuation(p)
 if e:small.append([int(p),int(e)]);remainder//=p**e
powers=[]
for k in range(2,133):
 root,exact=remainder.nth_root(k,truncate_mode=True)
 if exact:powers.append([k,str(root)])
out={'family':'103b2','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'scope':'One family, exact primitive A/B discriminants and resultant, gcd, trial division by primes below 10000, perfect powers through exponent 132. No unbounded factorization.',
 'invariant_bits':[int(abs(x).nbits()) for x in numbers],'common_gcd':str(common),
 'small_prime_factors':small,'remaining_cofactor':str(remainder),'remaining_bits':int(remainder.nbits()),'exact_power_representations':powers}
(directory/'result.json').write_text(json.dumps(out,indent=2)+'\n')
print('INVARIANT BITS',out['invariant_bits'],'SMALL',small,'REMAINING BITS',out['remaining_bits'],'POWERS',[(k,ZZ(r).nbits()) for k,r in powers],flush=True)
