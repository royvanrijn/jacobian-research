from sage.all import ZZ
from pathlib import Path
import json,hashlib
directory=Path(__file__).resolve().parent;source=directory/'result.json';d=json.loads(source.read_text())
k,value=max(d['exact_power_representations'],key=lambda r:r[0]);n=ZZ(value)
if n.nbits()>128:raise ArithmeticError('factor input exceeds the declared 128-bit gate')
f=n.factor(proof=True)
if f.value()!=n or any(not p.is_prime(proof=True) for p,e in f):raise ArithmeticError('prime factorization failed')
out={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'scope':'Factor the largest exact-power root, only if at most 128 bits; one 60-second worker. Prove every factor prime and check multiplication.',
 'root':str(n),'power':k,'factors':[[str(p),int(e)] for p,e in f]}
(directory/'factorization.json').write_text(json.dumps(out,indent=2)+'\n');print(out['factors'],flush=True)
