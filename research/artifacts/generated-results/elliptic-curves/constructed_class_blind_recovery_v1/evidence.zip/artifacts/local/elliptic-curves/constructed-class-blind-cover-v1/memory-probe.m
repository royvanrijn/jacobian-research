SetColumns(0);
// SetMemoryLimit(2147483648) is prohibited by calculator; inspect existing limit.
print "LIMIT", GetMemoryLimit();
print "USAGE",GetMaximumMemoryUsage();
