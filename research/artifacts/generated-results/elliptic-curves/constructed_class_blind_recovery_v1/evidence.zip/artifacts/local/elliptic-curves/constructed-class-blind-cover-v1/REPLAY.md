The blind cover arm recovered rational points on both frozen covers. `cover-worker-report.json` is the concise outcome and timing record; `cover-worker-witness.json` contains primitive original coordinates and the full degree-four transport in column convention. `quartic-c6-b1000.json` and `quartic-c7-b1000.json` retain the complete conic/quartic transports and their search hits. The generated-results copies are named `cover-worker-quartic-c6.json` and `cover-worker-quartic-c7.json`.

The sole supplied mathematical input is `research/artifacts/generated-results/elliptic-curves/constructed_class_blind_recovery_v1/covers.json`, SHA256 `a8218511b1ac1b2def5dafe9c7803ebbdb0d33a7a0ffffca1c8e33a090efca1f`. Public algorithm sources and installed implementation sources are listed in `cover-worker-report.json`. The initial plan and subsequent exact search source freezes are retained as `PLAN.json`, `SEARCH_FREEZE.json` and `QUARTIC_SEARCH_FREEZE.json`.

The three implementation scripts are `research/elliptic-curves/rank-jump/blind_constructed_cover_remote.py`, `blind_constructed_cover_check.py` and `blind_constructed_cover_quartic.py`. Run from the repository root. The remote wrapper posts a retained `.m` request to the standard public Magma calculator, logs exact XML and result text, and charges the complete request wall time. The remote service's existing 400000000-byte memory limit is asserted before arithmetic. It retains its ordinary 60-second, 50000-byte input and 20000-character output limits.

A source-input replay, running one arithmetic worker at a time, follows this sequence for each column C=6 then C=7:

1. Run the remote wrapper on `compact-minred-cC.m`, then the exact checker with `--column C`.
2. Optionally reproduce the retained bounded degree-four misses by running the remote wrapper with `--kind search` on `pointsearch-qi-cC-b1000.m` and then `pointsearch-qi-cC-b100000.m`.
3. Run the remote wrapper on `conic-quartic-minred-v3-cC.m`.
4. Run the quartic script with `python3 .../blind_constructed_cover_quartic.py --column C` to verify every conic and quartic coefficient identity without searching.
5. Run `/home/royvanrijn/.local/bin/sage -python .../blind_constructed_cover_quartic.py --column C --bound 1000`. The local environment supplies PARI 2.17.3 through cypari2. This checks infinity and then uses `hyperellratpoints` with flag 1.
6. Run the exact checker with `--column C --point-result research/artifacts/local/elliptic-curves/constructed-class-blind-cover-v1/quartic-cC-b1000.point.txt` to verify primitive source coordinates and the elliptic-curve map.

No point or point-derived hint appears in the Magma requests or the frozen search implementation. The degree-two no-cross-term models retain reported positive level at 2; exact recovered rational points prevent any insolvability interpretation. Quartic bound 100000 was never needed. The initial truncated export, prohibited memory-limit-setting call, incorrect conic matrix action, and Magma loop-scope failure are retained with exact requests/results and charged timings. The invalid conic-derived quartic was never searched.

The complete charged arithmetic wall total is 18.401175454142503 seconds, including network waits, probes, and the preserved failed preparations. The two successful local quartic searches used 0.024704707029741257 seconds together. This is a bounded recovery result for supplied classes, with upstream construction excluded; mixed backend machines preclude an end-to-end speed conclusion.
