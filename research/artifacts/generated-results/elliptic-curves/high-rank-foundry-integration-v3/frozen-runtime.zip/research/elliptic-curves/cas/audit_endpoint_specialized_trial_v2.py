#!/usr/bin/env python3
"""Independent full-cloud proofs for each terminal prospective specialized-parity trial."""
import sys,argparse
from pathlib import Path
import endpoint_specialized_parity_trial as batch
import certify_compact_r17_candidates as cert
from research_runtime.store import checkpoint
from research_runtime.supervisor import run,Limits
ROOT=batch.ROOT;ART=batch.ART;CAS=batch.CAS

def main(index):
    out=batch.BATCH/'cloud-verification-v2'/f'{index:02}.json'
    if out.exists():raise FileExistsError('preserve endpoint cloud audit')
    p=batch.protocol();ledger={'status':'RUNNING','rows':[]};checkpoint(out,ledger)
    for index,row in [(index,p['rows'][index])]:
        batch.configure(index);D=batch.D;input=D/'result.json';data=cert.read(input)
        completion=cert.read(batch.BATCH/'completion-v1/ledger.json');done=next((r for r in completion['rows'] if r['id']==row['id']),None)
        if done is None or done['status']!='PASS':raise ArithmeticError('completed original worker and selected replay required')
        for label in ('worker','replay'):
            path=batch.ROOT/done[label+'_supervision'];record=cert.read(path)
            if cert.hashed(path)!=done[label+'_sha256'] or record['outcome']!='completed' or record['returncode']!=0:raise ArithmeticError('endpoint completion supervision differs')
        mod2=ART/('endpoint_specialized_'+row['id'].replace('-','_')+'_mod2_v1.json');modl=mod2.with_name(mod2.name.replace('_mod2_','_modl_'))
        jobs=[('mod2-build',['audit_recorded_point_mod2_rank_v3.py','--input',str(input),'--input-sha256',cert.hashed(input),'--output',str(mod2),'--prime-bound','997'],180),('mod2-check',['audit_recorded_point_mod2_rank_v3.py','--check',str(mod2)],180),('modl-build',['audit_retained_cloud_modl.py','--input',str(mod2),'--output',str(modl)],300),('modl-check',['audit_retained_cloud_modl.py','--check',str(modl)],300)]
        for label,args,seconds in jobs:
            s=run([sys.executable,str(CAS/args[0]),*args[1:]],limits=Limits(seconds,1610612736),log_path=D/(label+'.log'),checkpoint_path=D/(label+'.supervisor.json'),cwd=ROOT)
            if s['outcome']!='completed' or s['returncode']!=0:raise ArithmeticError('full-cloud proof failed or censored')
        cloud=cert.read(mod2);ell=cert.read(modl)
        ledger['rows'].append({'id':row['id'],'input':str(input.relative_to(ROOT)),'input_sha256':cert.hashed(input),'status':'PASS','attempted_charts':len(data['charts']),'completed_boxes':sum(c['search']['status']=='bounded_search_complete' for c in data['charts']),'rank_lower_bound':cloud['rank_lower_bound'],'retained_points':len(cloud['points']),'odd_modulus_lower_bounds':{str(a['modulus']):a['finite_column_rank'] for a in ell['audits']},'mod2_certificate':str(mod2.relative_to(ROOT)),'mod2_sha256':cert.hashed(mod2),'modl_certificate':str(modl.relative_to(ROOT)),'modl_sha256':cert.hashed(modl)})
        checkpoint(out,ledger);print('AUDITED ENDPOINT',row['id'],len(data['charts']),cloud['rank_lower_bound'],len(cloud['points']),flush=True)
    ledger['status']='PASS';checkpoint(out,ledger)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--index',type=int,required=True);a=p.parse_args();main(a.index)
