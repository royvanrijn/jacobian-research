"""
verify_135.py -- ancillary file of the note
  "The two shapes of maximal degree 135 with starting corner (9,36) in the plane Jacobian
   problem: exclusion of the degree pairs (135,90) and (90,135)"
Author : David Niedbala Giraudin (Independent researcher, France)
ORCID  : 0009-0009-1526-1178
Prepared with AI assistance (Claude, Anthropic).

Exact rational arithmetic (SymPy).  One step, marked [Singular], uses a Groebner basis computed
by the program Singular (https://www.singular.uni-kl.de): the script writes its input file and
runs it if `Singular` is on the PATH, and otherwise reports it as NOT CHECKED.  A second
Singular run (the whole system at once) is an optional confirmation.
  1. arithmetic of Remark 1.3 and Lemma 3.1 (corner);
  2. leading terms of Lemma 4.1 (coordinates);
  3. Lemma 5.1: the equation of weight 4 (leading pair);
  4. Proposition 5.2: the linear systems of weights 3, 2, 1, the five free coefficients, the
     29 compatibility conditions, and the fact that they generate the unit ideal;
  5. controls: a planted pair is recognised as a solution; a wrong right-hand side is not.
It does not prove the results quoted in the note.
Run:  python3 verify_135.py        (about ten seconds)
"""
import sympy as sp, shutil, subprocess, os, random
from sympy import Rational as R
from fractions import Fraction as Fr
from math import gcd
from collections import defaultdict
ok=True; count=0
def check(name,cond):
    global ok,count
    count+=1
    print(("PASS  " if cond else "FAIL  ")+name, flush=True); ok = ok and bool(cond)
exe=shutil.which('Singular'); here=os.path.dirname(os.path.abspath(__file__))
def singular(fn): return subprocess.run([exe,'-q',fn],stdin=subprocess.DEVNULL,capture_output=True,text=True).stdout.split()
def type_I(a,b,l,m,n):
    c1=Fr(a,l)-Fr(1,m+n); c2=Fr(b)-Fr(1,m+n); r,s=c2,-c1
    den=r.denominator*s.denominator//gcd(r.denominator,s.denominator)
    Rr,S=int(r*den),int(s*den); g=gcd(abs(Rr),abs(S)); Rr//=g; S//=g
    vP=Fr(m,m+n)*(Rr+S); vQ=Fr(n,m+n)*(Rr+S); out=[]
    ap=vP*l/(m*Rr)
    if ap.denominator==1 and ap>0: out.append('I.a')
    for nm,val in (('stQ',vQ),('stP',vP)):
        k=val*l/Rr
        if k.denominator==1 and k>0: out.append(nm)
    return (Rr,S),(vP,vQ),out
# ---------------- 1. arithmetic ----------------
for (m,n) in ((3,2),(2,3)):
    check("(m,n)=(%d,%d): corner (9,36), direction (9,-2): right-hand side of (5.9) is 9m/7 = %s, so a root of h of multiplicity k needs k >= 2"%(m,n,Fr(9*m,7)),
          Fr(m,1)*Fr(81-72,7)==Fr(9*m,7) and m*1<Fr(9*m,7)<=m*2)
    d,v,o=type_I(13,2,9,m,n)
    check("(m,n)=(%d,%d): (13/9,2), l=9: Case I impossible (direction %s); gcd(13,2)=1"%(m,n,d), o==[] and gcd(13,2)==1)
    d,v,o=type_I(17,4,9,m,n)
    check("(m,n)=(%d,%d): (17/9,4), l=9: Case I direction (9,-4), v(P1)=%s, v(Q1)=%s; gcd(17,4)=1"%(m,n,v[0],v[1]), d==(9,-4) and v==(m,n) and gcd(17,4)==1)
check("(1,0)+k(2/9,1) = (13/9,2), (15/9,3), (17/9,4) for k = 2, 3, 4", [1+Fr(2*k,9) for k in (2,3,4)]==[Fr(13,9),Fr(15,9),Fr(17,9)])
check("Case III directions strictly between (9,-4) and (9,-2) with rho' dividing 9: only (3,-1)",
      [(r,-j) for r in (1,3,9) for j in range(0,r+1) if gcd(r,j)==1 and Fr(-4,9)<Fr(-j,r)<Fr(-2,9)]==[(3,-1)])
# ---------------- 2. coordinates ----------------
X,eta,lam,l3,g2,g3=sp.symbols('X eta lambda lambda3 gamma2 gamma3')
def wt(t):
    pw=t.as_powers_dict(); return pw.get(X,0)-4*pw.get(eta,0)
def trunc(e,wm): return sp.Add(*[t for t in sp.Add.make_args(sp.expand(e)) if wt(t)>=wm])
def layers(e):
    by=defaultdict(int)
    for t in sp.Add.make_args(sp.expand(e)): by[wt(t)]+=t
    return {k:sp.factor(val) for k,val in by.items() if sp.simplify(val)!=0}
Y=eta+lam/X**2+l3/X**3; u=sp.expand(Y*X**2); dd=u-lam
inv=sum((-dd/lam)**k for k in range(8))/lam
zi=trunc(X*u**4-g2*Y**2-g3*Y,-6); vi=trunc(X**2*inv,-6)
Lzi=layers(zi); Lvi=layers(vi)
check("image of z = X^9 Y^4 - gamma2 Y^2 - gamma3 Y: W = 1, leading term lambda^4 X", max(Lzi)==1 and sp.simplify(Lzi[1]-lam**4*X)==0)
check("image of v = 1/Y: W = 2, leading term X^2/lambda", max(Lvi)==2 and sp.simplify(Lvi[2]-X**2/lam)==0)
k1=9*lam**3*l3; k0=-9*lam**6*l3**2
Lz=layers(trunc(trunc(zi*zi,-6)-lam**9*vi-k1*zi-k0,-6))
check("image of zeta = z^2 - c v - kappa1 z - kappa0 (c=lambda^9, kappa1=9 lambda^3 lambda3, kappa0=-9 lambda^6 lambda3^2): W = 0, leading term 9 lambda^7 eta X^4; next weight -1",
      sorted(Lz,reverse=True)[:2]==[0,-1] and sp.simplify(Lz[0]-9*lam**7*eta*X**4)==0)
# ---------------- 3. the leading pair ----------------
x=sp.Symbol('x'); D=sp.diff
q2=x**8+21*x**6+22*x**5+R(1183,8)*x**4+423*x**3+R(6721,16)*x**2+R(13679,8)*x+R(268777,256)
p3=(x**12+R(63,2)*x**10+33*x**9+R(6195,16)*x**8+981*x**7+R(40989,16)*x**6+R(78783,8)*x**5+R(3531639,256)*x**4
    +R(617825,16)*x**3+R(31456311,512)*x**2+R(11753097,256)*x+R(291742453,4096))
J=sp.Integer(2**19*27*19)
check("the displayed pair satisfies 3 p3 q2' - 2 p3' q2 = 2^19 * 27 * 19 = 268959744", sp.expand(3*p3*D(q2,x)-2*D(p3,x)*q2)==J)
check("p3^2 - q2^3 = 884736 (16 x^5 + 248 x^3 + 296 x^2 + 1001 x + 4426)", sp.expand(p3**2-q2**3-884736*(16*x**5+248*x**3+296*x**2+1001*x+4426))==0)
A=[sp.Symbol('a%d'%i) for i in range(12)]; Bc=[sp.Symbol('b%d'%i) for i in range(7)]
Pg=x**12+sum(A[i]*x**i for i in range(12)); Qg=x**8+sum(Bc[i]*x**i for i in range(7))
E=sp.Poly(sp.expand(3*Pg*D(Qg,x)-2*D(Pg,x)*Qg-1),x).all_coeffs()
check("generic monic p3 (degree 12) and q2 (degree 8, no x^7 term): 3 p3 q2' - 2 p3' q2 - 1 gives 19 equations in 19 unknowns", len(E)==19 and all(e!=0 for e in E))
r=R(3**13*7**19,2**38*19**2)
fn=os.path.join(here,'leading_135.sing')
open(fn,'w').write('// 3 p3 q2\' - 2 p3\' q2 = 1, p3 and q2 monic of degrees 12 and 8, no x^7 term in q2\nring r=0,(%s),dp;\noption(redSB);\nideal I=\n'%','.join(map(str,(A+Bc)[::-1]))
   +',\n'.join(str(e).replace('**','^') for e in E)+';\nideal G=std(I);\nprint("DIM");print(dim(G));print(vdim(G));print("B6");print(reduce(b6^19,G));\nquit;\n')
if exe is None:
    print("NOT CHECKED  Lemma 5.1, uniqueness (needs Singular; input file leading_135.sing written; expected output: DIM 0 19 B6 %s)"%r,flush=True)
else:
    out=singular(fn)
    check("Lemma 5.1 [Singular]: with J' = 1 the equation has exactly 19 solutions (dimension 0, degree 19), and b6^19 = 3^13 7^19 / (2^38 19^2) on all of them",
          out[:4]==['DIM','0','19','B6'] and R(out[4])==r)
check("the displayed pair, rescaled to J' = 1 by x -> nu x with nu^19 = J, has b6 = 21 nu^-2, and 21^19 / J^2 = 3^13 7^19 / (2^38 19^2): it is one of the 19 solutions",
      sp.Integer(21)**19/J**2==r and sp.Poly(q2,x).coeff_monomial(x**6)==21 and sp.Poly(q2,x).coeff_monomial(x**7)==0)
# ---------------- 4. the chain ----------------
z,kap=sp.symbols('z kappa')
def unk(name,deg,skip=()):
    c=[sp.Symbol('%s_%d'%(name,i)) for i in range(deg+1)]
    return sum(ci*x**i for i,ci in enumerate(c) if i not in skip), [ci for i,ci in enumerate(c) if i not in skip]
def layer(expr,V):
    eqs=sp.Poly(sp.expand(expr),x).all_coeffs()
    Am,bb=sp.linear_eq_to_matrix(eqs,V)
    assert all(e.is_Rational for e in Am)
    ne,nv=Am.shape
    Rr,piv=Am.row_join(sp.eye(ne)).rref()
    sol={}; conds=[]
    for i in range(ne):
        tb=sp.expand(sum(Rr[i,nv+j]*bb[j] for j in range(ne) if Rr[i,nv+j]!=0))
        lead=next((j for j in range(nv) if Rr[i,j]!=0),None)
        if lead is None:
            if tb!=0: conds.append(tb)
        else: sol[V[lead]]=sp.expand(tb-sum(Rr[i,j]*V[j] for j in range(nv) if j!=lead and Rr[i,j]!=0))
    return sol,[w for w in V if w not in sol],conds
def chain(r3,r2,r1,r0,with_kappa=True):
    """weights 3,2,1,0 of {U,V} = J z^4 + r3 z^3 + r2 z^2 + r1 z + r0 with U = z^3 p3 + z^2 u2 + z u1 + u0, V = z^2 q2 + z v1 + v0."""
    free=[]; conds=[]
    u2,V2=unk('u2',12,skip=(8,)); v1,V1=unk('v1',8)
    s,f,c=layer(3*p3*D(v1,x)-D(p3,x)*v1+2*u2*D(q2,x)-2*D(u2,x)*q2-r3, V2+V1); free+=f; conds+=c; n3=(len(f),len(c))
    u2=sp.expand(u2.subs(s)); v1=sp.expand(v1.subs(s))
    v0,V0=unk('v0',8,skip=(0,)); u1,W1=unk('u1',12)
    s,f,c=layer(3*p3*D(v0,x)+2*u2*D(v1,x)-D(u2,x)*v1+u1*D(q2,x)-2*D(u1,x)*q2-r2, V0+W1+([kap] if with_kappa else [])); free+=f; conds+=c; n2=(len(f),len(c))
    v0=sp.expand(v0.subs(s)); u1=sp.expand(u1.subs(s)); kv=s.get(kap,kap)
    u0,U0=unk('u0',13,skip=(0,))
    s,f,c=layer(2*u2*D(v0,x)+u1*D(v1,x)-D(u1,x)*v1-2*D(u0,x)*q2-r1, U0); free+=f; conds+=c; n1=(len(f),len(c))
    u0=sp.expand(u0.subs(s))
    c=[e for e in sp.Poly(sp.expand(u1*D(v0,x)-D(u0,x)*v1-r0.subs(kap,kv)),x).all_coeffs() if e!=0]; conds+=c
    return free,conds,(n3,n2,n1,len(c)),(u2,u1,u0,v1,v0)
free,conds,cnt,_=chain(sp.Integer(0),-2*J*(kap+x),sp.Integer(0),J*(kap+x)**2)
check("weights 3, 2, 1, 0: free coefficients %s; numbers of conditions %s"%([str(f) for f in free],(cnt[0][1],cnt[1][1],cnt[2][1],cnt[3])),
      [str(f) for f in free]==['v1_7','v1_8','u1_11','u1_12','kappa'] and (cnt[0][1],cnt[1][1],cnt[2][1],cnt[3])==(0,0,8,21))
G=sp.groebner(conds,*free,order='grevlex')
check("Proposition 5.2: the 29 conditions generate the unit ideal of Q[v1_7, v1_8, u1_11, u1_12, kappa] (Groebner basis {1}, SymPy)", len(conds)==29 and list(G.exprs)==[1])
# ---------------- 5. controls ----------------
random.seed(7)
rp=lambda d,skip=(): sum(random.randint(-3,3)*x**i for i in range(d+1) if i not in skip)
pu2,pu1,pu0,pv1,pv0=rp(12,(8,)),rp(12),rp(13,(0,)),rp(8),rp(8,(0,))
U0_=z**3*p3+z**2*pu2+z*pu1+pu0; V0_=z**2*q2+z*pv1+pv0
Bp=sp.Poly(sp.expand(D(U0_,z)*D(V0_,x)-D(U0_,x)*D(V0_,z)),z)
co=lambda k: Bp.coeff_monomial(z**k)
check("control: for a planted pair (random lower layers) the coefficient of z^4 of the bracket is J", sp.expand(co(4)-J)==0 and Bp.degree()==4)
freeC,condsC,cntC,_=chain(co(3),co(2),co(1),co(0),with_kappa=False)
vals={sp.Symbol('v1_7'):sp.Poly(pv1,x).coeff_monomial(x**7),sp.Symbol('v1_8'):sp.Poly(pv1,x).coeff_monomial(x**8),
      sp.Symbol('u1_11'):sp.Poly(pu1,x).coeff_monomial(x**11),sp.Symbol('u1_12'):sp.Poly(pu1,x).coeff_monomial(x**12)}
check("control: with the right-hand side of the planted pair, all conditions vanish at the planted values of the free coefficients",
      len(condsC)>0 and set(freeC)==set(vals) and all(sp.expand(e.subs(vals))==0 for e in condsC))
freeD,condsD,cntD,_=chain(co(3),co(2),co(1),co(0)+1,with_kappa=False)
check("control: after adding 1 to the right-hand side, the conditions no longer vanish there", any(sp.expand(e.subs(vals))!=0 for e in condsD))
# ---------------- optional: the whole system at once ----------------
def unk2(name,deg,skip=()):
    c=[sp.Symbol('%s_%d'%(name,i)) for i in range(deg+1)]
    return sum(ci*x**i for i,ci in enumerate(c) if i not in skip), [ci for i,ci in enumerate(c) if i not in skip]
u2,A2=unk2('u2',12,skip=(8,)); u1,A1=unk2('u1',12); u0,A0=unk2('u0',13,skip=(0,)); v1,B1=unk2('v1',8); v0,B0=unk2('v0',8,skip=(0,))
U=z**3*p3+z**2*u2+z*u1+u0; V=z**2*q2+z*v1+v0
Bf=sp.Poly(sp.expand(D(U,z)*D(V,x)-D(U,x)*D(V,z)-J*(z**2-kap-x)**2),z,x)
eqs=[e for e in Bf.coeffs() if e!=0]; names=A2+A1+A0+B1+B0+[kap]
check("the normalised system (S): %d unknowns, %d equations"%(len(names),len(eqs)), len(names)==56 and len(eqs)==82)
fn2=os.path.join(here,'system_135.sing')
open(fn2,'w').write('// the normalised system (S) of the note\nring r=0,(%s),dp;\noption(redSB);\nideal I=\n'%','.join(map(str,names[::-1]))+',\n'.join(str(e).replace('**','^') for e in eqs)+';\nideal G=std(I);\nprint("SIZE");print(size(G));print("FIRST");print(G[1]);\nquit;\n')
if exe is None: print("NOT CHECKED  optional confirmation (needs Singular; input file system_135.sing written; expected output: SIZE 1 FIRST 1)",flush=True)
else: check("optional confirmation [Singular]: the 82 equations of the normalised system generate the unit ideal (Groebner basis {1})", singular(fn2)==['SIZE','1','FIRST','1'])
print("%d checks"%count)
print("ALL CHECKS PASSED" if ok else "SOME CHECK FAILED")
