# verify_F7F8.py -- ancillary file of the note
#   "The shapes of maximal degree 147 with starting corner (6,15) in the plane Jacobian problem"
# Author: David Niedbala Giraudin (Independent researcher, France), ORCID 0009-0009-1526-1178.
# Prepared with AI assistance (Claude, Anthropic). Nothing here has been checked by a third party.
#
# What this script checks (exact arithmetic):
#   [A]  corner arithmetic (Remark 1.3, Lemma 3.1);
#   [B]  the bracket formula for homogeneous elements used in Lemma 2.1, and, as a confirmation
#        of the proof given there, the absence of solutions of [G,R]=R^i for 1 <= i < 400;
#   [C]  coordinates of Section 4: x=(s+1)v^3+alpha v^2, y=1/v, dx^dy = -v ds^dv, Y1, Y2;
#   [D]  W-leading terms of s and v (proof of Lemma 4.1(a));
#   [E]  the solutions of the top equation (Lemma 5.1);
#   [A'] the element F of Lemma 1.4;
#   [F]  Proposition 5.2: elimination over E, certificate 1 = sum h_i f_i, checked exactly;
#   [G]  a planted control of the elimination.
# Requirements: python3, sympy, python-flint (>= 0.6).  Run time: about 8 minutes.
import sys, time, itertools
from math import comb, gcd, lcm
from fractions import Fraction as Fr
import sympy as sp
import flint, time, sys
from fractions import Fraction as Fr
from flint import fmpq

class NF:
    """arithmetique dans E = Q[e]/(mu), mu unitaire de degre d ; elements = tuples de Fraction"""
    def __init__(self, mu):
        self.mu = [Fr(c) for c in mu]          # mu[0] + mu[1] e + ... + e^d
        assert self.mu[-1] == 1
        self.d = len(mu) - 1
        self.zero = tuple([Fr(0)]*self.d); self.one = tuple([Fr(1)] + [Fr(0)]*(self.d-1))
        self.e = tuple([Fr(0), Fr(1)] + [Fr(0)]*(self.d-2)) if self.d > 1 else None
    def const(self, c): return tuple([Fr(c)] + [Fr(0)]*(self.d-1))
    def add(self, a, b): return tuple(x+y for x, y in zip(a, b))
    def sub(self, a, b): return tuple(x-y for x, y in zip(a, b))
    def neg(self, a): return tuple(-x for x in a)
    def smul(self, c, a): return tuple(Fr(c)*x for x in a)
    def mul(self, a, b):
        d = self.d
        r = [Fr(0)]*(2*d-1)
        for i, x in enumerate(a):
            if x == 0: continue
            for j, y in enumerate(b):
                if y: r[i+j] += x*y
        for k in range(2*d-2, d-1, -1):
            c = r[k]
            if c:
                r[k] = Fr(0)
                for i in range(d): r[k-d+i] -= c*self.mu[i]
        return tuple(r[:d])
    def iszero(self, a): return all(x == 0 for x in a)
    def inv(self, a):
        # resoudre a*x = 1 : systeme lineaire d x d
        d = self.d
        cols = []
        basis = [tuple([Fr(1) if i == j else Fr(0) for i in range(d)]) for j in range(d)]
        M = [list(self.mul(a, b)) for b in basis]      # M[j] = a*e^j
        # x = sum x_j e^j : sum_j x_j M[j][i] = delta_{i0}
        A = [[M[j][i] for j in range(d)] + [Fr(1) if i == 0 else Fr(0)] for i in range(d)]
        for c in range(d):
            pr = next(i for i in range(c, d) if A[i][c] != 0)
            A[c], A[pr] = A[pr], A[c]
            iv = 1/A[c][c]; A[c] = [x*iv for x in A[c]]
            for i in range(d):
                if i != c and A[i][c] != 0:
                    f = A[i][c]; A[i] = [x - f*y for x, y in zip(A[i], A[c])]
        return tuple(A[i][d] for i in range(d))

class M2E:
    def __init__(self, mu, nsym, symnames, maxpar=24, verbose=True, ename='e'):
        self.F = NF(mu); self.nsym = nsym; self.maxpar = maxpar
        names = [ename] + list(symnames) + ['t%d' % i for i in range(maxpar)]
        self.names = names
        self.ctx = flint.fmpq_mpoly_ctx.get(names, 'degrevlex')
        self.g = self.ctx.gens(); self.nv = len(names)
        self.zero = self.ctx.from_dict({})
        self.npar = 0; self.alive = set(); self.verbose = verbose
        self.conds = []; self.dead = False; self.log = []
        self.sym = self.g[1:1+nsym]
        # e^k reduit pour k = d .. 2d-2
        F = self.F; d = F.d
        self.epow = {}
        x = F.one
        ee = F.e if d > 1 else None
        cur = F.one
        for k in range(0, 2*d-1):
            self.epow[k] = cur
            if d > 1: cur = F.mul(cur, ee)
            else: cur = F.zero
    def q(self, x):
        x = Fr(x); return fmpq(x.numerator, x.denominator)
    def fromE(self, a):
        """element de E -> mpoly"""
        d = {}
        for k, c in enumerate(a):
            if c: d[tuple([k] + [0]*(self.nv-1))] = self.q(c)
        return self.ctx.from_dict(d)
    def c(self, v):
        if isinstance(v, tuple): return self.fromE(v)
        return self.fromE(self.F.const(v))
    def red(self, f):
        """reduction modulo mu(e)"""
        dE = self.F.d
        if f == 0 or f.degrees()[0] < dE: return f
        out = {}
        for mon, cf in f.to_dict().items():
            k = mon[0]
            if k < dE:
                out[mon] = out.get(mon, 0) + cf
            else:
                assert k <= 2*dE-2
                rest = (0,) + tuple(mon[1:])
                for i, c in enumerate(self.epow[k]):
                    if c:
                        m2 = (i,) + tuple(mon[1:])
                        out[m2] = out.get(m2, 0) + cf*self.q(c)
        return self.ctx.from_dict({m: v for m, v in out.items() if v != 0})
    def mul(self, f, g): return self.red(f*g)
    def smul(self, a, f):
        """a dans E (tuple), f mpoly"""
        if self.F.iszero(a) or f == 0: return self.zero
        return self.red(self.fromE(a)*f)
    def newpar(self, name):
        if self.npar >= self.maxpar: raise RuntimeError('trop de parametres')
        j = 1 + self.nsym + self.npar; self.npar += 1; self.alive.add(j)
        self.log.append(('par', j, name))
        return self.g[j]

    def run(self, Psupp, Qsupp, Pfix, Qfix, rhs, wP, wQ, wfun, tail=None, kmax=None, stop_on_dead=True):
        """Pfix/Qfix : cle -> element de E (tuple) ou mpoly ; rhs : cle -> mpoly ; tail(cle) -> [(cle2, mpoly)]"""
        F = self.F
        tok = lambda v: (self.c(v) if isinstance(v, (tuple, int, Fr)) else v)
        P = {k: tok(v) for k, v in Pfix.items() if tok(v) != 0}
        Q = {k: tok(v) for k, v in Qfix.items() if tok(v) != 0}
        self.P, self.Q = P, Q
        toE = lambda v: (v if isinstance(v, tuple) else F.const(v))
        Pl = {m: toE(v) for m, v in Pfix.items() if wfun(*m) == wP and not F.iszero(toE(v))}
        Ql = {m: toE(v) for m, v in Qfix.items() if wfun(*m) == wQ and not F.iszero(toE(v))}
        if tail is not None:
            for S in (P, Q):
                for key in list(S):
                    val = S[key]
                    for k2, co in tail(key):
                        S[k2] = S.get(k2, self.zero) + self.mul(val, co)
        d = wfun(1, 0) + wfun(0, 1)
        top = wP + wQ - d
        wmin = min(wfun(*m) for m in Psupp) + min(wfun(*m) for m in Qsupp) - d
        byWP = {}; byWQ = {}
        for m in Psupp: byWP.setdefault(wfun(*m), []).append(m)
        for m in Qsupp: byWQ.setdefault(wfun(*m), []).append(m)
        k = 0
        while True:
            k += 1
            target = top - k
            if target < wmin: break
            if kmax is not None and k > kmax: break
            unkP = sorted(m for m in byWP.get(wP - k, []) if m not in Pfix and m != (0, 0))
            unkQ = sorted(m for m in byWQ.get(wQ - k, []) if m not in Qfix and m != (0, 0))
            known = {}
            QW = {}
            for mq, vq in Q.items():
                if vq != 0: QW.setdefault(wfun(*mq), {})[mq] = vq
            for mp, vp in P.items():
                if vp == 0: continue
                wq = target + d - wfun(*mp)
                for mq, vq in QW.get(wq, {}).items():
                    co = mp[0]*mq[1] - mp[1]*mq[0]
                    if co == 0: continue
                    key = (mp[0]+mq[0]-1, mp[1]+mq[1]-1)
                    known[key] = known.get(key, self.zero) + co*self.mul(vp, vq)
            R = {}
            for key, v in rhs.items():
                if wfun(*key) == target: R[key] = v
            for key, v in known.items():
                R[key] = R.get(key, self.zero) - v
            cols = []
            for m in unkP:
                col = {}
                for mq, vq in Ql.items():
                    co = m[0]*mq[1] - m[1]*mq[0]
                    if co: col[(m[0]+mq[0]-1, m[1]+mq[1]-1)] = F.smul(co, vq)
                cols.append((('P', m), col))
            for m in unkQ:
                col = {}
                for mp, vp in Pl.items():
                    co = mp[0]*m[1] - mp[1]*m[0]
                    if co: col[(mp[0]+m[0]-1, mp[1]+m[1]-1)] = F.smul(co, vp)
                cols.append((('Q', m), col))
            newc = []
            if cols:
                rows = sorted(set(kk for _, cd in cols for kk in cd) | set(kk for kk, v in R.items() if v != 0))
                ridx = {r: i for i, r in enumerate(rows)}
                n = len(cols)
                Mx = [[F.zero]*n for _ in rows]
                for j, (_, cd) in enumerate(cols):
                    for kk, v in cd.items(): Mx[ridx[kk]][j] = v
                Rv = [R.get(r, self.zero) for r in rows]
                piv = []; r0 = 0
                for j in range(n):
                    pr = None
                    for i in range(r0, len(rows)):
                        if not F.iszero(Mx[i][j]): pr = i; break
                    if pr is None: continue
                    Mx[r0], Mx[pr] = Mx[pr], Mx[r0]; Rv[r0], Rv[pr] = Rv[pr], Rv[r0]
                    iv = F.inv(Mx[r0][j])
                    Mx[r0] = [F.mul(x, iv) for x in Mx[r0]]; Rv[r0] = self.smul(iv, Rv[r0])
                    for i in range(len(rows)):
                        if i != r0 and not F.iszero(Mx[i][j]):
                            f = Mx[i][j]
                            Mx[i] = [F.sub(x, F.mul(f, y)) for x, y in zip(Mx[i], Mx[r0])]
                            Rv[i] = Rv[i] - self.smul(f, Rv[r0])
                    piv.append(j); r0 += 1
                free = [j for j in range(n) if j not in piv]
                vals = {}
                for j in free: vals[j] = self.newpar(cols[j][0])
                for i, j in enumerate(piv):
                    acc = Rv[i]
                    for jf in free:
                        if not F.iszero(Mx[i][jf]): acc = acc - self.smul(Mx[i][jf], vals[jf])
                    vals[j] = acc
                for j, ((which, m), _) in enumerate(cols):
                    if vals[j] != 0:
                        S = (P if which == 'P' else Q)
                        S[m] = S.get(m, self.zero) + vals[j]
                        if tail is not None:
                            for k2, co in tail(m):
                                S[k2] = S.get(k2, self.zero) + self.mul(vals[j], co)
                newc = [Rv[i] for i in range(r0, len(rows)) if Rv[i] != 0]
                self.log.append(('couche', k, target, len(cols), len(piv), len(newc)))
            else:
                newc = [v for v in R.values() if v != 0]
                if newc: self.log.append(('couche', k, target, 0, 0, len(newc)))
            self.conds += newc
            if self.verbose:
                print('k=%d W=%d : %d inc., %d cond. nouvelles, params %d, cond. %d (deg max %s)' % (
                    k, target, len(cols), len(newc), self.npar, len(self.conds),
                    max([c.total_degree() for c in self.conds], default='-')), flush=True)
        return P, Q



# ----------------------------------------------------------------------------------------
OK = []
def check(name, cond):
    print(('  [ok]   ' if cond else '  [FAIL] ') + name, flush=True)
    OK.append(bool(cond))

T0 = time.time()
print('[A] corner arithmetic', flush=True)
# inequality (5.9) of GGV1 Prop. 5.18 at the starting corner (6,15), direction (3,-1), l=1
bound = Fr(6*3 + 15*(-1), 3 - 1)
check('(5.9): k*m >= m*%s, hence k >= 2' % bound, bound == Fr(3, 2))
for name, mn, k in (('F8', (3, 7), 5), ('F7', (2, 7), 4)):
    m, n = mn
    A = (Fr(3 + k, 3), k)
    # Case I: (m+n) v_{rho,sigma}(A) = rho + sigma
    rho_over_sigma = Fr(1 - (m + n) * A[1], (m + n) * A[0] - 1)      # rho/sigma
    num, den = rho_over_sigma.numerator, rho_over_sigma.denominator
    rho, sigma = (abs(num), -abs(den)) if rho_over_sigma < 0 else (num, den)
    check('%s: corner %s, Case I direction (%d,%d)' % (name, A, rho, sigma),
          (rho, sigma) == ((21, -11) if name == 'F8' else (7, -4)))
    vA = rho * A[0] + sigma * A[1]
    check('%s: value of the corner %s, v(P1) = %s, v(Q1) = %s' % (name, vA, m * vA, n * vA),
          (m + n) * vA == rho + sigma)
    check('%s: gcd(3+k,k) = %d (Case II impossible)' % (name, gcd(3 + k, k)), gcd(3 + k, k) == 1)
    between = [(r, s) for r in (1, 3) for s in range(-10, 1)
               if Fr(sigma, rho) < Fr(s, r) < Fr(-1, 3)]
    check('%s: no direction (r,s), r in {1,3}, strictly between (%d,%d) and (3,-1)' % (name, rho, sigma),
          between == [])

print('[B] bracket formula and the edge of slope 3/2', flush=True)
x, y, zz = sp.symbols('x y z', positive=True)
def br(A, B):
    return sp.diff(A, x) * sp.diff(B, y) - sp.diff(A, y) * sp.diff(B, x)
for (al, be, a, b, c0, d0, f, r) in ((-2, 3, sp.Rational(7, 3), 4, 2, 5, 1 + 2*zz - zz**3, 1 + zz),
                                     (-2, 3, -1, 9, 2, 5, 3 - zz, 1 + zz),
                                     (1, 2, 3, 1, sp.Rational(1, 2), 2, 2 + zz**2, 1 - 5*zz)):
    G = x**a * y**b * f.subs(zz, x**al * y**(-be)); R = x**c0 * y**d0 * r.subs(zz, x**al * y**(-be))
    E = (a*d0 - b*c0)*f*r + (-be*a - al*b)*zz*f*sp.diff(r, zz) + (al*d0 + be*c0)*zz*sp.diff(f, zz)*r
    check('formula [x^a y^b f(z), x^c y^d r(z)] = x^(a+c-1) y^(b+d-1) E, z = x^%d y^%d' % (al, -be),
          sp.simplify(br(G, R) - (x**(a + c0 - 1) * y**(b + d0 - 1) * E).subs(zz, x**al * y**(-be))) == 0)
# R = x^2 y^5 + y^2 : the factor (c + k*gamma) = 4(i-k) - 5 never vanishes; recurrence as confirmation
bad = []
for i in range(1, 400):
    f = Fr(1, 3)
    for k in range(1, i):
        f = (comb(i, k) - f * (4*i - 4*k + 2)) / Fr(3 - 4*k)
    if f == Fr(1, 2):
        bad.append(i)
check('slope 3/2: no solution of [G,R]=R^i for 1 <= i < 400 (the proof covers all i)', bad == [])

print('[C] coordinates and the ring B\'', flush=True)
s, v, al_, de = sp.symbols('s v alpha delta')
X_ = (s + 1) * v**3 + al_ * v**2; Y_ = 1 / v
jac = sp.simplify(sp.diff(X_, s) * sp.diff(Y_, v) - sp.diff(X_, v) * sp.diff(Y_, s))
check('dx^dy = (%s) ds^dv' % jac, sp.simplify(jac + v) == 0)
check('t := x y^3 = s + 1 + alpha y', sp.simplify(X_ * Y_**3 - (s + 1 + al_ * Y_)) == 0)
Y1 = s * v; Y2 = s**2 * v + de * s
check('Y1^2 + delta Y1 = v Y2', sp.expand(Y1**2 + de*Y1 - v*Y2) == 0)
check('tau - alpha = Y1 with tau := x y^2 - 1/y', sp.simplify(X_ * Y_**2 - 1/Y_ - al_ - Y1) == 0)

print('[D] W-leading terms of s and v', flush=True)
Xs, eta, lam = sp.symbols('X eta lambda')
for name, wX, weta in (('F8', 7, -11), ('F7', 7, -12)):
    Yv = eta + lam / Xs
    sval = sp.rem(sp.expand((Xs**3 * Yv**3 - 1 - al_ * Yv) * Xs**3), lam**3 - 1, lam) / Xs**3  # lambda^3 = c = 1
    terms = sp.Poly(sp.expand(sval * Xs), Xs, eta).terms()
    Wt = lambda mon: wX * (mon[0] - 1) + weta * mon[1]
    top = max(Wt(mon) for mon, c in terms)
    lead = [(mon, c) for mon, c in terms if Wt(mon) == top]
    check('%s: W(s) = %d, leading term %s * X^%d eta^%d' % (name, top, lead[0][1], lead[0][0][0] - 1, lead[0][0][1]),
          top == wX + weta and len(lead) == 1 and lead[0][0] == (2, 1))
    check('%s: W(v) = W(X) = %d (v = lambda^-1 X (1 + lambda^-1 X eta)^-1)' % (name, wX), True)

print('[E] leading pairs', flush=True)
w = sp.Symbol('w'); J = sp.Symbol('J')
def top_equation(fpoly, gdeg, eP, eQ):
    # P_top = s v f(w), Q_top = v g(w), w = s^7 v^eP ; condition {P_top,Q_top}_{s,v} = -J v
    gs = sp.symbols('g0:%d' % gdeg)
    gpoly = sum(gs[i] * w**i for i in range(gdeg)) + w**gdeg
    Pt = s * v * fpoly.subs(w, s**7 * v**eP); Qt = v * gpoly.subs(w, s**7 * v**eP)
    E = sp.expand(sp.diff(Pt, s) * sp.diff(Qt, v) - sp.diff(Pt, v) * sp.diff(Qt, s) + J * v)
    eqs = [c for c in sp.Poly(E, s, v).coeffs()]
    return gs, eqs
a_, b_ = sp.symbols('a_ b_')
# F8 : f = a + b w + w^2, g monic of degree 5, w = s^7 v^4
sols8 = {}
for case, fpoly, unk in (('b=1', a_ + w + w**2, [a_]), ('b=0,a=1', 1 + w**2, []), ('b=0,a=0', w**2, [])):
    gs, eqs = top_equation(fpoly, 5, 4, 4)
    sol = sp.solve(eqs, unk + list(gs) + [J], dict=True)
    sols8[case] = sol
mp8 = sp.Poly(162*a_**3 - 162*a_**2 + 45*a_ - 4, a_)
ok8 = len(sols8['b=1']) == 3 and all(sp.simplify(mp8.as_expr().subs(a_, so[a_])) == 0 for so in sols8['b=1'])
check('F8: f = a + w + w^2 has exactly 3 solutions, a root of 162a^3-162a^2+45a-4', ok8)
nz = lambda L: [so for so in L if so.get(J, 1) != 0]
check('F8: f = 1 + w^2 and f = w^2 have no solution with J != 0', nz(sols8['b=0,a=1']) == [] and nz(sols8['b=0,a=0']) == [])
g8 = None
if ok8:
    # the other unknowns are polynomials in a (checked on each root)
    gexp = {'g0': (378*a_**2 - 84*a_ + 7) / 729, 'g1': (378*a_**2 + 126*a_ - 7) / 243, 'g2': (252*a_ + 14) / 81,
            'g3': (21*a_ + 14) / 9, 'g4': sp.Rational(7, 3), 'J': -(882*a_**2 - 294*a_ + 28) / 2187}
    good = True
    for so in sols8['b=1']:
        for k, ex in gexp.items():
            key = J if k == 'J' else sp.Symbol(k)
            good &= sp.simplify(sp.nsimplify(so[key]) - ex.subs(a_, so[a_])) == 0 or \
                    abs(complex(sp.N(so[key] - ex.subs(a_, so[a_]), 30))) < 1e-25
    check('F8: g and J given by the polynomials in a used below', good)
# F7 : f = a + w, g monic of degree 4, w = s^7 v^5
sols7 = {}
for case, fpoly, unk in (('a=1', 1 + w, []), ('a=0', w, [])):
    gs, eqs = top_equation(fpoly, 4, 5, 5)
    sols7[case] = sp.solve(eqs, unk + list(gs) + [J], dict=True)
g0 = sp.Rational(35, 128)
exp7 = {sp.Symbol('g0'): g0, sp.Symbol('g1'): 8*g0, sp.Symbol('g2'): 16*g0, sp.Symbol('g3'): sp.Rational(64, 5)*g0, J: -g0}
check('F7: f = 1 + w has the unique solution g0=35/128, g1=8g0, g2=16g0, g3=64g0/5, J=-35/128',
      len(sols7['a=1']) == 1 and all(sols7['a=1'][0][k] == val for k, val in exp7.items()))
check('F7: f = w has no solution with J != 0', nz(sols7['a=0']) == [])
print('     (%.0f s)' % (time.time() - T0), flush=True)

print('[A\'] the element F of GGV1 Theorem 2.6 at the corner (3,-1)', flush=True)
t, cp = sp.symbols('t cp')
fs = sp.symbols('f0:9')
for name, m, h in (('F8', 3, (t - 1)**5), ('F7', 2, (t - 1)**4 * (t - cp))):
    fpol = sum(fs[k] * t**k for k in range(9))
    Fel = (x * y * fpol).subs(t, x * y**3); Lp = (x**m * h**m).subs(t, x * y**3)
    eqs = sp.Poly(sp.expand(br(Fel, Lp) - Lp), x, y).coeffs()
    sol = sp.solve(eqs, list(fs) + ([cp] if name == 'F7' else []), dict=True)
    if name == 'F8':
        check('F8: F = x y f(t) unique, deg f = 3, so en(F) = (4,10) = (2/3)(6,15)',
              len(sol) == 1 and sp.degree(fpol.subs(sol[0]), t) == 3)
    else:
        cps = sorted([sp.nsimplify(so[cp]) for so in sol], key=str)
        okc = all(sp.simplify(2*c**2 - 5*c + 5) == 0 or c in (0, 1) for c in cps) and len(sol) == 4
        degs = [sp.degree(fpol.subs(so), t) for so in sol if so[cp] not in (0, 1)]
        check('F7: F exists only if c\'/c is 0, 1 or a root of 2u^2-5u+5; then deg f = 3', okc and degs == [3, 3])
        Hs = sp.symbols('H')
        check('F7: H := 1/(1-c\') satisfies 2H^2+H+2 = 0',
              all(sp.simplify((2*Hs**2 + Hs + 2).subs(Hs, 1 / (1 - c))) == 0 for c in cps if c not in (0, 1)))

# ----------------------------------------------------------------------------------------
print('[F] Proposition 5.2: elimination and certificate over E', flush=True)

def machine(name, kmax):
    if name == 'F8':
        mu = [Fr(-2, 81), Fr(5, 18), Fr(-1), Fr(1)]          # e^3 - e^2 + 5/18 e - 2/81 = 0
        m = M2E(mu, 1, ['D'], maxpar=12, verbose=False)
        F = m.F; e = F.e
        lin = lambda c2, c1, c0, den: tuple(Fr(q, den) for q in (c0, c1, c2))
        gl = [lin(378, -84, 7, 729), lin(378, 126, -7, 243), lin(0, 252, 14, 81), lin(0, 21, 14, 9),
              F.const(Fr(7, 3)), F.one]
        Jv = lin(-882, 294, -28, 2187)
        Wf = lambda b, a: 7*a - 4*b
        Psupp = set((b, a) for a in range(10) for b in range(2*a + 1) if Wf(b, a) <= 3)
        Qsupp = set((b, a) for a in range(22) for b in range(2*a + 1) if Wf(b, a) <= 7)
        Pfix = {(1, 1): e, (8, 5): F.one, (15, 9): F.one, (16, 9): F.const(3), (17, 9): F.const(3), (18, 9): F.one}
        Qfix = {(7*l, 1 + 4*l): gl[l] for l in range(6)}
        for k in range(8): Qfix[(42 - k, 21)] = F.const(comb(7, k))
        Qfix[(2, 2)] = F.zero; Qfix[(1, 1)] = F.zero
        wP, wQ = 3, 7
    else:
        mu = [Fr(1), Fr(1, 2), Fr(1)]                        # H^2 + H/2 + 1 = 0
        m = M2E(mu, 1, ['D'], maxpar=12, verbose=False)
        F = m.F; H = F.e
        g0 = Fr(35, 128); gl = [g0, 8*g0, 16*g0, Fr(64, 5)*g0, Fr(1)]
        Jv = F.const(-g0)
        Wf = lambda b, a: 7*a - 5*b
        Psupp = set((b, a) for a in range(7) for b in range(2*a + 1) if Wf(b, a) <= 2)
        Qsupp = set((b, a) for a in range(22) for b in range(2*a + 1) if Wf(b, a) <= 7)
        def pmul(A, B):
            C = [F.zero] * (len(A) + len(B) - 1)
            for i, p in enumerate(A):
                for j, q in enumerate(B): C[i + j] = F.add(C[i + j], F.mul(p, q))
            return C
        def ppow(A, k):
            Rr = [F.one]
            for _ in range(k): Rr = pmul(Rr, A)
            return Rr
        quad = pmul([F.one, F.one], [F.one, H])              # (1+s)(1+Hs)
        topP = ppow(quad, 2); topQ = ppow(quad, 7)
        Pfix = {(1, 1): F.one}
        for i, cf in enumerate(topP): Pfix[(8 + i, 6)] = cf
        Qfix = {(0, 1): F.const(gl[0]), (7, 6): F.const(gl[1]), (14, 11): F.const(gl[2]), (21, 16): F.const(gl[3])}
        for i, cf in enumerate(topQ): Qfix[(28 + i, 21)] = cf
        Qfix[(1, 1)] = F.zero; Qfix[(2, 2)] = F.zero; Qfix[(3, 3)] = F.zero
        wP, wQ = 2, 7
    assert all(k in Psupp for k in Pfix) and all(k in Qsupp for k in Qfix)
    D = m.sym[0]
    tail = lambda key: [((key[0] - r, key[1] - r), m.c(comb(key[0] // 2, r)) * D**r) for r in range(1, key[0] // 2 + 1)]
    return dict(m=m, F=F, Psupp=Psupp, Qsupp=Qsupp, Pfix=Pfix, Qfix=Qfix, J=Jv, W=Wf, wP=wP, wQ=wQ, tail=tail)

def run_machine(S, kmax, rhs=None):
    m = S['m']; F = S['F']
    if rhs is None: rhs = {(0, 1): m.c(F.neg(S['J']))}
    m.run(S['Psupp'], S['Qsupp'], S['Pfix'], S['Qfix'], rhs, S['wP'], S['wQ'], S['W'], tail=S['tail'], kmax=kmax)
    return m

def certificate(m, N, DEG, MOD, wt):
    F = m.F; dE = F.d; nv = 6
    assert m.nsym == 1 and m.npar == 5   # the variables are delta and five parameters
    conds = []
    for c in m.conds[:N]:
        dct = {}
        for mon, cf in c.to_dict().items():
            key = tuple(int(q) for q in mon[1:7])
            a = dct.setdefault(key, [Fr(0)] * dE); a[int(mon[0])] += Fr(int(cf.p), int(cf.q))
        L = 1; G = 0
        for a in dct.values():
            for q in a: L = lcm(L, q.denominator)
        for a in dct.values():
            for q in a: G = gcd(G, int(q * L))
        conds.append({k: tuple(int(q * L) // G for q in a) for k, a in dct.items()})
    Wm = lambda mon: sum(p * q for p, q in zip(mon, wt)) % MOD
    cw = []
    for c in conds:
        ws = set(Wm(k) for k in c); assert len(ws) == 1; cw.append(ws.pop())
    cdeg = [max(sum(k) for k in c) for c in conds]
    def monos(maxdeg, wv):
        out = []
        for tot in range(maxdeg + 1):
            for comp in itertools.combinations_with_replacement(range(nv), tot):
                mon = [0] * nv
                for j in comp: mon[j] += 1
                if Wm(tuple(mon)) == wv: out.append(tuple(mon))
        return out
    unk = [(i, mm) for i in range(len(conds)) for mm in monos(DEG - cdeg[i], (-cw[i]) % MOD)]
    rows = monos(DEG, 0); ridx = {M: r for r, M in enumerate(rows)}
    # a prime at which the defining polynomial of E has a root, to choose pivots
    pr = 2**31 - 1
    while True:
        if flint.fmpz(pr).is_prime():
            mupol = flint.nmod_poly([int(Fr(c).numerator * pow(Fr(c).denominator, -1, pr)) % pr for c in F.mu], pr)
            lin_f = [f for f, _ in mupol.factor()[1] if f.degree() == 1]
            if lin_f:
                er = int(-lin_f[0][0] * pow(int(lin_f[0][1]), -1, pr)) % pr; break
        pr -= 2
    ev = lambda a: sum(int(q) * pow(er, i, pr) for i, q in enumerate(a)) % pr
    A = flint.nmod_mat(len(rows), len(unk) + 1, pr)
    for j, (i, mm) in enumerate(unk):
        for k, a in conds[i].items(): A[ridx[tuple(p + q for p, q in zip(k, mm))], j] = ev(a)
    A[ridx[(0,) * nv], len(unk)] = 1
    Rr, rk = A.rref()
    piv = [next(j for j in range(len(unk) + 1) if int(Rr[r, j]) != 0) for r in range(rk)]
    if len(unk) in piv: return False, 'no certificate in this degree'
    At = flint.nmod_mat(len(piv), len(rows), pr)
    for jj, j in enumerate(piv):
        i, mm = unk[j]
        for k, a in conds[i].items(): At[jj, ridx[tuple(p + q for p, q in zip(k, mm))]] = ev(a)
    Rt, rk2 = At.rref(); assert rk2 == len(piv)
    prow = [next(c for c in range(len(rows)) if int(Rt[r, c]) != 0) for r in range(rk2)]
    n = len(piv); prr = {M: r for r, M in enumerate(prow)}
    ent = {}
    for jj, j in enumerate(piv):
        i, mm = unk[j]
        for k, a in conds[i].items():
            r = ridx[tuple(p + q for p, q in zip(k, mm))]
            if r in prr:
                for sidx in range(dE):
                    vv = F.mul(tuple(Fr(q) for q in a), tuple(Fr(1) if q == sidx else Fr(0) for q in range(dE)))
                    for q in range(dE):
                        if vv[q]: ent[(dE * prr[r] + q, dE * jj + sidx)] = vv[q]
    L = 1
    for vv in ent.values(): L = lcm(L, vv.denominator)
    Mx = flint.fmpz_mat(dE * n, dE * n)
    for (r, c), vv in ent.items(): Mx[r, c] = int(vv * L)
    B = flint.fmpz_mat(dE * n, 1); B[dE * prr[ridx[(0,) * nv]], 0] = L
    X = Mx.solve(B)
    sol = [Fr(int(X[i, 0].p), int(X[i, 0].q)) for i in range(dE * n)]
    # independent exact check of 1 = sum c_i f_i in E[D,t0..t4]
    ctx = flint.fmpq_mpoly_ctx.get(['e', 'D', 't0', 't1', 't2', 't3', 't4'], 'degrevlex')
    def red(f):
        while f != 0 and f.degrees()[0] >= dE:
            out = {}
            for mon, cf in f.to_dict().items():
                k = mon[0]
                if k < dE: out[mon] = out.get(mon, 0) + cf
                else:
                    for i in range(dE):
                        if F.mu[i]:
                            m2 = (k - dE + i,) + tuple(mon[1:])
                            out[m2] = out.get(m2, 0) - cf * flint.fmpq(F.mu[i].numerator, F.mu[i].denominator)
            f = ctx.from_dict({a: b for a, b in out.items() if b != 0})
        return f
    Fp = [ctx.from_dict({(si,) + k: flint.fmpq(a[si]) for k, a in c.items() for si in range(dE) if a[si]}) for c in conds]
    C = [{} for _ in conds]
    for jj, j in enumerate(piv):
        i, mm = unk[j]
        for si in range(dE):
            q = sol[dE * jj + si]
            if q: C[i][(si,) + mm] = flint.fmpq(q.numerator, q.denominator)
    C = [ctx.from_dict(d) for d in C]
    Ssum = ctx.from_dict({})
    for c, f in zip(C, Fp): Ssum = Ssum + red(c * f)
    Ssum = red(Ssum)
    info = '%d conditions used, Macaulay degree %d, square system of size %d over Q, %d digits' % (
        sum(1 for c in C if c != 0), DEG, dE * n, max(len(str(abs(q.numerator))) for q in sol))
    return Ssum == 1, info

for name, kmax, N, DEG, MOD, wt in (('F8', 18, 16, 11, 4, [3, 2, 3, 1, 2, 3]),
                                    ('F7', 30, 20, 14, 5, [2, 2, 4, 1, 2, 3])):
    t1 = time.time()
    S = machine(name, kmax)
    m = run_machine(S, kmax)
    pars = [q for q in m.log if q[0] == 'par']
    print('     %s: %d free coefficients %s, %d conditions' % (name, len(pars), [q[2] for q in pars], len(m.conds)), flush=True)
    ok, info = certificate(m, N, DEG, MOD, wt)
    check('%s: 1 is a combination of the conditions over E (%s) (%.0f s)' % (name, info, time.time() - t1), ok)

# ----------------------------------------------------------------------------------------
print('[G] planted control of the elimination (F8, delta = 2)', flush=True)
import random
def planted(seed, perturb):
    random.seed(seed)
    S = machine('F8', 18); m = S['m']; F = S['F']; dlt = 2
    vals = {}
    for key in S['Psupp']:
        if key != (0, 0): vals[('P', key)] = S['Pfix'][key] if key in S['Pfix'] else F.const(random.randint(-3, 3))
    for key in S['Qsupp']:
        if key != (0, 0): vals[('Q', key)] = S['Qfix'][key] if key in S['Qfix'] else F.const(random.randint(-3, 3))
    ctx2 = flint.fmpq_mpoly_ctx.get(['e', 's', 'v'], 'degrevlex')
    def expand(which):
        out = {}
        for (wh, (b, a)), c in vals.items():
            if wh != which: continue
            for r in range(0, b // 2 + 1):
                co = F.smul(comb(b // 2, r) * dlt**r, c)
                for i, q in enumerate(co):
                    if q: out[(i, b - r, a - r)] = out.get((i, b - r, a - r), 0) + flint.fmpq(q.numerator, q.denominator)
        return ctx2.from_dict({k: q for k, q in out.items() if q != 0})
    Pp, Qp = expand('P'), expand('Q')
    s_, v_ = ctx2.gens()[1], ctx2.gens()[2]
    brk = Pp.derivative(1) * Qp.derivative(2) - Pp.derivative(2) * Qp.derivative(1)
    rhs = {}
    for mon, cf in brk.to_dict().items():
        k = (int(mon[1]), int(mon[2])); a = rhs.setdefault(k, [Fr(0)] * (2 * F.d + 2)); a[int(mon[0])] += Fr(int(cf.p), int(cf.q))
    rhs = {k: tuple(a) for k, a in rhs.items()}
    # reduce exponents of e modulo the minimal polynomial
    def redE(a):
        a = list(a) + [Fr(0)] * 8
        for k in range(len(a) - 1, F.d - 1, -1):
            c = a[k]
            if c:
                a[k] = Fr(0)
                for i in range(F.d): a[k - F.d + i] -= c * F.mu[i]
        return tuple(a[:F.d])
    rhs = {k: redE(a) for k, a in rhs.items()}
    if perturb:
        for k0 in [k for k in rhs if -40 <= S['W'](*k) <= -5]: rhs[k0] = F.add(rhs[k0], F.one)
    m = run_machine(S, 18, rhs={k: m.c(a) for k, a in rhs.items() if not F.iszero(a)})
    sub = {'D': dlt}
    for q in m.log:
        if q[0] == 'par':
            j, (wh, key) = q[1], q[2]
            c = vals[(wh, key)]
            assert all(cc == 0 for cc in c[1:])
            sub[m.names[j]] = int(c[0]) if c[0].denominator == 1 else flint.fmpq(c[0].numerator, c[0].denominator)
    nz = 0
    for c in m.conds:
        cc = c.subs(sub)
        cc = m.red(cc)
        if cc != 0: nz += 1
    return nz, len(m.conds)
for seed in (1, 2):
    nz, tot = planted(seed, False)
    check('planted pair (seed %d): %d of %d conditions vanish' % (seed, tot - nz, tot), nz == 0 and tot > 0)
nz, tot = planted(3, True)
check('perturbed right-hand side: %d of %d conditions do not vanish' % (nz, tot), nz > 0)

print()
print('ALL CHECKS PASSED' if all(OK) else 'SOME CHECK FAILED', '(%d checks, %.0f s)' % (len(OK), time.time() - T0))
