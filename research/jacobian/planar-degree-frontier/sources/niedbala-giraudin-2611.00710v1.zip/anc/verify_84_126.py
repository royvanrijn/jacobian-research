"""
verify_84_126.py -- ancillary file of the note
  "The degree pair (84,126) in the plane Jacobian problem: exclusion of the shape
   with final corner (19/7,5)"
Author : David Niedbala Giraudin (Independent researcher, France)
ORCID  : 0009-0009-1526-1178
Prepared with AI assistance (Claude, Anthropic).

Exact arithmetic (SymPy).  One step, marked [Singular], needs the free computer algebra
system Singular; the script calls the program `Singular` if it is on the PATH (or if its
path is given as first argument) and otherwise reports that step as NOT CHECKED.

Checks, in the order of the note:
 (a) the arithmetic of the final corner (Lemma 3.1) and of Remark 1.3;
 (b) the leading terms of v and zeta in the variables X, eta (Lemma 4.1);
 (c) the layer of order 0 of the system (S) and its uniqueness (Lemma 5.1);
 (d) Proposition 5.2: the system (S) has no solution.
       stage A: orders 1..23, no assumption: the compatibility conditions, polynomials in
                five parameters, generate an ideal containing three of them   [Singular];
       stage B: with these three equal to 0, the conditions of orders 1..36 generate the
                unit ideal                                                    [SymPy];
 (e) control: without condition (S3) the same computation has the solution 0.
 (f) optional (ONEPASS=True, about 10 more minutes): the conditions of orders 1..30, with no
     intermediate assumption, generate the unit ideal                         [Singular].
The script does not prove the reductions of the note, nor the results it quotes.
Run:  python3 verify_84_126.py            (about 3 minutes; the output of a complete run,
      with ONEPASS=True, is in expected_output.txt)
It prints PASS / FAIL / NOT CHECKED lines and a final summary.
"""
import sympy as sp, time, shutil, subprocess, sys
from sympy import Rational as R
ok=True; skipped=0
def check(name,cond):
    global ok
    print(("PASS  " if cond else "FAIL  ")+name, flush=True); ok = ok and bool(cond)

# ---------------- (a) arithmetic of the corners ---------------------------------------
def typeI(a7,b,m=2,n=3):
    """corner A=(a7/7,b) of an (m,n)-pair in L^(7): data forced by a type I corner, or None."""
    r,s=sp.symbols('r s')
    # v(P)+v(Q)=rho+sigma, v(P)/v(Q)=m/n, v(P)=m*v(A)
    sol=sp.solve(sp.Eq(m*(r*R(a7,7)+b*s),R(m,m+n)*(r+s)),s)[0]      # sigma as multiple of rho
    ratio=sp.nsimplify(sol/r)                                        # sigma/rho
    rho=sp.denom(ratio); sig=sp.numer(ratio)
    vP=R(m,m+n)*(rho+sig); vQ=R(n,m+n)*(rho+sig)
    out=[]
    ap=vP*7/(m*rho)                    # I.a): st(P)/m=(a'/7,0)
    if ap==int(ap) and ap>0: out.append(('I.a',rho,sig,ap))
    for nm,val in (('I.b, st(Q)=(k/7,0)',vQ),('I.b, st(P)=(k/7,0)',vP)):
        k=val*7/rho
        if k==int(k) and k>0: out.append((nm,rho,sig,k))
    return out
check("corner (19/7,5): type I forces (rho,sigma)=(21,-11), st(Q)=(2/7,0), st(P)=(5/7,1), nothing else",
      typeI(19,5)==[('I.b, st(Q)=(k/7,0)',21,-11,2)])
check("corner (19/7,5): v(P1)=4, v(Q1)=6; end points (38/7,10), (57/7,15); gcd(19,5)=1",
      21*R(38,7)-110==4 and 21*R(57,7)-165==6 and 21*R(5,7)-11==4 and 21*R(2,7)==6 and sp.gcd(19,5)==1)
check("corner (17/7,3): type I impossible and gcd(17,3)=1 (Remark 1.3)", typeI(17,3)==[] and sp.gcd(17,3)==1)
check("inequality (5.9) of [GGV1] at the starting corner: 14/3 <= 10; a root of multiplicity k of h needs 2k >= 14/3, i.e. k >= 3",
      R(2,1)*(7*7-35)/(7-1)==R(14,3))

# ---------------- (b) leading terms -----------------------------------------------------
X,eta,E,lam,l2,l3,g2,g3,g4=sp.symbols('X eta E lambda lambda2 lambda3 g2 g3 g4')
# weight W(X^i eta^j)=3i-11j is recorded by E: X -> X/E^3, eta -> eta*E^11  (W = -(exponent of E))
y=lam*E**3/X+l2*E**6/X**2+l3*E**9/X**3+eta*E**11
yX=sp.expand(y*X/(lam*E**3))                      # = 1 + (terms with positive powers of E)
u=sp.expand(yX-1)
invy=sum((-u)**k for k in range(0,5))             # (1+u)^(-1) up to terms of E-order >= 15 > 9
vv=sp.expand(X/(lam*E**3)*invy)
def trunc(e,N):                                   # keep E-exponents <= N  (weights >= -N)
    e=sp.expand(e); return sp.Add(*[t for t in sp.Add.make_args(e) if t.as_coeff_exponent(E)[1]<=N])
vv=trunc(vv,6)
zz=sp.expand((X/E**3)**7*y**5-g2*y**3-g3*y**2-g4*y)
c0s=lam**7; k1=7*lam**5*l2
zeta0=trunc(zz-c0s*trunc(vv**2,2)-k1*vv,2)
k2=sp.simplify(trunc(zeta0,0))                    # the constant term defines kappa2
zeta=sp.expand(zeta0-k2)
check("W(v)=3 with leading term X/lambda", sp.expand(trunc(vv,-3)-X/(lam*E**3))==0)
check("kappa2 is a constant (printed below)", k2.free_symbols<= {lam,l2,l3})
check("zeta = z - lambda^7 v^2 - 7 lambda^5 lambda2 v - kappa2 has W(zeta)=-2 with leading term 7 lambda^4 eta X^3",
      sp.expand(zeta-7*lam**4*eta*X**3*E**2)==0)
print("      kappa2 =",sp.factor(k2),flush=True)

# ---------------- the system (S) ---------------------------------------------------------
z,v=sp.symbols('zeta v')
def supp(top,wmax): return [(a,b) for a in range(0,top//2+1) for b in range(0,top+1) if 2*a+b<=top and 3*b-2*a<=wmax]
SP=supp(28,4); SQ=supp(42,6)
def br(f,g): return sp.expand(sp.diff(f,z)*sp.diff(g,v)-sp.diff(f,v)*sp.diff(g,z))
s=z**3*v**2
P0=sp.expand(z*v**2*(1+R(5,4)*s+s**2/2+s**3/12))
Q0=sp.expand(v**2*(1+5*s+R(16,3)*s**2+R(8,3)*s**3+R(2,3)*s**4+R(2,27)*s**5))

# ---------------- (c) order 0 --------------------------------------------------------------
check("layer 0 of P is supported on (1,2),(4,4),(7,6),(10,8) and that of Q on (0,2),(3,4),...,(15,12)",
      sorted(p for p in SP if 3*p[1]-2*p[0]==4)==[(1,2),(4,4),(7,6),(10,8)] and
      sorted(p for p in SQ if 3*p[1]-2*p[0]==6)==[(0,2),(3,4),(6,6),(9,8),(12,10),(15,12)])
check("order 0: {P0,Q0} = 2 v^3", br(P0,Q0)==2*v**3)
a4,a7,h1,h2,h3,h4,h5,Jc=sp.symbols('a4 a7 h1 h2 h3 h4 h5 J')
GP=z*v**2*(1+a4*s+a7*s**2+s**3/12); GQ=v**2*(1+h1*s+h2*s**2+h3*s**3+h4*s**4+h5*s**5)
e0=sp.expand(br(GP,GQ)+Jc*v**3)
sol0=sp.solve(sp.Poly(e0,z,v).coeffs(),[a4,a7,h1,h2,h3,h4,h5,Jc],dict=True)
check("order 0: J=-2 and exactly 3 solutions, with a4^3 = 125/64 (exchanged by zeta^3 v^2 -> cube root of 1 times itself)",
      len(sol0)==3 and all(d[Jc]==-2 and sp.simplify(d[a4]**3-R(125,64))==0 for d in sol0)
      and any(d[a4]==R(5,4) and sp.expand((GP-P0).subs(d))==0 and sp.expand((GQ-Q0).subs(d))==0 for d in sol0))
check("boundary: the coefficient of zeta^10 v^8 in (1/12) zeta^10 (zeta+v^2)^4 is 1/12, as in P0",
      sp.Poly(sp.expand(z**10*(z+v**2)**4/12),z,v).coeff_monomial((10,8))==sp.Poly(P0,z,v).coeff_monomial((10,8)))

# ---------------- (d) the layer-by-layer solution ---------------------------------------
def run(K,boundary=True,zero=()):
    known={}
    if boundary:
        for (a,b),c in sp.Poly(sp.expand(R(1,12)*z**10*(z+v**2)**4),z,v).terms(): known[(a,b)]=c
    gz=set([('q',10,8),('q',0,0),('p',0,0)])|set(zero)
    Pd={0:P0}; Qd={0:Q0}; free=[]; cons=[]; numeric=True
    for k in range(1,K+1):
        newv=[]; Pp=sp.Integer(0); Qp=sp.Integer(0)
        for (a,b) in SP:
            if 3*b-2*a!=4-k: continue
            if (a,b) in known: Pp+=known[(a,b)]*z**a*v**b
            elif ('p',a,b) not in gz:
                x=sp.Symbol('p_%d_%d'%(a,b)); newv.append(x); Pp+=x*z**a*v**b
        for (a,b) in SQ:
            if 3*b-2*a!=6-k: continue
            if ('q',a,b) not in gz:
                x=sp.Symbol('q_%d_%d'%(a,b)); newv.append(x); Qp+=x*z**a*v**b
        Pd[k]=Pp; Qd[k]=Qp
        def order(): return sp.expand(sum(br(Pd[i],Qd[k-i]) for i in range(0,k+1)))
        e=order()
        eqs=sp.Poly(e,z,v).coeffs() if e!=0 else []
        if newv and eqs:
            A,b=sp.linear_eq_to_matrix(eqs,newv)
            numeric = numeric and all(x.is_Rational for x in A)
            S=sp.linsolve((A,b),newv)
            if S==sp.EmptySet or len(S)==0: S=sp.linsolve((A.T*A,A.T*b),newv)
            solv=list(S)[0]; rep={}
            for x,val in zip(newv,solv):
                val=sp.expand(val)
                if val!=x: rep[x]=val
            Pd[k]=sp.expand(Pd[k].subs(rep)); Qd[k]=sp.expand(Qd[k].subs(rep))
            free+=[x for x in newv if x not in rep]
            e=order()
            eqs=sp.Poly(e,z,v).coeffs() if e!=0 else []
        elif newv: free+=newv
        for c in eqs: cons.append((k,c))
    out=[]; seen=set()
    for k,c in cons:
        Pc=sp.Poly(c,*free) if free else sp.Poly(c,z)
        if Pc.is_zero: continue
        Pc=Pc.primitive()[1]
        if Pc.LC()<0: Pc=-Pc
        if Pc.as_expr() not in seen: seen.add(Pc.as_expr()); out.append((k,Pc.as_expr()))
    return free,out,numeric
t0=time.time(); print("stage A: orders 1..23 ...",flush=True)
freeA,polA,numA=run(23)
namesA=[str(x) for x in freeA]
check("stage A: every linear system has rational coefficients; free parameters q_14_11, q_15_11, q_14_10, q_15_10, q_13_8",
      numA and namesA==['q_14_11','q_15_11','q_14_10','q_15_10','q_13_8'])
print("      %d conditions (%.0f s)"%(len(polA),time.time()-t0),flush=True)
src="ring r=0,(%s),wp(1,3,4,6,8);\nideal I=\n"%",".join(namesA)
src+=",\n".join(str(p).replace('**','^') for k,p in polA)+";\nideal G=std(I);\n"
src+='print("STAGEA "+string(reduce(q_14_11,G))+" "+string(reduce(q_15_11,G))+" "+string(reduce(q_15_10,G))+" "+string(reduce(1,G)));\nquit;\n'
open("stageA.sing","w").write(src)
exe=shutil.which("Singular") or (sys.argv[1] if len(sys.argv)>1 else None)
if exe:
    out=subprocess.run([exe,"-q"],input=src,capture_output=True,text=True).stdout
    check("stage A [Singular]: q_14_11, q_15_11, q_15_10 belong to the ideal of the conditions (and 1 does not)", "STAGEA 0 0 0 1" in out)
else:
    skipped+=1
    print("NOT CHECKED  stage A [Singular]: program not found; run `Singular -q < stageA.sing`, expected output: STAGEA 0 0 0 1",flush=True)
t0=time.time(); print("stage B: orders 1..36 ...",flush=True)
Z=(('q',14,11),('q',15,11),('q',15,10))
freeB,polB,numB=run(36,zero=Z)
check("stage B: rational linear systems; free parameters q_14_10, q_13_8", numB and [str(x) for x in freeB]==['q_14_10','q_13_8'])
G=sp.groebner([e for k,e in polB],*freeB,order='grevlex')
check("stage B [SymPy]: the %d conditions generate the unit ideal: (S) HAS NO SOLUTION"%len(polB), list(G.exprs)==[1])
print("      (%.0f s)"%(time.time()-t0),flush=True)

# ---------------- (e) control ---------------------------------------------------------------
freeC,polC,numC=run(36,boundary=False,zero=Z)
check("control: without (S3) there are %d conditions and 0 is a common zero of all of them"%len(polC),
      len(polC)>0 and all(e.subs({x:0 for x in freeC})==0 for k,e in polC))
# ---------------- (f) optional: one pass, no intermediate assumption (about 10 more minutes)
ONEPASS=False      # set to True to run it
if ONEPASS and exe:
    freeO,polO,numO=run(30)
    srcO="ring r=0,(%s),wp(1,3,4,6,8);\nideal I=\n"%",".join(str(x) for x in freeO)
    srcO+=",\n".join(str(p).replace('**','^') for k,p in polO)+";\nideal G=std(I);\n"
    srcO+='print("ONEPASS "+string(reduce(1,G)));\nquit;\n'
    outO=subprocess.run([exe,"-q"],input=srcO,capture_output=True,text=True).stdout
    check("one pass [Singular]: the %d conditions of orders 1..30 in the five parameters generate the unit ideal"%len(polO), "ONEPASS 0" in outO)
print("ALL CHECKS PASSED" if ok and not skipped else ("ALL EXECUTED CHECKS PASSED; %d step NOT CHECKED (Singular missing)"%skipped if ok else "SOME CHECK FAILED"))
