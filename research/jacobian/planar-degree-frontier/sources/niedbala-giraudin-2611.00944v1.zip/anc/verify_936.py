# verify_936.py -- ancillary file of the note
#   "A shape of maximal degree 135 in the plane Jacobian problem:
#    exclusion of the complete chain (9,36), (9,24), (11/3,8)"
# Author: David Niedbala Giraudin (Independent researcher, France), ORCID 0009-0009-1526-1178.
# Prepared with AI assistance (Claude, Anthropic). Nothing here has been checked by a third party.
#
# What this script checks (exact arithmetic):
#   [A] Lemma 2.1: the direction (3,-1) of the edge A1A2, the value p_j/q_j = 2/3, q_j = 3,
#       and the degree pair (45m, 45n) = (90, 135);
#   [B] Lemma 3.1, on examples: for h = y^8 p(y) with p monic of degree 4, the equation
#       f h' - 3 f' h = kappa h  (equivalent to [x f, x^{9m} h^{3m}] = x^{9m} h^{3m} with
#       kappa = 1/(3m)) has no solution with kappa != 0 and deg f <= 4 when p has 4 distinct
#       roots; positive control: for p = (y-c)^4 a solution with deg f = 4 exists; and the
#       local statement (f has a simple root at every root of h) on all solutions found;
#   [C] Lemma 4.2: the points (9,3k), k = 1..4 (k=2: form wp(n',n'-1); k=3: aligned with (1,1);
#       k=4: above the diagonal; k=1 is a possible last lower corner, so it is not excluded
#       by this step: this is why Lemma 3.1 is needed);
#   [D] proof of Theorem 1.2: the partitions of 4 into at most 3 parts all have a part 2, 3 or 4;
#   [E] the rows of [GGV4, Section 6] with first corner (9,36) and maximal degree 135
#       (transcribed from the source), none with second corner (9,12);
#   [F] the remark on the chain (12,36),(12,33),(11/3,8): corner (12,3) is a possible last
#       lower corner (so the method does not exclude that chain).
# Requirements: python3, sympy.  Run time: a few seconds.
import random
from fractions import Fraction as Fr
from itertools import combinations
import sympy as sp

ok_all = True
def check(name, cond):
    global ok_all
    print(("  ok   " if cond else "  FAIL ") + name, flush=True)
    ok_all = ok_all and bool(cond)

def v(w, A):
    return w[0] * Fr(A[0]) + w[1] * Fr(A[1])

print("[A] Lemma 2.1", flush=True)
A0, A1, A2 = (Fr(9), Fr(36)), (Fr(9), Fr(24)), (Fr(11, 3), Fr(8))
w = (3, -1)
check("v_{3,-1}(A1) = v_{3,-1}(A2) = 3", v(w, A1) == v(w, A2) == 3)
# primitive direction of A1 - A2: (dy, -dx) normalised
dx, dy = A1[0] - A2[0], A1[1] - A2[1]
ratio = dy / dx
check("edge A2A1 has direction (3,-1) (slope dy/dx = 3)", ratio == 3)
mu = Fr(w[0] + w[1]) / v(w, A1)
check("p_j/q_j = (rho+sigma)/v(A1) = 2/3, q_j = 3", mu == Fr(2, 3) and mu.denominator == 3)
check("en(F_j) = (2/3) A1 = (6,16) is integral", (mu * A1[0], mu * A1[1]) == (6, 16))
check("v_{1,1}(A0) = 45, degrees (45m,45n) = (90,135) for (m,n)=(2,3)",
      A0[0] + A0[1] == 45 and (45 * 2, 45 * 3) == (90, 135))
check("vertical edge: (36-24)/3 = 4 = deg p, ord_0 = 24/3 = 8", (36 - 24) // 3 == 4 and 24 // 3 == 8)

print("[B] Lemma 3.1 (examples)", flush=True)
y, kap = sp.symbols('y kappa')
def solve_F(p, N=4):
    h = sp.expand(y**8 * p)
    cs = sp.symbols('c0:%d' % (N + 1))
    f = sum(cs[i] * y**i for i in range(N + 1))
    expr = sp.expand(f * sp.diff(h, y) - 3 * sp.diff(f, y) * h - kap * h)
    eqs = sp.Poly(expr, y).all_coeffs()
    sols = sp.solve(eqs, list(cs) + [kap], dict=True)
    res = []
    for s in sols:
        kk = s.get(kap, kap)
        fs = sp.expand(f.subs(s))
        if fs != 0 and kk != 0:
            res.append((kk, fs, h))
    return res
random.seed(936)
n_dist = 0
for trial in range(12):
    rts = set()
    while len(rts) < 4:
        r = Fr(random.randint(-30, 30), random.randint(1, 7))
        if r != 0:
            rts.add(r)
    p = sp.Mul(*[(y - sp.Rational(r.numerator, r.denominator)) for r in rts])
    if solve_F(p) == []:
        n_dist += 1
check("p with 4 distinct roots: no F with deg f <= 4 (12 random examples)", n_dist == 12)
# controls with fewer distinct roots
c = sp.Rational(5, 3)
sol4 = solve_F((y - c)**4)
check("control p=(y-c)^4: F exists, deg f = 4", len(sol4) >= 1 and all(sp.degree(fs, y) == 4 for _, fs, _ in sol4))
def simple_roots_ok(fs, h):
    for r in sp.roots(sp.Poly(h, y)).keys():
        if fs.subs(y, r) != 0:
            return False
        if sp.diff(fs, y).subs(y, r) == 0:
            return False
    return True
check("control: f has a simple root at each root of h", all(simple_roots_ok(fs, h) for _, fs, h in sol4))
# local lemma on generic small examples with ord_0 h = 8 and other patterns (any degree up to 8)
loc_ok = True
for p in [(y - 2)**2 * (y + 3) * (y - 5), (y - 2)**2 * (y + 3)**2, (y - 2)**3 * (y + 1), (y + 7)**4]:
    for kk, fs, h in solve_F(p, N=8):
        loc_ok = loc_ok and simple_roots_ok(fs, h)
check("local lemma on all solutions found for patterns 211, 22, 31, 4 (deg f <= 8)", loc_ok)

print("[C] Lemma 4.2: the points (9,3k)", flush=True)
def is_wp_form(a, b):
    # (a,b) = wp (n', n'-1) with wp >= 1, n' >= 2
    if a - b <= 0:
        return False
    wp = a - b
    return a % wp == 0 and a // wp >= 2 and b == wp * (a // wp - 1)
def remark_319(a, b):
    # GGV2 Remark 3.19: a > b > 0 and a - 2b > 0 => possible last lower corner
    return a > b > 0 and a - 2 * b > 0
pts = {k: (9, 3 * k) for k in range(1, 5)}
check("k=2: (9,6) below the diagonal and = 3*(3,2) (GGV2 Prop. 3.29)", 9 > 6 and is_wp_form(9, 6) and (9, 6) == (3 * 3, 3 * 2))
check("k=3: (9,9) aligned with (1,1)", 9 * 1 - 9 * 1 == 0)
check("k=4: (9,12) above the diagonal (v_{1,-1} < 0)", 9 - 12 < 0)
check("k=1: (9,3) is a possible last lower corner (Remark 3.19), not excluded by Lemma 4.2",
      remark_319(9, 3) and not is_wp_form(9, 3))

print("[D] partitions of 4 into at most 3 parts", flush=True)
def partitions(n, maxpart=None):
    if maxpart is None:
        maxpart = n
    if n == 0:
        yield ()
        return
    for k in range(min(n, maxpart), 0, -1):
        for rest in partitions(n - k, k):
            yield (k,) + rest
parts = [q for q in partitions(4) if len(q) <= 3]
check("partitions: (4),(3,1),(2,2),(2,1,1)", sorted(parts) == sorted([(4,), (3, 1), (2, 2), (2, 1, 1)]))
check("each has a part in {2,3,4}", all(any(k in (2, 3, 4) for k in q) for q in parts))
check("(1,1,1,1) is the only partition of 4 without such a part", [q for q in partitions(4) if not any(k in (2, 3, 4) for k in q)] == [(1, 1, 1, 1)])

print("[E] rows of [GGV4, Section 6] with first corner (9,36), max degree 135", flush=True)
# transcribed from arXiv:1708.07936v1, Section 6 (tables of chains of length 1 and 2)
rows = [
    (("9", "36"), ("17/9", "4"), (3, 2), 135),
    (("9", "36"), ("17/9", "4"), (2, 3), 135),
    (("9", "36"), ("9", "24"), ("11/3", "8"), (2, 3), 135),
]
check("no listed row (9,36),(9,12)", all(r[1] != ("9", "12") for r in rows))
check("the chain of the standing data is listed", any(r[:3] == (("9", "36"), ("9", "24"), ("11/3", "8")) for r in rows))

print("[F] remark: chain (12,36),(12,33),(11/3,8)", flush=True)
B1, B2 = (Fr(12), Fr(33)), (Fr(11, 3), Fr(8))
muB = Fr(2) / v((3, -1), B1)
check("q_j = 3, d | gcd(12,33) = 3, vertical factor of degree (36-33)/3 = 1", muB == Fr(2, 3) and (36 - 33) // 3 == 1)
check("translation gives (12,3), a possible last lower corner (not excluded)", remark_319(12, 3) and not is_wp_form(12, 3))

print("", flush=True)
print("ALL CHECKS PASSED" if ok_all else "SOME CHECK FAILED", flush=True)
