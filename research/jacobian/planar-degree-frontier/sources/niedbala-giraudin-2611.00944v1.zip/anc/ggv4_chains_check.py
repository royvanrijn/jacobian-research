# ggv4_chains_check.py -- ancillary file of the note
#   "A shape of maximal degree 135 in the plane Jacobian problem:
#    exclusion of the complete chain (9,36), (9,24), (11/3,8)"
# Author: David Niedbala Giraudin (Independent researcher, France), ORCID 0009-0009-1526-1178.
# Prepared with AI assistance (Claude, Anthropic). Nothing here has been checked by a third party.
#
# Cross-check of the case k=4 of Lemma 4.2 (NOT part of the proof, which uses the published list
# of [GGV4, Section 6]): an independent reimplementation, written from the text of
# arXiv:1708.07936v1, Sections 1-2, of the algorithms GetPossibleLastLowerCorners,
# GetGeneratedCorners, GetCornerChildrenList, GetChildrenAndFinalList and GetCompleteChains,
# with the definition of valid edges checked on every edge produced.
# It prints: the valid edge ((9,36),(9,12)) generates no complete chain; and, as regression,
# the published chains through (9,24), (8,28), (12,33) and (12,30) are recovered.
# Requirements: python3 (standard library only).  Run time: a few seconds.
import sys
from fractions import Fraction as Fr
from math import gcd, lcm, floor, sqrt, isqrt
import sys

def less(w1,w2):            # w1 < w2 in the counterclockwise order (on a half plane)
    return w1[0]*w2[1]-w1[1]*w2[0] > 0
def prim(dx,dy):            # dir: primitive (rho,sigma) prop. to (dy,-dx)
    s=lcm(Fr(dx).denominator,Fr(dy).denominator)
    r,q=int(Fr(dy)*s),int(-Fr(dx)*s); g=gcd(r,q); return (r//g,q//g)
def v(w,P): return w[0]*Fr(P[0])+w[1]*Fr(P[1])
def pt(c): a,l,b=c; return (Fr(a,l),Fr(b))      # corner (a/l,b) -> point
def omega(n):
    k=0;p=2
    while p*p<=n:
        while n%p==0: n//=p;k+=1
        p+=1
    return k+(n>1)

# ---------- Algorithm 1: PLLC ----------
def pllc(xmax):
    PFL=[];PL=set()
    for a in range(1,xmax+1):
        b=0
        while b <= (2*a-sqrt(4*a-3)-1)/2 + 1e-12:
            # exact version of the bound: b<=(a-b-1)^2 with b<a
            if not (b<a and b<=(a-b-1)**2): b+=1; continue
            if b==0:
                PFL.append(((a,b),(0,-1)));PL.add((a,b))
            elif a>2*b>0:
                PFL.append(((a,b),(1,-2)));PL.add((a,b))
            else:
                wab=(1,-1)
                for (rs,wrs) in PFL:
                    r,s=rs
                    if r<a and s<b and r-s<a-b:
                        N1=gcd(a-r,b-s);N2=gcd(r,s)
                        w=((b-s)//N1,(r-a)//N1)
                        g=gcd(w[0]+w[1],w[0]*a+w[1]*b)
                        th=(w[0]*a+w[1]*b)//g
                        if less(wrs,w) and less(w,wab) and w[0]*a+w[1]*b>=w[0] and (th<=N1 or (N2%th==0 if th>0 else False)):
                            wab=w
                if less(wab,(1,-1)):
                    PFL.append(((a,b),wab));PL.add((a,b))
            b+=1
    return PL
PLLC=pllc(200)

# ---------- valid edge (Definition 2.2), checked independently ----------
def is_valid(A,Ap):
    a,l,b=A; ap,lp,bp=Ap; assert l==lp
    P,Pp=pt(A),pt(Ap)
    w=prim(P[0]-Pp[0],P[1]-Pp[1])
    if not (less((1,-1),w) and (w==(1,0) or less(w,(1,0)))): return False   # w in ](1,-1),(1,0)]
    if not (v((1,-1),Pp)!=0 and v((1,-1),P)<0 and v((1,-1),P)<v((1,-1),Pp)): return False
    d=gcd(a,b); bb=b//d
    mu=Fr(w[0]+w[1])/v(w,P)*d
    if mu.denominator!=1 or mu<=0: return False
    mu=int(mu)
    if not (mu<= l*(b*l-a)+Fr(1,bb) and mu%d!=0 and (l>1 or mu<d)): return False
    if l==1 and v((1,-1),Pp)>0:
        if not (Pp[0].denominator==1 and (int(Pp[0]),int(Pp[1])) in PLLC): return False
    return True
def enF(A,Ap):
    a,l,b=A; P,Pp=pt(A),pt(Ap); w=prim(P[0]-Pp[0],P[1]-Pp[1])
    t=Fr(w[0]+w[1])/v(w,P); return (t*P[0],t*P[1]),w
def gapf(rho,l): return rho//gcd(rho,l)
def is_simple(A,Ap):
    F,w=enF(A,Ap); g=gapf(w[0],A[1])
    return F[1]-1==g and (g>1 or pt(Ap)[1]>0)

# ---------- GetGeneratedCorners ----------
def generated(A,Ap):
    a,l,b=A; ap,_,bp=Ap; P,Pp=pt(A),pt(Ap)
    rho,sig=prim(P[0]-Pp[0],P[1]-Pp[1])
    if v((1,-1),Pp)<0: return [Ap]
    out=[]
    l1=lcm(rho,l); g=gapf(rho,l)
    gm=min(Fr(b-bp,g),Fr(b-1)); assert gm.denominator==1; gm=int(gm)
    rng=[gm] if is_simple(A,Ap) else range(bp+1,gm+1)
    for b1 in rng:
        a1=Fr(a*l1,l)+(b1-b)*Fr(-sig*l1,rho); assert a1.denominator==1; a1=int(a1)
        A1=(a1,l1,b1)
        cond2 = (l1-Fr(a1,b1)>1) or gcd(a1,b1)>1
        if is_simple(A,Ap):
            if cond2: out.append(A1)      # algorithm line (simple branch); v11<0 proven in Prop 2.7
        elif v((1,-1),pt(A1))<0 and cond2: out.append(A1)
    return out
def is_final(A1): a1,l1,b1=A1; return b1>0 and l1-Fr(a1,b1)>1

# ---------- GetCornerChildrenList ----------
def children(A,Ap,A1):
    P,Pp=pt(A),pt(Ap); w=prim(P[0]-Pp[0],P[1]-Pp[1])
    a1,l1,b1=A1; d1=gcd(a1,b1); P1=pt(A1)
    lo=floor(1+Fr(d1*(w[0]+w[1]))/v(w,P1))
    hi=d1 if l1==1 else floor(l1*(b1*l1-a1)+Fr(d1,b1))
    out=[]
    for mu in range(lo,hi+1):
        F=(Fr(mu,d1)*P1[0],Fr(mu,d1)*P1[1])
        w1=prim(F[0]-1,F[1]-1); g=gapf(w1[0],l1)
        if g<=b1 and mu%d1!=0:
            for j in range(1,b1//g+1):
                Q=(P1[0]+j*g*Fr(w1[1],w1[0]), P1[1]-j*g)
                vq=v((1,-1),Q)
                ok=(l1>1 and vq!=0) or (l1==1 and vq<0) or (l1==1 and vq>0 and Q[0].denominator==1 and (int(Q[0]),int(Q[1])) in PLLC)
                if ok:
                    num=Q[0]*l1; assert num.denominator==1
                    A1p=(int(num),l1,int(Q[1]))
                    assert less(w1,w), "child direction not smaller"
                    assert is_valid(A1,A1p), ("child not valid",A1,A1p)
                    out.append((A1,A1p))
    return out
def children_and_finals(A,Ap):
    ch=[];fi=[]
    for A1 in generated(A,Ap):
        if is_final(A1): fi.append(A1)
        else: ch+=children(A,Ap,A1)
    return ch,fi
def complete_chains(A,Ap):
    P,Pp=pt(A),pt(Ap); w=prim(P[0]-Pp[0],P[1]-Pp[1])
    q=Fr(A[2]-Ap[2],w[0]); assert q.denominator==1
    Lmax=omega(gcd(A[2],int(q)))+1
    openc=[((A,Ap),)];comp=[];counts=[1]
    for _ in range(Lmax):
        nxt=[]
        for ch in openc:
            c,f=children_and_finals(*ch[-1])
            comp+=[ch+(x,) for x in f]; nxt+=[ch+(x,) for x in c]
        openc=nxt;counts.append(len(openc))
    return comp,counts,Lmax
def starting_edges(a,b):
    d=gcd(a,b);out=[]
    for mu in range(1,d):
        F=(Fr(mu*a,d),Fr(mu*b,d)); w=prim(F[0]-1,F[1]-1)
        for i in range(1,b//w[0]+1):
            Q=(a-i*(-w[1]),b-i*w[0])
            vq=Q[0]-Q[1]
            if vq<0 or (vq>0 and Q in PLLC): out.append(((a,1,b),(Q[0],1,Q[1])))
    return out
def fmt(c): a,l,b=c; x=Fr(a,l); return "(%s,%d)"%(x,b)
def fmtchain(ch): return " -> ".join("["+fmt(e[0])+","+fmt(e[1])+"]" if isinstance(e[0],tuple) else fmt(e) for e in ch)

if __name__=="__main__":
    ok=True
    E=((9,1,36),(9,1,12))
    comp,counts,L=complete_chains(*E)
    print("valid edge ((9,36),(9,12)):",is_valid(*E),"; generated corners:",[fmt(c) for c in generated(*E)])
    print("Lmax =",L,"; open chains per level:",counts,"; complete chains:",len(comp))
    ok = ok and is_valid(*E) and len(comp)==0
    print("PLLC: (9,6)",(9,6) in PLLC,"(8,4)",(8,4) in PLLC,"(12,3)",(12,3) in PLLC,"(9,3)",(9,3) in PLLC)
    ok = ok and (9,6) not in PLLC and (8,4) not in PLLC and (12,3) in PLLC
    published={((9,1,36),(9,1,24)):"(11/3,8)",((8,1,32),(8,1,28)):"(11/4,7)",((12,1,36),(12,1,33)):"(11/3,8)",((12,1,36),(12,1,30)):"(16/3,10)"}
    for (A,Ap),last in published.items():
        comp,counts,L=complete_chains(A,Ap)
        ends=[fmt(c[-1]) for c in comp]
        print("regression",fmt(A),fmt(Ap),": final corners",ends)
        ok = ok and last in ends
    print("ALL CROSS-CHECKS PASSED" if ok else "SOME CROSS-CHECK FAILED", flush=True)
