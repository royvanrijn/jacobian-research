"""
verify_150.py -- ancillary file of the note
  "A shape of maximal degree 150 in the plane Jacobian problem: the point (18/5,8)
   is not a regular corner"
Author : David Niedbala Giraudin (Independent researcher, France)
ORCID  : 0009-0009-1526-1178
Prepared with AI assistance (Claude, Anthropic).

Exact rational arithmetic, Python standard library only (module fractions).
It checks the arithmetic used in the note, for (m,n) = (3,2):
  * type_I(a,b,l)  : for a corner (a/l,b), the direction (rho,sigma) forced by
        m*v(A) = m/(m+n)*(rho+sigma)   (v(P)+v(Q)=rho+sigma, v(P)/v(Q)=m/n, en(P)=m*A)
    and the starting points allowed by [GGV1, Proposition 5.13]:
        I.a)  (1/m) st(P) = (a'/l,0),  a' a positive integer;
        I.b)  {st(P),st(Q)} = {(k/l,0),(1-k/l,1)},  k a positive integer.
  * type_II(a,b,l,below) : the directions allowed by [GGV1, Proposition 5.14(2),(3),(4)]
    for a corner of type II, in the interval I = ](1,-1),(1,0)], strictly smaller than the
    direction `below` (no restriction if below is None).
It does not prove the propositions quoted in the note.
Run:  python3 verify_150.py      (immediate)
"""
from fractions import Fraction as Fr
from math import gcd
m,n=3,2
ok=True
def check(name,cond):
    global ok
    print(("PASS  " if cond else "FAIL  ")+name); ok = ok and bool(cond)
def type_I(a,b,l):
    c1=Fr(a,l)-Fr(1,m+n); c2=Fr(b)-Fr(1,m+n)        # c1*rho + c2*sigma = 0
    r,s=c2,-c1
    den=r.denominator*s.denominator//gcd(r.denominator,s.denominator)
    R,S=int(r*den),int(s*den); g=gcd(abs(R),abs(S)); R//=g; S//=g
    assert R>0 and S<0 and R+S>0
    vP=Fr(m,m+n)*(R+S); vQ=Fr(n,m+n)*(R+S)
    out=[]
    ap=vP*l/(m*R)
    if ap.denominator==1 and ap>0: out.append(('I.a',int(ap)))
    for nm,val in (('I.b, st(Q)=(k/l,0)',vQ),('I.b, st(P)=(k/l,0)',vP)):
        k=val*l/R
        if k.denominator==1 and k>0: out.append((nm,int(k)))
    return (R,S),out
def type_II(a,b,l,below):
    d=gcd(a,b)
    if d==1: return []
    ab,bb=a//d,b//d; res=[]; mu=1
    while mu<=l*(b*l-a)+Fr(1,bb):          # bound of [GGV1, Prop. 5.14(4)], with bb = b/d
        if mu%d!=0:
            X,Y=mu*ab-l,mu*bb*l-l                   # (rho,sigma) = dir(X,Y): rho*X+sigma*Y=0
            R,S=Y,-X
            g=gcd(abs(R),abs(S))
            if g:
                R//=g; S//=g
                if R>0 and S<=0 and R+S>0 and R//gcd(R,l)<=b and (below is None or Fr(S,R)<Fr(below[1],below[0])):
                    res.append((mu,(R,S)))
        mu+=1
    return res
def dirI(a,b,l): return type_I(a,b,l)[0]
def noI(a,b,l): return type_I(a,b,l)[1]==[]
# --- the corner A1 = (18/5,8), l = 5 -------------------------------------------------------
check("A1=(18/5,8): Case I impossible (direction %s); Case II directions, among all of I: (5,-2) and (15,-4)"%(dirI(18,8,5),),
      noI(18,8,5) and sorted(d for mu,d in type_II(18,8,5,None))==[(5,-2),(15,-4)])
check("A1, direction (5,-2): right-hand side of (5.9) is 2, so every root (multiplicity 3*mu >= 3) satisfies it",
      Fr(m,5)*Fr(18*5+8*5*(-2),5-2)==2)
check("A1, direction (5,-2): the edge line meets the first axis at (2/5,0); C_mu = ((2+2mu)/5, mu)",
      Fr(18,5)-8*Fr(2,5)==Fr(2,5))
# --- corners C_mu, l = 5, direction smaller than (5,-2) -------------------------------------
check("C_1=(4/5,1): l-a/b = 1 is not > 1 and gcd(4,1)=1", 5-Fr(4,1)==1 and gcd(4,1)==1)
check("C_2=(6/5,2): Case I impossible (direction %s); Case II below (5,-2): only (2,-1)"%(dirI(6,2,5),),
      noI(6,2,5) and [d for mu,d in type_II(6,2,5,(5,-2))]==[(2,-1)])
check("C_4=(10/5,4): Case I impossible (direction %s); Case II below (5,-2): none"%(dirI(10,4,5),),
      noI(10,4,5) and type_II(10,4,5,(5,-2))==[])
check("C_5=(12/5,5): Case I impossible (direction %s); gcd(12,5)=1"%(dirI(12,5,5),), noI(12,5,5) and gcd(12,5)==1)
check("C_7=(16/5,7): Case I impossible (direction %s); gcd(16,7)=1"%(dirI(16,7,5),), noI(16,7,5) and gcd(16,7)==1)
check("A1=C_8=(18/5,8): no Case II direction smaller than (5,-2) (Lemma 3.1(a))", noI(18,8,5) and type_II(18,8,5,(5,-2))==[])
check("C_3=(8/5,3): Case I is possible (direction %s) -- the final corner of the list"%(dirI(8,3,5),), not noI(8,3,5))
# --- C_2 in Case II, direction (2,-1) ----------------------------------------------------------
check("C_2, direction (2,-1): A' = C_2 - h(1/2,1) in (1/5)Z x N_0 only for h=2: A'=(1/5,0)",
      [h for h in (1,2) if ((Fr(6,5)-Fr(h,2))*5).denominator==1]==[2] and Fr(6,5)-1==Fr(1,5))
check("C_2, direction (2,-1): right-hand side of (5.9) is 6/5 <= 3", Fr(m,5)*Fr(6*2+2*5*(-1),2-1)==Fr(6,5))
check("next corner (7/10,1), l=10: Case I impossible (direction %s); gcd(7,1)=1"%(dirI(7,1,10),), noI(7,1,10) and gcd(7,1)==1)
# --- the count for the direction (5,-2) --------------------------------------------------------
def sums(h):
    return any(h==3*i+6*j for i in range(0,4) for j in range(0,3) if i+j>0)
check("direction (5,-2): h = 8-b' is a sum of 3's and 6's only for h=3 and h=6, i.e. A'=(12/5,5) or (6/5,2)",
      [h for h in range(1,9) if sums(h)]==[3,6] and Fr(18,5)-3*Fr(2,5)==Fr(12,5) and Fr(18,5)-6*Fr(2,5)==Fr(6,5))
check("both are below the diagonal: 12/5 < 5 and 6/5 < 2", Fr(12,5)<5 and Fr(6,5)<2)
# --- the direction (15,-4) -----------------------------------------------------------------------
check("direction (15,-4): A' = A1 - h(4/15,1) in (1/5)Z x N_0 only for h=3,6: A'=(14/5,5) or (2,2)",
      [h for h in range(1,9) if ((Fr(18,5)-h*Fr(4,15))*5).denominator==1]==[3,6]
      and Fr(18,5)-3*Fr(4,15)==Fr(14,5) and Fr(18,5)-6*Fr(4,15)==2)
check("(14/5,5), l=5: below the diagonal, Case I impossible (direction %s), gcd(14,5)=1"%(dirI(14,5,5),),
      Fr(14,5)<5 and noI(14,5,5) and gcd(14,5)==1)
# --- the corollary -------------------------------------------------------------------------------
dA=(Fr(10)-Fr(18,5),Fr(40)-8)
check("corollary: A0-A1 = (32/5,32) is proportional to (1/5,1), so (rho0,sigma0)=(5,-1) and l1 = lcm(5,1) = 5; (18/5,8) is not in Z x N_0",
      dA==(Fr(32,5),32) and 5*dA[0]-1*dA[1]==0 and Fr(18,5).denominator!=1)
check("control: the direction (1,0) of I is taken into account (it occurs at C_4 for mu=1)", (1,(1,0)) in type_II(10,4,5,None))
# --- control ---------------------------------------------------------------------------------------
check("control: the corner (11/6,3) of the note on (126,84) is recognised as possible in Case I",
      type_I(11,3,6)==((12,-7),[('I.b, st(Q)=(k/l,0)',1)]))
print("ALL CHECKS PASSED" if ok else "SOME CHECK FAILED")
