"""
verify_88_132.py -- ancillary file of the note
  "The degree pair (88,132) in the plane Jacobian problem: exclusion of the shape
   with starting corner (11,33) and final corner (19/4,8)"
Author : David Niedbala Giraudin (Independent researcher, France)
ORCID  : 0009-0009-1526-1178
Prepared with AI assistance (Claude, Anthropic).

Exact arithmetic with SymPy (rational numbers and the field Q(sqrt(-3))); three steps, marked
[Singular], use Groebner bases computed by the program Singular (https://www.singular.uni-kl.de):
the script writes their input files and runs them if `Singular` is on the PATH, and otherwise
reports them as NOT CHECKED.
  1. arithmetic of Lemma 2.1 (roots) and Lemma 4.1 (corner);
  2. leading terms of Lemma 5.1 (coordinates);
  3. Lemma 6.1: the equation of order 0 and its two solutions;
  4. Proposition 6.2: the linear systems of orders 1..12, the three free coefficients, the six
     compatibility conditions, and the fact that they generate the unit ideal;
  5. control: the same computation without the boundary condition (S3) is consistent.
It does not prove the results quoted in the note.
Run:  python3 verify_88_132.py        (a few seconds)
"""
import sympy as sp, time, shutil, subprocess, os
from sympy import QQ, ring, Rational as R
from sympy.polys.matrices import DomainMatrix
from fractions import Fraction as Fr
from math import gcd, comb
from collections import defaultdict
ok=True; count=0
def check(name,cond):
    global ok,count
    count+=1
    print(("PASS  " if cond else "FAIL  ")+name, flush=True); ok = ok and bool(cond)
m,n=2,3
def type_I(a,b,l):
    c1=Fr(a,l)-Fr(1,m+n); c2=Fr(b)-Fr(1,m+n)
    r,s=c2,-c1
    den=r.denominator*s.denominator//gcd(r.denominator,s.denominator)
    Rr,S=int(r*den),int(s*den); g=gcd(abs(Rr),abs(S)); Rr//=g; S//=g
    vP=Fr(m,m+n)*(Rr+S); vQ=Fr(n,m+n)*(Rr+S)
    out=[]
    ap=vP*l/(m*Rr)
    if ap.denominator==1 and ap>0: out.append(('I.a',int(ap)))
    for nm,val in (('st(Q)=(k/l,0)',vQ),('st(P)=(k/l,0)',vP)):
        k=val*l/Rr
        if k.denominator==1 and k>0: out.append((nm,int(k)))
    return (Rr,S),(vP,vQ),out
# ---------------- 1. arithmetic ----------------
check("corner (11,33), direction (4,-1), l=1: right-hand side of (5.9) is 22/3, so 2k >= 22/3 means k >= 4",
      Fr(m,1)*Fr(11*4+33*(-1),4-1)==Fr(22,3) and 2*3<Fr(22,3)<=2*4)
check("(11/4,0)+k(1/4,1) = (15/4,4), (16/4,5), (17/4,6), (18/4,7), (19/4,8) for k = 4..8",
      [(Fr(11+k,4),k) for k in range(4,9)]==[(Fr(15,4),4),(4,5),(Fr(17,4),6),(Fr(9,2),7),(Fr(19,4),8)])
for k in range(4,8):
    d,v,o=type_I(11+k,k,4)
    check("(%d/4,%d), l=4: Case I impossible (direction %s, v(P)=%s, v(Q)=%s); gcd(%d,%d)=1"%(11+k,k,d,v[0],v[1],11+k,k), o==[] and gcd(11+k,k)==1)
d,v,o=type_I(19,8,4)
check("(19/4,8), l=4: Case I direction (12,-7), v(P1)=2, v(Q1)=3, only st(Q1)=(1/4,0), st(P1)=(3/4,1); gcd(19,8)=1",
      d==(12,-7) and v==(2,3) and o==[('st(Q)=(k/l,0)',1)] and gcd(19,8)==1 and 12*Fr(3,4)-7==2)
check("Case III directions strictly between (12,-7) and (4,-1) with rho' dividing 4: only (2,-1)",
      [(r,-j) for r in (1,2,4) for j in range(0,4*r+1) if gcd(r,j)==1 and Fr(-7,12)<Fr(-j,r)<Fr(-1,4)]==[(2,-1)])
check("W(X^i eta^j) = 3i-7j: X^3 eta, X^38 eta^16 have W=2; X, X^57 eta^24 have W=3", [9-7,3*38-112,3,3*57-168]==[2,2,3,3])
# ---------------- 2. coordinates ----------------
X,eta,lam,l2,gam=sp.symbols('X eta lambda lambda2 gamma')
def wt(term):
    pw=term.as_powers_dict(); return 3*pw.get(X,0)-7*pw.get(eta,0)
def trunc(e,wm): return sp.Add(*[t for t in sp.Add.make_args(sp.expand(e)) if wt(t)>=wm])
def layers(e):
    by=defaultdict(int)
    for t in sp.Add.make_args(sp.expand(e)): by[wt(t)]+=t
    return {k:sp.factor(val) for k,val in by.items() if sp.simplify(val)!=0}
Y=eta+lam/X+l2/X**2; u=sp.expand(Y*X); dd=u-lam
inv=sum((-dd/lam)**k for k in range(8))/lam
zi=trunc(X*u**3-gam*Y,-9); vi=trunc(X*inv,-9)
Lv=layers(vi); Lz=layers(trunc(zi-lam**4*vi-4*lam**2*l2,-9))
check("image of v = 1/Y: W = 3, leading term X/lambda", max(Lv)==3 and sp.simplify(Lv[3]-X/lam)==0)
check("image of zeta = z - c v - kappa (c=lambda^4, kappa=4 lambda^2 lambda2): W = -1, leading term 4 lambda^2 eta X^2; next weight -3",
      sorted(Lz,reverse=True)[:2]==[-1,-3] and sp.simplify(Lz[-1]-4*lam**2*eta*X**2)==0)
# ---------------- 3. order 0 ----------------
A=sp.symbols('a1:6'); H=sp.symbols('h1:9'); tt=sp.Symbol('t')
aa=[sp.Integer(1)]+list(A); hh=[sp.Integer(1)]+list(H)
def eq(k,aa,hh): return sum((5*i-2*k+1)*aa[i]*hh[k-i] for i in range(6) if 0<=k-i<=8)
zz,vv=sp.symbols('zeta v'); ss=zz**3*vv
GP=zz*vv*sum(aa[i]*ss**i for i in range(6)); GQ=vv*sum(hh[j]*ss**j for j in range(9))
B0=sp.Poly(sp.expand(sp.diff(GP,zz)*sp.diff(GQ,vv)-sp.diff(GP,vv)*sp.diff(GQ,zz)-vv),zz,vv)
check("order 0: {zeta v p(s), v q(s)} - v has the coefficients sum_i (5i-2k+1) a_i h_(k-i), k = 1..12 (s = zeta^3 v)",
      all(sp.expand(B0.coeff_monomial(zz**(3*k)*vv**(k+1))-eq(k,aa,hh))==0 for k in range(1,13)) and B0.coeff_monomial(vv)==0 and len(B0.terms())==12)
exe=shutil.which('Singular')
here=os.path.dirname(os.path.abspath(__file__))
def singular(fn):
    return subprocess.run([exe,'-q',fn],stdin=subprocess.DEVNULL,capture_output=True,text=True).stdout.split()
names0=['h%d'%j for j in range(8,0,-1)]+['a4','a3','a2','a5','t']
a1one=[sp.Integer(1),sp.Integer(1)]+list(A[1:])
src='// equations of order 0 with a1 = 1 and a5*t = 1\nring r=0,(%s),dp;\noption(redSB);\nideal I=\n'%','.join(names0)
src+=',\n'.join(str(sp.expand(eq(k,a1one,hh))).replace('**','^') for k in range(1,13))+',\na5*t-1;\nideal G=std(I);\n'
src+='print("DIM");print(dim(G));print(vdim(G));print("RED");print(reduce(150994944*t^2-314828451840*t+1291756832812537,G));\nquit;\n'
fn0=os.path.join(here,'order0_88_132.sing'); open(fn0,'w').write(src)
if exe is None:
    print("NOT CHECKED  uniqueness in Lemma 6.1 (needs Singular; input file order0_88_132.sing written; expected output: DIM 0 2 RED 0)",flush=True)
else:
    check("order 0 with a1 = 1 and a5 != 0 [Singular]: exactly two solutions (dimension 0, degree 2), and T = 1/a5 is a root of 150994944 T^2 - 314828451840 T + 1291756832812537",
          singular(fn0)==['DIM','0','2','RED','0'])
a1zero=[sp.Integer(1),sp.Integer(0)]+list(A[1:])
srcz='// equations of order 0 with a1 = 0 and a5*t = 1\nring r=0,(%s),dp;\noption(redSB);\nideal I=\n'%','.join(names0)
srcz+=',\n'.join(str(sp.expand(eq(k,a1zero,hh))).replace('**','^') for k in range(1,13))+',\na5*t-1;\nideal G=std(I);\nprint("SIZE");print(size(G));print("FIRST");print(G[1]);\nquit;\n'
fnz=os.path.join(here,'order0_a1zero_88_132.sing'); open(fnz,'w').write(srcz)
if exe is None:
    print("NOT CHECKED  a1 != 0 in Lemma 6.1 (needs Singular; input file order0_a1zero_88_132.sing written; expected output: SIZE 1 FIRST 1)",flush=True)
else:
    check("order 0 [Singular]: no solution with a1 = 0 and a5 != 0 (Groebner basis {1})", singular(fnz)==['SIZE','1','FIRST','1'])
disc=314828451840**2-4*150994944*1291756832812537
check("its discriminant is -3 * 476472471552^2: the solutions lie in Q(sqrt(-3))", disc==-3*476472471552**2)
Kf=QQ.algebraic_field(sp.sqrt(-3)); c=Kf.convert
T=Kf.from_sympy((314828451840+476472471552*sp.sqrt(-3))/(2*150994944))
iT=Kf.one/T
a=[Kf.one,Kf.one,(c(33207559840)-c(1179648)*T)/c(87282533261),(c(9142619992576)-c(948436992)*T)/c(111808925107341),(c(35168631085056)-c(8204058624)*T)/c(4222117981434353),iT]
h=[Kf.one,c(4),(c(132959026424)-c(1179648)*T)/c(37406799969),(c(17130979691392)-c(721944576)*T)/c(10164447737031),(c(23190255008542720)-c(2265018531840)*T)/c(47742411020834607),
   (c(65536)*T+c(154611184))*iT/c(1175013),(c(6291456)*T+c(42564276664))*iT/c(1839678687),(c(132830239360)-c(4718592)*T)*iT/c(69469771371),(c(25761882159104)-c(5173673984)*T)*iT/c(484505342131811)]
check("the displayed solution (a_i, h_j) in Q(sqrt(-3)) satisfies the equations of order 0, with a1 = 1, h1 = 4, a5 = 1/T",
      all(sum((c(5*i-2*k+1)*a[i]*h[k-i] for i in range(6) if 0<=k-i<=8),Kf.zero)==Kf.zero for k in range(1,14)))
print("      a2..a5 =",[Kf.to_sympy(x) for x in a[2:]],flush=True)
Tb=Kf.from_sympy((314828451840-476472471552*sp.sqrt(-3))/(2*150994944)); iTb=Kf.one/Tb
ab=[Kf.one,Kf.one,(c(33207559840)-c(1179648)*Tb)/c(87282533261),(c(9142619992576)-c(948436992)*Tb)/c(111808925107341),(c(35168631085056)-c(8204058624)*Tb)/c(4222117981434353),iTb]
hb=[Kf.one,c(4),(c(132959026424)-c(1179648)*Tb)/c(37406799969),(c(17130979691392)-c(721944576)*Tb)/c(10164447737031),(c(23190255008542720)-c(2265018531840)*Tb)/c(47742411020834607),
   (c(65536)*Tb+c(154611184))*iTb/c(1175013),(c(6291456)*Tb+c(42564276664))*iTb/c(1839678687),(c(132830239360)-c(4718592)*Tb)*iTb/c(69469771371),(c(25761882159104)-c(5173673984)*Tb)*iTb/c(484505342131811)]
check("the same formulas with the other root T satisfy the equations of order 0 as well",
      all(sum((c(5*i-2*k+1)*ab[i]*hb[k-i] for i in range(6) if 0<=k-i<=8),Kf.zero)==Kf.zero for k in range(1,14)))
# ---------------- 4. the layers ----------------
DP,DQ,WP,WQ=22,33,2,3
W=lambda i,j: 3*j-i
SP=[(i,j) for i in range(DP+1) for j in range(DP+1) if i+j<=DP and W(i,j)<=WP]
SQ=[(i,j) for i in range(DQ+1) for j in range(DQ+1) if i+j<=DQ and W(i,j)<=WQ]
check("(S1): 89 possible monomials for P, 187 for Q; layer 0: 6 and 9 monomials", len(SP)==89 and len(SQ)==187 and
      sorted(x for x in SP if W(*x)==2)==[(3*i+1,i+1) for i in range(6)] and sorted(x for x in SQ if W(*x)==3)==[(3*j,j+1) for j in range(9)])
def run(K,boundary=True):
    knownP={(3*i+1,i+1):a[i] for i in range(6)}; knownQ={(3*j,j+1):h[j] for j in range(9)}
    if boundary:
        for j in range(7): knownP[(16+j,6-j)]=a[5]*c(comb(6,j))
    knownP[(0,0)]=Kf.zero; knownQ[(0,0)]=Kf.zero; knownQ[(16,6)]=Kf.zero
    kP={x:WP-W(*x) for x in SP}; kQ={x:WQ-W(*x) for x in SQ}
    pairs={}
    for (i,j) in SP:
        for (k,l) in SQ:
            co=i*l-j*k; lay=kP[(i,j)]+kQ[(k,l)]
            if co and 1<=lay<=K: pairs.setdefault(lay,[]).append(((i,j),(k,l),co))
    P0={x:knownP[x] for x in SP if kP[x]==0}; Q0={x:knownQ[x] for x in SQ if kQ[x]==0}
    struct={}; free=[]
    for lay in range(1,K+1):
        V=[('p',x) for x in SP if kP[x]==lay and x not in knownP]+[('q',x) for x in SQ if kQ[x]==lay and x not in knownQ]
        pos={x:i for i,x in enumerate(V)}
        targets=sorted({(i+k-1,j+l-1) for (i,j),(k,l),co in pairs.get(lay,[])}); tpos={t:i for i,t in enumerate(targets)}
        ne=len(targets); nV=len(V); Am=[[Kf.zero]*nV for _ in range(ne)]
        for (i,j),(k,l),co in pairs.get(lay,[]):
            r=tpos[(i+k-1,j+l-1)]
            if kQ[(k,l)]==0 and ('p',(i,j)) in pos: Am[r][pos[('p',(i,j))]]+=c(co)*Q0[(k,l)]
            if kP[(i,j)]==0 and ('q',(k,l)) in pos: Am[r][pos[('q',(k,l))]]+=c(co)*P0[(i,j)]
        M=DomainMatrix([Am[r]+[Kf.one if r==cc else Kf.zero for cc in range(ne)] for r in range(ne)],(ne,nV+ne),Kf)
        rows=M.rref()[0].to_list(); piv={}
        for r in range(ne):
            lead=next((cc for cc in range(nV) if rows[r][cc]!=Kf.zero),None)
            if lead is not None: piv[r]=lead
        fr=[V[cc] for cc in range(nV) if cc not in piv.values()]
        free+=fr; struct[lay]=(V,targets,tpos,rows,piv,fr)
    names=['%s_%d_%d'%(t,x[0],x[1]) for t,x in free]
    Rg,*G=ring(names,Kf,order='grevlex'); gi={x:G[i] for i,x in enumerate(free)}
    imgP={x:Rg.ground_new(val) for x,val in knownP.items()}; imgQ={x:Rg.ground_new(val) for x,val in knownQ.items()}
    conds=[]
    for lay in range(1,K+1):
        V,targets,tpos,rows,piv,fr=struct[lay]; ne=len(targets); nV=len(V)
        b=[Rg.zero for _ in range(ne)]
        for (i,j),(k,l),co in pairs.get(lay,[]):
            ip=imgP.get((i,j)); iq=imgQ.get((k,l))
            if ip is None or iq is None: continue
            r=tpos[(i+k-1,j+l-1)]; b[r]=b[r]-(ip*iq)*c(co)
        for x in fr: (imgP if x[0]=='p' else imgQ)[x[1]]=gi[x]
        for r in range(ne):
            tb=Rg.zero
            for cc in range(ne):
                if rows[r][nV+cc]!=Kf.zero: tb=tb+b[cc]*rows[r][nV+cc]
            if r in piv:
                e=tb
                for cc in range(nV):
                    if cc!=piv[r] and rows[r][cc]!=Kf.zero: e=e-gi[V[cc]]*rows[r][cc]
                x=V[piv[r]]; (imgP if x[0]=='p' else imgQ)[x[1]]=e
            elif tb!=Rg.zero: conds.append((lay,tb))
    return names,conds,Rg
t0=time.time(); names,conds,Rg=run(12)
check("orders 1..12: every linear system has its matrix in Q(sqrt(-3)); free coefficients q_23_8, q_24_8, q_22_7; six compatibility conditions, of orders 8, 9, 10, 11, 12, 12",
      names==['q_23_8','q_24_8','q_22_7'] and [k for k,_ in conds]==[8,9,10,11,12,12])
def cs(cf):
    L=cf.to_list(); nn=len(L)
    t=["(%s)%s"%(x,"*w" if nn-1-i==1 else "") for i,x in enumerate(L) if x!=0]
    return "("+"+".join(t)+")"
lines=[]
for k,cd in conds:
    lines.append("+".join(cs(cf)+"".join("*%s^%d"%(nm,e) for nm,e in zip(names,mon) if e) for mon,cf in cd.terms()))
fn=os.path.join(here,'conditions_88_132.sing')
open(fn,'w').write('// the six conditions of Proposition 6.2; w = sqrt(-3)\nring r=(0,w),(%s),dp;\nminpoly=w*w+3;\noption(redSB);\nideal I=\n'%','.join(names)+',\n'.join(lines)+';\nideal G=std(I);\nprint("SIZE");print(size(G));print("FIRST");print(G[1]);\nquit;\n')
if exe is None:
    print("NOT CHECKED  Proposition 6.2, last step (needs Singular; input file conditions_88_132.sing written; expected output: SIZE 1 FIRST 1)",flush=True)
else:
    check("Proposition 6.2 [Singular]: the six conditions generate the unit ideal of Q(sqrt(-3))[q_23_8, q_24_8, q_22_7] (Groebner basis {1})", singular(fn)==['SIZE','1','FIRST','1'])
# ---------------- 5. control ----------------
namesC,condsC,RgC=run(12,boundary=False)
symsC=sp.symbols(namesC)
check("control without (S3): %d free coefficients, %d conditions, all vanishing when the free coefficients are 0"%(len(namesC),len(condsC)),
      len(condsC)>0 and all(cd.as_expr().subs({x:0 for x in symsC})==0 for k,cd in condsC))
print("%d checks"%count)
print("ALL CHECKS PASSED" if ok else "SOME CHECK FAILED")
