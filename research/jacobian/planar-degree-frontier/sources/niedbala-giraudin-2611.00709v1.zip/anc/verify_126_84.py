"""
verify_126_84.py -- ancillary file of the note
  "The degree pair (126,84) in the plane Jacobian problem: the point (16/3,10)
   is not a regular corner"
Author : David Niedbala Giraudin (Independent researcher, France)
ORCID  : 0009-0009-1526-1178
Prepared with AI assistance (Claude, Anthropic).

Exact rational arithmetic, Python standard library only (module fractions).
It checks the arithmetic used in the note, for (m,n) = (3,2):
  * type_I(a,b,l)  : for a corner (a/l,b), the direction (rho,sigma) forced by
        m*v(A) = m/(m+n)*(rho+sigma)   (v(P)+v(Q)=rho+sigma, v(P)/v(Q)=m/n, en(P)=m*A)
    and the starting points allowed by [GGV1, Proposition 5.13]:
        I.a)  (1/m) st(P) = (a'/l,0),  a' a positive integer;
        I.b)  {st(P),st(Q)} = {(k/l,0),(1-k/l,1)},  k a positive integer.
  * type_II(a,b,l,below) : the directions allowed by [GGV1, Proposition 5.14(2),(3),(4)]
    for a corner of type II, strictly smaller than the direction `below`.
It does not prove the propositions quoted in the note.
Run:  python3 verify_126_84.py      (immediate)
"""
from fractions import Fraction as Fr
from math import gcd
m,n=3,2
ok=True
def check(name,cond):
    global ok
    print(("PASS  " if cond else "FAIL  ")+name); ok = ok and bool(cond)
def type_I(a,b,l):
    c1=Fr(a,l)-Fr(1,m+n); c2=Fr(b)-Fr(1,m+n)        # c1*rho + c2*sigma = 0
    r,s=c2,-c1
    den=r.denominator*s.denominator//gcd(r.denominator,s.denominator)
    R,S=int(r*den),int(s*den); g=gcd(abs(R),abs(S)); R//=g; S//=g
    assert R>0 and S<0 and R+S>0
    vP=Fr(m,m+n)*(R+S); vQ=Fr(n,m+n)*(R+S)
    out=[]
    ap=vP*l/(m*R)
    if ap.denominator==1 and ap>0: out.append(('I.a',int(ap)))
    for nm,val in (('I.b, st(Q)=(k/l,0)',vQ),('I.b, st(P)=(k/l,0)',vP)):
        k=val*l/R
        if k.denominator==1 and k>0: out.append((nm,int(k)))
    return (R,S),out
def type_II(a,b,l,below):
    d=gcd(a,b)
    if d==1: return []
    ab,bb=a//d,b//d; res=[]; mu=1
    while mu<=l*(b*l-a)+Fr(1,bb):          # bound of [GGV1, Prop. 5.14(4)], with bb = b/d
        if mu%d!=0:
            X,Y=mu*ab-l,mu*bb*l-l                   # (rho,sigma) = dir(X,Y): rho*X+sigma*Y=0
            R,S=Y,-X
            g=gcd(abs(R),abs(S))
            if g:
                R//=g; S//=g
                if R>0 and S<0 and R+S>0 and R//gcd(R,l)<=b and Fr(S,R)<Fr(below[1],below[0]):
                    res.append((mu,(R,S)))
        mu+=1
    return res
# --- the corner A1 = (16/3,10), l = 3 ----------------------------------------------------
check("A1=(16/3,10): a type I corner would have direction (21,-11), and no admissible starting point",
      type_I(16,10,3)==((21,-11),[]))
check("A1: a type II corner has direction (12,-5) (mu=1) or (2,-1) (mu=3), among all directions of I",
      type_II(16,10,3,(1,0))==[(1,(12,-5)),(3,(2,-1))])
check("A1, direction (12,-5): A' = A1 - h(5/12,1) lies in (1/3)Z x N_0 only for h=4,8: A'=(11/3,6) or (2,2)",
      [h for h in range(1,11) if ((Fr(16,3)-h*Fr(5,12))*3).denominator==1]==[4,8]
      and Fr(16,3)-4*Fr(5,12)==Fr(11,3) and Fr(16,3)-8*Fr(5,12)==2)
check("A'=(2,2) is on the diagonal; A'=(11/3,6), l=3: below the diagonal, gcd(11,6)=1, type I impossible (direction (87,-52))",
      Fr(11,3)<6 and gcd(11,6)==1 and type_I(11,6,3)==((87,-52),[]))
check("A1, direction (2,-1): right-hand side of (5.9) equals 2",
      Fr(m,3)*Fr(16*2+10*3*(-1),2-1)==2)
check("A1, direction (2,-1): A' = A1 - h(1/2,1) lies in (1/3)Z x N_0 only for h even",
      all(((Fr(16,3)-Fr(h,2))*3).denominator==1 for h in (2,4,6,8,10)) and
      all(((Fr(16,3)-Fr(h,2))*3).denominator!=1 for h in (1,3,5,7,9)))
# --- corners C_mu = (1/3,0)+mu(1/2,1) = ((2+3mu)/6, mu), l = 6 ---------------------------
check("C_1=(5/6,1): l-a/b = 1 is not > 1 and gcd(5,1)=1", 6-Fr(5,1)==1 and gcd(5,1)==1)
check("C_2=(8/6,2): type I impossible (direction (27,-17))", type_I(8,2,6)==((27,-17),[]))
check("C_2=(8/6,2): type II only with mu=5, direction (12,-7)", type_II(8,2,6,(2,-1))==[(5,(12,-7))])
check("C_2, direction (12,-7): the starting point is (1/6,0) (h=2; h=1 gives (9/12,1), not in (1/6)Z x N_0)",
      Fr(8,6)-2*Fr(7,12)==Fr(1,6) and ((Fr(8,6)-Fr(7,12))*6).denominator!=1)
check("C_2, direction (12,-7): right-hand side of (5.9) equals 6/5 <= 3",
      Fr(m,6)*Fr(8*12+2*6*(-7),12-7)==Fr(6,5))
check("next corner (9/12,1), l=12: gcd(9,1)=1 and type I impossible (direction (16,-11))",
      gcd(9,1)==1 and type_I(9,1,12)==((16,-11),[]))
check("C_3=(11/6,3): type I is possible (direction (12,-7), I.b with st(Q)=(1/6,0)) -- the corner of the list",
      type_I(11,3,6)==((12,-7),[('I.b, st(Q)=(k/l,0)',1)]))
check("C_4=(14/6,4): type I impossible (direction (57,-32)), type II impossible",
      type_I(14,4,6)==((57,-32),[]) and type_II(14,4,6,(2,-1))==[])
check("C_5=(17/6,5): type I impossible (direction (144,-79)), gcd(17,5)=1",
      type_I(17,5,6)==((144,-79),[]) and gcd(17,5)==1)
# --- the count ------------------------------------------------------------------------------
sums={bp:Fr(10-bp,2) for bp in (0,2,4,6,8)}
check("sum of the mu_i equals (10-b')/2 = 5,4,3,2,1 for b'=0,2,4,6,8: a sum of 3's only for b'=4",
      [bp for bp,s_ in sums.items() if s_>0 and s_%3==0]==[4])
check("A'=(7/3,4), l=3: below the diagonal (7/3<4), gcd(7,4)=1, type I impossible (direction (57,-32))",
      Fr(7,3)<4 and gcd(7,4)==1 and type_I(7,4,3)==((57,-32),[]))
# --- control ----------------------------------------------------------------------------------
m,n=2,3
check("control, (m,n)=(2,3): the final corner (19/7,5) of the companion note is recognised (direction (21,-11), st(Q)=(2/7,0))",
      type_I(19,5,7)==((21,-11),[('I.b, st(Q)=(k/l,0)',2)]))
print("ALL CHECKS PASSED" if ok else "SOME CHECK FAILED")
