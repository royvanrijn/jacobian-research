"""
verify_147.py -- ancillary verifier for the note
  "Two shapes of maximal degree 147 in the plane Jacobian problem:
   exclusion of the degree pairs (147,98) and (98,147) with corners (7,42) and (13/7,6)"

Author : David Niedbala Giraudin (Independent researcher, France), ORCID 0009-0009-1526-1178.
Prepared with AI assistance (Claude, Anthropic). Nothing here has been checked by a third party.

Requirements: Python 3 with SymPy, python-flint and cypari2; Singular (https://www.singular.uni-kl.de)
on the PATH for the steps marked [Singular]. Reads anc/leading_pair_147.txt (same folder).
Run:  python3 verify_147.py      (a few minutes)

Notation of the note: E = Q(a), a^6-2a^5-8a^4+10a^3+12a^2-48a+80 = 0. System (S1)-(S2):
  U = u3 v^3 + u2 v^2 + u1 v + u0 ,  V = w2 v^2 + w1 v + w0 ,  u_i, w_i in K[x],
  homogeneous parts of top degree (x+v)^3 x^18 and (x+v)^2 x^12,
  U_x V_v - U_v V_x = -J' v^4 .
Checks:
  1  Jacobian of x = z v^6 + g2 v^2 + ... + g5 v^5, y = 1/v is -v^4.
  2  Leading terms of the images of z and zeta = z - c v (Lemma 4.1), by series expansion.
  3  Equations (E4)-(E0) from the bracket.
  4  Identity (u3^2/w2^3)' = u3 W / w2^4 with W = 2 u3' w2 - 3 u3 w2'.
  5  The representative (u3*, w2*) over E: deg(u3*^2 - w2*^3) = 7, W constant = -29 d7 != 0,
     c9 = c10 != 0, and w = c8/c10^2 has an irreducible minimal polynomial of degree 6 over Q.
  6  [Singular] With d7 = 1, the ideal of the leading equation in b0..b10 has dimension 0 and
     degree 174 modulo three primes (a computational confirmation of the bound 174, which the note
     derives from the Davenport-Zannier / weighted tree correspondence; the computation over Q
     is optional, see RUN_COUNT_OVER_Q).
  6d The heptagon has 42 triangulations, in 6 rotation classes of size 7.
  7  Elimination over E (Proposition 5.2): ranks, free unknowns, 46 conditions;
     [Singular] they generate the unit ideal over E; the 13 conditions of (E1) alone as well;
     in fact 1 is an E-linear combination of these 13 conditions (rank test over E).
  8  Planted controls (two seeds) and a perturbed control for the elimination procedure.
  9  [Singular] Independent check: the full normalised system (84 unknowns, 126 equations),
     built by direct expansion, is inconsistent modulo a prime p at which the defining polynomial
     of E splits, for each of its 6 roots.
"""
import sys, os, re, time, random, itertools, subprocess, tempfile
import sympy as sp
import flint
import cypari2

HERE = os.path.dirname(os.path.abspath(__file__))
RUN_COUNT_OVER_Q = False   # Groebner basis over Q of the leading equation (long; optional)
pari = cypari2.Pari()
pari.allocatemem(2 * 10**9)

NPASS = [0]
def ok(cond, msg):
    if not cond:
        print("FAIL ", msg, flush=True)
        sys.exit(1)
    NPASS[0] += 1
    print("PASS ", msg, flush=True)

def singular(text):
    with tempfile.NamedTemporaryFile('w', suffix='.sing', delete=False, dir=HERE) as f:
        f.write(text)
        name = f.name
    try:
        out = subprocess.run(['Singular', '-q', name], stdin=subprocess.DEVNULL,
                             capture_output=True, text=True, timeout=1800).stdout
    finally:
        os.remove(name)
    return out.split()

FPOL = 'a^6-2*a^5-8*a^4+10*a^3+12*a^2-48*a+80'

# ---------------------------------------------------------------- 1. Jacobian
z, v = sp.symbols('z v')
g2, g3, g4, g5 = sp.symbols('g2:6')
X0 = z*v**6 + g2*v**2 + g3*v**3 + g4*v**4 + g5*v**5
Y0 = 1/v
jac = sp.simplify(sp.diff(X0, z)*sp.diff(Y0, v) - sp.diff(X0, v)*sp.diff(Y0, z))
ok(sp.simplify(jac + v**4) == 0, "1  dx^dy = -v^4 dz^dv for x = z v^6 + g2 v^2 + ... + g5 v^5, y = 1/v")

# ---------------------------------------------------------------- 2. right side
Xs, eta, lam, s = sp.symbols('X eta lambda s', nonzero=True)
c = lam**7
Y = eta + lam/Xs
zimg = Xs**7*Y**6 - (g2*Y**4 + g3*Y**3 + g4*Y**2 + g5*Y)
zetaimg = zimg - c/Y
def top(e, n=3):
    # substitute X -> s X, eta -> eta / s^2 : a monomial X^i eta^j gets the factor s^(i-2j) = s^W
    ser = sp.series(e.subs({Xs: s*Xs, eta: eta/s**2}, simultaneous=True), s, sp.oo, n).removeO()
    ser = sp.expand(ser)
    return {k: sp.simplify(ser.coeff(s, k)) for k in range(-2, 3)}
tz = top(zimg)
tq = top(zetaimg)
ok(sp.simplify(tz[1] - lam**6*Xs) == 0 and tz[2] == 0,
   "2a image of z: weight 1, leading term lambda^6 X")
ok(tq[2] == 0 and tq[1] == 0 and sp.simplify(tq[0] - 7*lam**5*eta*Xs**2) == 0,
   "2b image of zeta = z - c v (c = lambda^7): weight 0, leading term 7 lambda^5 eta X^2, no other term of weight >= 0")

# ---------------------------------------------------------------- 3. equations (E4)-(E0)
x = sp.Symbol('x')
u = [sp.Function('u%d' % i)(x) for i in range(4)]
w = [sp.Function('w%d' % i)(x) for i in range(3)]
U = sum(u[i]*v**i for i in range(4)); V = sum(w[i]*v**i for i in range(3))
Jp = sp.Symbol('Jp')
br = sp.expand(sp.diff(U, x)*sp.diff(V, v) - sp.diff(U, v)*sp.diff(V, x) + Jp*v**4)
d = lambda f: sp.diff(f, x)
E = {4: 2*d(u[3])*w[2] - 3*u[3]*d(w[2]) + Jp,
     3: d(u[3])*w[1] + 2*d(u[2])*w[2] - 3*u[3]*d(w[1]) - 2*u[2]*d(w[2]),
     2: d(u[2])*w[1] + 2*d(u[1])*w[2] - 3*u[3]*d(w[0]) - 2*u[2]*d(w[1]) - u[1]*d(w[2]),
     1: d(u[1])*w[1] + 2*d(u[0])*w[2] - 2*u[2]*d(w[0]) - u[1]*d(w[1]),
     0: d(u[0])*w[1] - u[1]*d(w[0])}
ok(all(sp.expand(br.coeff(v, k) - E[k]) == 0 for k in range(5)) and sp.expand(br.coeff(v, 5)) == 0,
   "3  coefficients of v^4,...,v^0 of U_x V_v - U_v V_x + J' v^4 are (E4),...,(E0)")

# ---------------------------------------------------------------- 4. identity
W = 2*d(u[3])*w[2] - 3*u[3]*d(w[2])
ok(sp.simplify(d(u[3]**2/w[2]**3) - u[3]*W/w[2]**4) == 0,
   "4  (u3^2/w2^3)' = u3 W / w2^4 with W = 2 u3' w2 - 3 u3 w2'")

# ---------------------------------------------------------------- 5. representative over E
coef = {}
for line in open(os.path.join(HERE, 'leading_pair_147.txt')):
    if line.startswith('#') or not line.strip():
        continue
    i, cstr = line.split(':')
    coef[int(i)] = cstr.strip()
ok(sorted(coef) == list(range(11)), "5a data file: coefficients c_0..c_10 of w2* read")
T = '(%s)' % FPOL
def El(e): return pari('Mod(%s,%s)' % (e, T))
ZE, ONE = El(0), El(1)
c_ = [El(coef[i]) for i in range(11)] + [ZE, ONE]
k3 = [ZE]*37
for i in range(13):
    for j in range(13):
        for l in range(13):
            if c_[i] != ZE and c_[j] != ZE and c_[l] != ZE:
                k3[i+j+l] += c_[i]*c_[j]*c_[l]
gc = [ONE]
for j in range(1, 19):
    acc = ZE
    for a_ in range(1, j):
        acc += gc[a_]*gc[j-a_]
    gc.append((k3[36-j] - acc)/2)
u3c = [gc[18-i] for i in range(19)]          # u3c[i] = coefficient of x^i in u3*
w2c = c_
Dc = [ZE]*37
for i in range(19):
    for j in range(19):
        Dc[i+j] += u3c[i]*u3c[j]
Dc = [Dc[i] - k3[i] for i in range(37)]
ok(all(Dc[i] == ZE for i in range(8, 37)) and Dc[7] != ZE,
   "5b u3* := polynomial part of w2*^(3/2); deg(u3*^2 - w2*^3) = 7")
def pmul(A, B):
    C = [ZE]*(len(A)+len(B)-1)
    for i, a_ in enumerate(A):
        if a_ == ZE: continue
        for j, b_ in enumerate(B):
            if b_ != ZE: C[i+j] += a_*b_
    return C
def pder(A): return [A[i]*i for i in range(1, len(A))]
def padd(A, B, sgn=1):
    n = max(len(A), len(B))
    return [(A[i] if i < len(A) else ZE) + sgn*(B[i] if i < len(B) else ZE) for i in range(n)]
Wc = padd([2*t for t in pmul(pder(u3c), w2c)], [3*t for t in pmul(u3c, pder(w2c))], -1)
Jstar = -Wc[0]
ok(all(t == ZE for t in Wc[1:]) and Jstar == 29*Dc[7] and Jstar != ZE,
   "5c 2 u3*' w2* - 3 u3* w2*' = -J* is constant, with J* = 29 d7* != 0")
ok(c_[9] == c_[10] and c_[10] != ZE, "5d normalisation of the representative: c9 = c10 != 0")
wv = c_[8]/(c_[10]**2)
mp = pari.minpoly(wv)
ok(pari.poldegree(mp) == 6 and pari.polisirreducible(mp),
   "5e w = c8/c10^2 has an irreducible minimal polynomial of degree 6 over Q (so w generates E)")
print("     minimal polynomial of w:", mp, flush=True)
ok(pari.polisirreducible(pari(FPOL.replace('a', 'x'))) and pari.poldegree(pari(FPOL.replace('a', 'x'))) == 6,
   "5f the defining polynomial of E is irreducible over Q")

# ---------------------------------------------------------------- 6. count of leading pairs
ctx = flint.fmpq_mpoly_ctx.get(('b', 11), 'degrevlex')
Bv = ctx.gens()
zero = 0*Bv[0]
kc = [Bv[i] for i in range(11)] + [zero, zero + 1]
def mmul(A, B_):
    C = [zero for _ in range(len(A)+len(B_)-1)]
    for i, a_ in enumerate(A):
        for j, b_ in enumerate(B_):
            C[i+j] += a_*b_
    return C
K3 = mmul(mmul(kc, kc), kc)
G = [zero + 1]
for j in range(1, 19):
    acc = zero
    for a_ in range(1, j):
        acc += G[a_]*G[j-a_]
    G.append((K3[36-j] - acc)/2)
gpol = [G[18-i] for i in range(19)]
DD = mmul(gpol, gpol)
DD = [DD[i] - K3[i] for i in range(37)]
ok(all(DD[i] == 0 for i in range(18, 37)), "6a generic leading equation: D = u3^2 - w2^3 has degree <= 17 by construction")
den_free = []
for e in [DD[i] for i in range(8, 18)] + [DD[7] - 1]:
    den = 1
    for mon, cf in e.to_dict().items():
        den = sp.ilcm(den, int(cf.q))
    den_free.append(str(e*den))
names = ','.join('b%d' % i for i in range(10, -1, -1))
wts = ','.join(str(12-i) for i in range(10, -1, -1))
def count_text(p):
    hdr = 'ring r=%s,(%s),wp(%s);\noption(redSB);\n' % (p, names, wts)
    body = 'ideal I=\n' + ',\n'.join(den_free) + ';\nideal G=std(I);\nprint(dim(G));print(vdim(G));\nquit;\n'
    return hdr + body
def count_text_Q():
    # exact over Q: the equations are weighted homogeneous except d7 - 1; homogenise it as d7 - h^29
    # (h of weight 1), compute a verified standard basis of this weighted homogeneous ideal (modStd is
    # exact for homogeneous input), dehomogenise (h = 1, h last in a weighted reverse ordering) and
    # recompute a standard basis over Q of the resulting generators of the original ideal.
    E_ = list(den_free)
    m_ = re.match(r'(.*) - (\d+)$', E_[-1].strip(), re.S)
    E_[-1] = m_.group(1) + ' - %s*h^29' % m_.group(2)
    t_ = ('LIB "modstd.lib";\nring r=0,(%s,h),wp(%s,1);\noption(redSB);\n' % (names, wts)
          + 'ideal I=\n' + ',\n'.join(E_) + ';\nideal G=modStd(I);\nideal G1=subst(G,h,1);\n'
          + 'ring r1=0,(%s),wp(%s);\noption(redSB);\nideal G1=imap(r,G1);\nideal S=std(G1);\n' % (names, wts)
          + 'print(dim(S));print(vdim(S));\nquit;\n')
    return t_
for p in (32003, 1000003, 536870909):
    out = singular(count_text(p))
    ok(out == ['0', '174'], "6b [Singular] mod %d: dimension 0, degree 174 (d7 = 1)" % p)
def triangulations(vs):
    if len(vs) < 3: return [frozenset()]
    out_ = []
    for k_ in range(1, len(vs)-1):
        for L_ in triangulations(vs[:k_+1]):
            for R_ in triangulations(vs[k_:]):
                out_.append(L_ | R_ | {tuple(sorted((vs[0], vs[k_], vs[-1])))})
    return out_
TR = set(triangulations(tuple(range(7))))
def rot7(t_): return frozenset(tuple(sorted((q_+1) % 7 for q_ in tr)) for tr in t_)
orbs = set()
for t_ in TR:
    o_ = [t_]
    for i in range(6): o_.append(rot7(o_[-1]))
    orbs.add(frozenset(o_))
ok(len(TR) == 42 and len(orbs) == 6 and all(len(o_) == 7 for o_ in orbs),
   "6d a heptagon has 42 triangulations, forming 6 rotation classes of size 7 (6 weighted trees)")
if RUN_COUNT_OVER_Q:
    out = singular(count_text_Q())
    ok(out == ['0', '174'], "6c [Singular] over Q (homogenised, verified standard basis): dimension 0, degree 174 (d7 = 1)")
else:
    print("SKIP  6c [Singular] over Q: optional, set RUN_COUNT_OVER_Q = True (long; the note does not use it)", flush=True)

# ---------------------------------------------------------------- 7. elimination over E
NP = [0]; FREE = []
def pp_add(A, B_, sg=1):
    C = dict(A)
    for m, cf in B_.items():
        C[m] = C.get(m, ZE) + sg*cf
        if C[m] == ZE: del C[m]
    return C
def pp_mul(A, B_):
    C = {}
    for (m1, c1), (m2, c2) in itertools.product(A.items(), B_.items()):
        n = max(len(m1), len(m2))
        m = tuple((m1[i] if i < len(m1) else 0) + (m2[i] if i < len(m2) else 0) for i in range(n))
        while m and m[-1] == 0: m = m[:-1]
        C[m] = C.get(m, ZE) + c1*c2
    return {m: cf for m, cf in C.items() if cf != ZE}
def pp_scal(A, t): return {m: cf*t for m, cf in A.items() if cf*t != ZE}
def cst(t): return {(): t} if t != ZE else {}
def newpar(name):
    NP[0] += 1; FREE.append(name)
    return {tuple([0]*(NP[0]-1) + [1]): ONE}
def xp_add(A, B_, sg=1):
    n = max(len(A), len(B_))
    return [pp_add(A[i] if i < len(A) else {}, B_[i] if i < len(B_) else {}, sg) for i in range(n)]
def xp_mul(A, B_):
    C = [{} for _ in range(len(A)+len(B_)-1)]
    for i, a_ in enumerate(A):
        if not a_: continue
        for j, b_ in enumerate(B_):
            if b_: C[i+j] = pp_add(C[i+j], pp_mul(a_, b_))
    return C
def xp_d(A): return [pp_scal(A[i], El(i)) for i in range(1, len(A))] or [{}]
def xp_sc(A, t): return [pp_scal(a_, El(t)) for a_ in A]
def mono(i): return [{}]*i + [cst(ONE)]
U3 = [cst(t) for t in u3c]; W2 = [cst(t) for t in w2c]
def solve_layer(cols, rhs):
    deg = max(len(rhs), max(len(col) for _, col in cols))
    M = pari.matrix(deg, len(cols))
    for j, (nm, col) in enumerate(cols):
        for i in range(deg):
            cc = col[i] if i < len(col) else {}
            assert set(cc) <= {()}
            M[i, j] = cc.get((), ZE)
    R = [rhs[i] if i < len(rhs) else {} for i in range(deg)]
    idx = pari.matindexrank(M)
    ri = [int(t)-1 for t in idx[0]]; ci = [int(t)-1 for t in idx[1]]
    rk = len(ri)
    Mi = pari.matrix(rk, rk)
    for a_ in range(rk):
        for b_ in range(rk): Mi[a_, b_] = M[ri[a_], ci[b_]]
    Inv = Mi**-1
    vals = {}
    free = [j for j in range(len(cols)) if j not in ci]
    for j in free: vals[j] = newpar(cols[j][0])
    red = []
    for a_ in range(rk):
        r = R[ri[a_]]
        for j in free:
            if M[ri[a_], j] != ZE: r = pp_add(r, pp_scal(vals[j], M[ri[a_], j]), -1)
        red.append(r)
    for b_ in range(rk):
        acc = {}
        for a_ in range(rk):
            if Inv[b_, a_] != ZE: acc = pp_add(acc, pp_scal(red[a_], Inv[b_, a_]))
        vals[ci[b_]] = acc
    conds = []
    for i in range(deg):
        if i in ri: continue
        acc = pp_scal(R[i], El(-1)) if R[i] else {}
        for j in range(len(cols)):
            if M[i, j] != ZE: acc = pp_add(acc, pp_scal(vals[j], M[i, j]))
        if acc: conds.append(acc)
    return [vals[j] for j in range(len(cols))], conds, rk

def eliminate(planted=None, perturb=False):
    NP[0] = 0; FREE.clear()
    zeroX = [{}]
    if planted:
        pl = planted
        X3 = xp_add(xp_add(xp_mul(xp_d(U3), pl['w1']), xp_sc(xp_mul(U3, xp_d(pl['w1'])), 3), -1),
                    xp_add(xp_sc(xp_mul(xp_d(pl['u2']), W2), 2), xp_sc(xp_mul(pl['u2'], xp_d(W2)), 2), -1))
        X2 = xp_add(xp_add(xp_mul(xp_d(pl['u2']), pl['w1']), xp_sc(xp_mul(pl['u2'], xp_d(pl['w1'])), 2), -1),
                    xp_add(xp_add(xp_sc(xp_mul(xp_d(pl['u1']), W2), 2), xp_mul(pl['u1'], xp_d(W2)), -1),
                           xp_sc(xp_mul(U3, xp_d(pl['w0'])), -3)))
        X1 = xp_add(xp_add(xp_add(xp_mul(xp_d(pl['u1']), pl['w1']), xp_mul(pl['u1'], xp_d(pl['w1'])), -1),
                           xp_sc(xp_mul(pl['u2'], xp_d(pl['w0'])), -2)), xp_sc(xp_mul(xp_d(pl['u0']), W2), 2))
        X0 = xp_add(xp_mul(xp_d(pl['u0']), pl['w1']), xp_mul(pl['u1'], xp_d(pl['w0'])), -1)
        if perturb: X0 = xp_add(X0, [cst(ONE)])
    else:
        X3 = X2 = X1 = X0 = zeroX
    # (E3): u3' w1 - 3 u3 w1' + 2 u2' w2 - 2 u2 w2' = 0, unknowns u2 (x^0..x^18), w1 (x^0..x^12)
    def L3(p2=None, q1=None):
        e = [{}]
        if q1 is not None: e = xp_add(e, xp_add(xp_mul(xp_d(U3), q1), xp_sc(xp_mul(U3, xp_d(q1)), 3), -1))
        if p2 is not None: e = xp_add(e, xp_add(xp_sc(xp_mul(xp_d(p2), W2), 2), xp_sc(xp_mul(p2, xp_d(W2)), 2), -1))
        return e
    cols = [('u2_%d' % i, L3(p2=mono(i))) for i in range(19)] + [('w1_%d' % i, L3(q1=mono(i))) for i in range(13)]
    rhs = xp_add(X3, L3(p2=xp_sc(mono(19), 3), q1=xp_sc(mono(13), 2)), -1)
    v3, c3, r3 = solve_layer(cols, rhs)
    u2 = xp_add(xp_sc(mono(19), 3), v3[:19]); w1 = xp_add(xp_sc(mono(13), 2), v3[19:])
    # (E2): u2' w1 - 2 u2 w1' + 2 u1' w2 - u1 w2' - 3 u3 w0' = 0, unknowns u1 (x^0..x^19), w0 (x^1..x^13)
    known = xp_add(xp_mul(xp_d(u2), w1), xp_sc(xp_mul(u2, xp_d(w1)), 2), -1)
    def L2(p1=None, q0=None):
        e = [{}]
        if p1 is not None: e = xp_add(e, xp_add(xp_sc(xp_mul(xp_d(p1), W2), 2), xp_mul(p1, xp_d(W2)), -1))
        if q0 is not None: e = xp_add(e, xp_sc(xp_mul(U3, xp_d(q0)), -3))
        return e
    cols = [('u1_%d' % i, L2(p1=mono(i))) for i in range(20)] + [('w0_%d' % i, L2(q0=mono(i))) for i in range(1, 14)]
    rhs = xp_add(X2, xp_add(known, L2(p1=xp_sc(mono(20), 3), q0=mono(14))), -1)
    v2, c2, r2 = solve_layer(cols, rhs)
    u1 = xp_add(xp_sc(mono(20), 3), v2[:20]); w0 = xp_add(mono(14), [{}] + v2[20:])
    # (E1): u1' w1 - u1 w1' - 2 u2 w0' + 2 u0' w2 = 0, unknowns u0 (x^1..x^20 without x^14)
    known = xp_add(xp_add(xp_mul(xp_d(u1), w1), xp_mul(u1, xp_d(w1)), -1), xp_sc(xp_mul(u2, xp_d(w0)), -2))
    idx0 = [i for i in range(1, 21) if i != 14]
    cols = [('u0_%d' % i, xp_sc(xp_mul(xp_d(mono(i)), W2), 2)) for i in idx0]
    rhs = xp_add(X1, xp_add(known, xp_sc(xp_mul(xp_d(mono(21)), W2), 2)), -1)
    v1, c1, r1 = solve_layer(cols, rhs)
    u0 = mono(21)
    for t_, i in enumerate(idx0): u0 = xp_add(u0, [{}]*i + [v1[t_]])
    # (E0): u0' w1 - u1 w0' = 0
    E0 = xp_add(xp_add(xp_mul(xp_d(u0), w1), xp_mul(u1, xp_d(w0)), -1), X0, -1)
    c0 = [e for e in E0 if e]
    return dict(r3=r3, r2=r2, r1=r1, c3=c3, c2=c2, c1=c1, c0=c0, free=list(FREE), n=NP[0])

t0 = time.time()
res = eliminate()
ok(res['r3'] == 29 and len(res['c3']) == 0 and res['free'][:3] == ['u2_12', 'w1_11', 'w1_12'],
   "7a (E3): 32 unknowns, rank 29, free: coefficients of x^12 in u2 and x^11, x^12 in w1; no condition")
ok(res['r2'] == 30 and len(res['c2']) == 0 and res['free'][3:] == ['w0_11', 'w0_12', 'w0_13'],
   "7b (E2): 33 unknowns, rank 30, free: coefficients of x^11, x^12, x^13 in w0; no condition")
ok(res['r1'] == 19 and len(res['c1']) == 13, "7c (E1): 19 unknowns (u0), rank 19, 13 conditions")
ok(len(res['c0']) == 33, "7d (E0): 33 conditions")
conds = res['c1'] + res['c0']
degs = sorted(set(max(sum(m) for m in cc) for cc in conds))
ok(res['n'] == 6 and degs == [3, 4], "7e 46 conditions, polynomials of degrees 3 and 4 in the 6 free unknowns t1..t6")
tv = ['t%d' % (i+1) for i in range(6)]
def pstr(cc):
    out = []
    for m, cf in cc.items():
        mon = '*'.join('%s^%d' % (tv[i], e) for i, e in enumerate(m) if e) or '1'
        cs = str(pari.lift(cf))
        assert not re.search(r'\^\d+/', cs)
        out.append('(%s)*%s' % (cs, mon))
    return '+'.join(out)
def unit_text(cl):
    return ('ring r=(0,a),(%s),dp;\nminpoly=%s;\noption(redSB);\nideal I=\n' % (','.join(tv), FPOL)
            + ',\n'.join(pstr(cc) for cc in cl) + ';\nideal G=std(I);\nsize(G);G[1];\nquit;\n')
ok(singular(unit_text(conds)) == ['1', '1'], "7f [Singular] the 46 conditions generate the unit ideal over E")
ok(singular(unit_text(res['c1'])) == ['1', '1'], "7g [Singular] the 13 conditions from (E1) alone generate the unit ideal over E")
mons = sorted(set(m for cc in res['c1'] for m in cc))
Mlin = pari.matrix(len(mons), len(res['c1']))
for j, cc in enumerate(res['c1']):
    for i, m in enumerate(mons):
        Mlin[i, j] = cc.get(m, ZE)
target = pari.matrix(len(mons), 1)
for i, m in enumerate(mons):
    target[i, 0] = ONE if m == () else ZE
r1 = pari.matrank(Mlin)
Aug = pari.matconcat([Mlin, target])
r2 = pari.matrank(Aug)
ok(() in mons and r1 == r2,
   "7h 1 is an E-linear combination of the 13 conditions from (E1) (%d monomials): the contradiction is linear" % len(mons))

# ---------------------------------------------------------------- 8. planted controls
def planted(seed):
    random.seed(seed)
    def rnd(): return El(random.randint(-9, 9)) + El(random.randint(-3, 3))*El('a')
    return {'u2': [cst(rnd()) for i in range(19)] + [cst(El(3))],
            'w1': [cst(rnd()) for i in range(13)] + [cst(El(2))],
            'u1': [cst(rnd()) for i in range(20)] + [cst(El(3))],
            'w0': [{}] + [cst(rnd()) for i in range(13)] + [cst(ONE)],
            'u0': [{}] + [cst(rnd()) if i != 14 else {} for i in range(1, 21)] + [cst(ONE)]}
def eval_conds(pl, perturb=False):
    r = eliminate(pl, perturb)
    name2val = {}
    for i in range(19): name2val['u2_%d' % i] = pl['u2'][i]
    for i in range(13): name2val['w1_%d' % i] = pl['w1'][i]
    for i in range(1, 14): name2val['w0_%d' % i] = pl['w0'][i]
    tvals = [name2val[f].get((), ZE) for f in r['free']]
    def ev(cc):
        tot = ZE
        for m, cf in cc.items():
            t_ = cf
            for i, e in enumerate(m): t_ = t_*tvals[i]**e
            tot += t_
        return tot
    allc = r['c3'] + r['c2'] + r['c1'] + r['c0']
    return sum(1 for cc in allc if ev(cc) != ZE), len(allc)
for seed in (11, 12):
    nz, tot = eval_conds(planted(seed))
    ok(nz == 0, "8a planted solution (seed %d): all %d conditions vanish at the planted values" % (seed, tot))
nz, tot = eval_conds(planted(13), perturb=True)
ok(nz > 0, "8b perturbed right-hand side (seed 13): %d of %d conditions do not vanish" % (nz, tot))

# ---------------------------------------------------------------- 9. full system modulo a split prime
p = 536853127
fx = flint.nmod_poly([80, -48, 12, 10, -8, -2, 1], p)
roots = [int(r) for r, e in fx.roots()]
ok(len(roots) == 6, "9a the defining polynomial of E has 6 distinct roots modulo p = %d" % p)
def modp(cstr, r):
    q = sp.Poly(sp.sympify(cstr.replace('^', '**')), sp.Symbol('a'))
    tot = 0
    for (e,), cf in q.terms():
        cf = sp.Rational(cf)
        tot += int(cf.p) * pow(int(cf.q), -1, p) * pow(r, e, p)
    return tot % p
allinc = True
for r in roots:
    wc = [modp(coef[i], r) for i in range(11)] + [0, 1]
    # u3 = polynomial part of w2^(3/2) modulo p
    W3 = [0]*37
    for i in range(13):
        for j in range(13):
            for l in range(13):
                W3[i+j+l] = (W3[i+j+l] + wc[i]*wc[j]*wc[l]) % p
    gg = [1]
    inv2 = pow(2, -1, p)
    for j in range(1, 19):
        acc = sum(gg[a_]*gg[j-a_] for a_ in range(1, j)) % p
        gg.append((W3[36-j] - acc)*inv2 % p)
    u3p = sum(gg[18-i]*x**i for i in range(19)); w2p = sum(wc[i]*x**i for i in range(13))
    Unk = []
    def unk(name, deg, topc, skip=()):
        e = topc*x**(deg+1)
        for i in range(deg+1):
            if i in skip: continue
            sy = sp.Symbol('%s_%d' % (name, i)); Unk.append(sy); e += sy*x**i
        return e
    u2p = unk('uu2', 18, 3); w1p = unk('ww1', 12, 2); u1p = unk('uu1', 19, 3)
    w0p = unk('ww0', 13, 1, skip=(0,)); u0p = unk('uu0', 20, 1, skip=(0, 14))
    Up = u3p*v**3 + u2p*v**2 + u1p*v + u0p; Vp = w2p*v**2 + w1p*v + w0p
    brp = sp.Poly(sp.expand(sp.diff(Up, x)*sp.diff(Vp, v) - sp.diff(Up, v)*sp.diff(Vp, x)), x, v)
    jv = [(i, cf) for (i, j), cf in brp.terms() if j == 4 and int(cf) % p != 0]
    assert all(i == 0 for i, cf in jv) and len(jv) == 1 and int(jv[0][1]) % p != 0
    eqs = [cf for (i, j), cf in brp.terms() if j != 4]
    assert all(j <= 4 for (i, j), cf in brp.terms())
    eqs = [sp.Poly(e, *Unk) for e in eqs]
    def ms(e):
        terms = []
        for mon, cf in e.terms():
            cf = int(cf) % p
            if cf == 0: continue
            m = '*'.join('%s^%d' % (Unk[i], k) for i, k in enumerate(mon) if k) or '1'
            terms.append('%d*%s' % (cf, m))
        return '+'.join(terms) if terms else '0'
    txt = ('ring r=%d,(%s),dp;\noption(redSB);\nideal I=\n' % (p, ','.join(map(str, Unk)))
           + ',\n'.join(ms(e) for e in eqs) + ';\nideal G=std(I);\nsize(G);G[1];\nquit;\n')
    out = singular(txt)
    allinc = allinc and out == ['1', '1'] and len(Unk) == 84 and len(eqs) == 126
ok(allinc, "9b [Singular] full system (84 unknowns, 126 equations) is inconsistent mod p at each of the 6 roots")

print("%d checks" % NPASS[0])
print("ALL CHECKS PASSED")
