"""
verify_56_140.py -- ancillary file of the note
  "The degree pair (56,140) in the plane Jacobian problem: exclusion of the shape
   with starting corner (7,21) and final corner (13/7,3)"
Author : David Niedbala Giraudin (Independent researcher, France)
ORCID  : 0009-0009-1526-1178
Prepared with AI assistance (Claude, Anthropic).

What it checks (exact arithmetic):
  1. the arithmetic of Lemma 2.1 (roots) and Lemma 4.1 (corner);
  2. the leading terms of Lemma 5.1 (coordinates), by expansion with SymPy;
  3. the equation of order 0 of Lemma 6.1 (normalisation);
  4a. Proposition 6.2 by exact linear algebra (SymPy only): the equations of layers 0..11 force
     p_{0,7} = -4 and q_{3,16} = -10; two further coefficients then give 840 = 0.
  4b. Proposition 6.2 again, by a Groebner basis: the normalised system generates the unit
     ideal over Q. This step needs the program Singular (https://www.singular.uni-kl.de); the
     script writes the input file system_56_140.sing and runs it if `Singular` is on the PATH
     (a few minutes at most); otherwise it prints NOT CHECKED for this step, which is not
     needed for the proof.
It does not prove the results quoted in the note.
Run:  python3 verify_56_140.py
"""
import sympy as sp, shutil, subprocess, sys, os, time
from fractions import Fraction as Fr
from math import gcd
from collections import defaultdict
ok=True; count=0
def check(name,cond):
    global ok,count
    count+=1
    print(("PASS  " if cond else "FAIL  ")+name, flush=True); ok = ok and bool(cond)
m,n=2,5
def type_I(a,b,l):
    c1=Fr(a,l)-Fr(1,m+n); c2=Fr(b)-Fr(1,m+n)
    r,s=c2,-c1
    den=r.denominator*s.denominator//gcd(r.denominator,s.denominator)
    R,S=int(r*den),int(s*den); g=gcd(abs(R),abs(S)); R//=g; S//=g
    vP=Fr(m,m+n)*(R+S); vQ=Fr(n,m+n)*(R+S)
    out=[]
    ap=vP*l/(m*R)
    if ap.denominator==1 and ap>0: out.append(('I.a',int(ap)))
    for nm,val in (('st(Q)=(k/l,0)',vQ),('st(P)=(k/l,0)',vP)):
        k=val*l/R
        if k.denominator==1 and k>0: out.append((nm,int(k)))
    return (R,S),(vP,vQ),out
# ---------------- 1. arithmetic ----------------
check("corner (7,21), direction (7,-2), l=1: right-hand side of (5.9) is 14/5, so 2k >= 14/5 means k >= 2",
      Fr(m,1)*Fr(7*7+21*(-2),7-2)==Fr(14,5) and 2*1<Fr(14,5)<=2*2)
check("(1,0)+k(2/7,1) = (11/7,2), (13/7,3) for k = 2, 3", [1+Fr(2*k,7) for k in (2,3)]==[Fr(11,7),Fr(13,7)])
d,v,o=type_I(11,2,7)
check("(11/7,2), l=7: Case I impossible (direction %s, v(P)=%s, v(Q)=%s); gcd(11,2)=1"%(d,v[0],v[1]), d==(13,-10) and o==[] and gcd(11,2)==1)
d,v,o=type_I(13,3,7)
check("(13/7,3), l=7: Case I direction (5,-3), v(P1)=4/7, v(Q1)=10/7, only st(Q1)=(2/7,0), st(P1)=(5/7,1); gcd(13,3)=1",
      d==(5,-3) and v==(Fr(4,7),Fr(10,7)) and o==[('st(Q)=(k/l,0)',2)] and gcd(13,3)==1 and 5*Fr(5,7)-3==Fr(4,7))
check("Case III directions (7,-j) strictly between (5,-3) and (7,-2): j = 3, 4", [j for j in range(1,8) if Fr(-3,5)<Fr(-j,7)<Fr(-2,7)]==[3,4])
check("W(X^i eta^j) = 5i-21j: X^5 eta, X^26 eta^6 have W=4; X^2, X^65 eta^15 have W=10",
      [5*5-21,5*26-21*6,5*2,5*65-21*15]==[4,4,10,10])
# ---------------- 2. coordinates ----------------
X,eta,lam,l3,l4,g2=sp.symbols('X eta lambda lambda3 lambda4 g2')
def weight(term):
    pw=term.as_powers_dict(); return 5*pw.get(X,0)-21*pw.get(eta,0)
def trunc(expr,wmin):
    return sp.Add(*[t for t in sp.Add.make_args(sp.expand(expr)) if weight(t)>=wmin])
def layers(expr):
    by=defaultdict(int)
    for t in sp.Add.make_args(sp.expand(expr)): by[weight(t)]+=t
    return by
Y=eta+lam/X**2+l3/X**3+l4/X**4
u=sp.expand(Y*X**2); dd=u-lam
inv=sum((-dd/lam)**k for k in range(0,6))/lam          # 1/u up to terms of weight <= -30
wmin=-12
zi=trunc(X*u**3-g2*Y,wmin)                              # image of z = X^7 Y^3 - g2 Y
vi=trunc(X**2*inv,wmin)                                 # image of v = 1/Y
Lz=layers(zi); Lv=layers(vi)
check("image of z: W = 5, leading term lambda^3 X", max(Lz)==5 and sp.simplify(Lz[5]-lam**3*X)==0)
check("image of v: W = 10, leading term X^2/lambda", max(Lv)==10 and sp.simplify(Lv[10]-X**2/lam)==0)
k1=7*lam**2*l3; k2=7*lam**4*(lam*l4-l3**2)
zeta=trunc(trunc(zi*zi,wmin)-lam**7*vi-k1*zi-k2,wmin)
Lzeta={w:sp.factor(e) for w,e in layers(zeta).items() if sp.simplify(e)!=0}
check("image of zeta = z^2 - c v - kappa1 z - kappa2 (c=lambda^7): W = -1, leading term 7 lambda^5 eta X^4; next weight -5",
      sorted(Lzeta,reverse=True)[:2]==[-1,-5] and sp.simplify(Lzeta[-1]-7*lam**5*eta*X**4)==0)
check("leading monomials eta^b X^(a+4b) of z^a zeta^b have W = 5a-b and are distinct for distinct (a,b)",
      len({(a+4*b,b) for a in range(40) for b in range(40)})==1600 and all(5*(a+4*b)-21*b==5*a-b for a in range(5) for b in range(5)))
# ---------------- 3. the system ----------------
z,s,J,kk=sp.symbols('z s J k2')
def poly(pref,D,Wb,fix):
    e=0; names=[]
    for a in range(0,D+1):
        for b in range(0,D+1):
            if a+2*b<=D and 5*a-b<=Wb:
                if (a,b) in fix: e+=fix[(a,b)]*z**a*s**b
                else:
                    c=sp.Symbol('%s_%d_%d'%(pref,a,b)); names.append(c); e+=c*z**a*s**b
    return e,names
P0=[(a,b) for a in range(15) for b in range(15) if a+2*b<=14 and 5*a-b==4]
Q0=[(a,b) for a in range(36) for b in range(36) if a+2*b<=35 and 5*a-b==10]
check("layer 0 of P: monomials z s, z^2 s^6; layer 0 of Q: z^2, z^3 s^5, z^4 s^10, z^5 s^15", P0==[(1,1),(2,6)] and Q0==[(2,0),(3,5),(4,10),(5,15)])
b20,b35,b410,Jx=sp.symbols('b20 b35 b410 Jx')
p0=z*s+z**2*s**6; q0=b20*z**2+b35*z**3*s**5+b410*z**4*s**10+z**5*s**15
B0=sp.expand(sp.diff(p0,z)*sp.diff(q0,s)-sp.diff(p0,s)*sp.diff(q0,z)-Jx*z**2)
sol=sp.solve(sp.Poly(B0,z,s).coeffs(),[b20,b35,b410,Jx],dict=True)
check("order 0 with p_{1,1}=p_{2,6}=q_{5,15}=1: unique solution q_{2,0}=5/16, q_{3,5}=15/8, q_{4,10}=5/2, J=-5/8",
      sol==[{b20:sp.Rational(5,16),b35:sp.Rational(15,8),b410:sp.Rational(5,2),Jx:sp.Rational(-5,8)}])
P,pn=poly('p',14,4,{(1,1):1,(2,6):1,(0,0):0})
Q,qn=poly('q',35,10,{(5,15):1,(0,0):0,(4,12):0,(2,6):0})
B=sp.expand(sp.diff(P,z)*sp.diff(Q,s)-sp.diff(P,s)*sp.diff(Q,z)-J*(z**2-kk-s))
eqs=[c for c in sp.Poly(B,z,s).coeffs() if c!=0]
names=pn+qn+[kk,J]
check("system (S1)-(S2), normalised: %d unknowns, %d equations"%(len(names),len(eqs)), len(names)==82 and len(eqs)==104)
# ---------------- 4a. Proposition 6.2, elementary route (exact linear algebra, no Groebner basis) ----------------
Bp=sp.Poly(B,z,s)
def layer(nm):
    nm=str(nm)
    if nm=='J': return 0
    if nm=='k2': return 10
    pref,a,b=nm.split('_'); a=int(a); b=int(b); return (4 if pref=='p' else 10)-(5*a-b)
byw={}
for (a,b),c in Bp.terms(): byw.setdefault(10-(5*a-b),[]).append(c)
known={}; free=[]; lin=True
for k in range(0,12):
    V=[x for x in names if layer(x)==k]
    E=[sp.expand(e.subs(known)) for e in byw.get(k,[])]
    A,bb=sp.linear_eq_to_matrix(E,V)
    lin = lin and all(x.is_number for x in A)
    solk=sp.linsolve((A,bb),V)
    if solk==sp.EmptySet: lin=False; break
    solk=list(solk)[0]
    fr=sorted(set().union(*[x.free_symbols for x in solk])&set(V),key=str)
    for vv,val in zip(V,solk):
        if vv not in fr: known[vv]=sp.expand(val)
    free+=fr
S=sp.Symbol
check("layers 0..11: each equation system is linear with rational matrix in the unknowns of its layer and is solvable; free parameters: q_4_14, q_4_15, q_3_13, q_3_15",
      lin and [str(x) for x in free]==['q_4_14','q_4_15','q_3_13','q_3_15'])
check("layers 0..11 force p_{0,7} = -4 and q_{3,16} = -10 (and J' = -5/8), independently of the free parameters",
      known[S('p_0_7')]==-4 and known[S('q_3_16')]==-10 and known[J]==sp.Rational(-5,8))
c22=Bp.coeff_monomial(z**2*s**22); c23=Bp.coeff_monomial(s**23)
check("coefficient of z^2 s^22 in (S2): -21 p_{0,7} q_{3,16} + 28 q_{1,17};  coefficient of s^23: -7 p_{0,7} q_{1,17}",
      sp.expand(c22-(-21*S('p_0_7')*S('q_3_16')+28*S('q_1_17')))==0 and sp.expand(c23+7*S('p_0_7')*S('q_1_17'))==0)
q117=sp.solve(c22.subs(known),S('q_1_17'))
check("hence q_{1,17} = 30 and the coefficient of s^23 equals 840, which is not 0: the system has no solution",
      q117==[30] and c23.subs(known).subs(S('q_1_17'),30)==840)
# ---------------- 4b. Proposition 6.2, second route (Groebner basis, Singular) ----------------
def wgt(nm):
    nm=str(nm)
    if nm=='J': return 44
    if nm=='k2': return 2
    pref,a,b=nm.split('_'); a=int(a); b=int(b); return ((14 if pref=='p' else 35)-(a+2*b)) or 1
here=os.path.dirname(os.path.abspath(__file__))
fn=os.path.join(here,'system_56_140.sing')
with open(fn,'w') as f:
    f.write('// system (S1)-(S2) of the note, normalised as in Lemma 6.1\n')
    f.write('ring r=0,(%s),wp(%s);\noption(redSB);\n'%(','.join(map(str,names)),','.join(str(wgt(x)) for x in names)))
    f.write('ideal I=\n'+',\n'.join(str(e).replace('**','^') for e in eqs)+';\n')
    f.write('ideal G=std(I);\nprint("SIZE");print(size(G));print("FIRST");print(G[1]);\nquit;\n')
print("      input file written: system_56_140.sing", flush=True)
exe=shutil.which('Singular')
if exe is None:
    print("NOT CHECKED  second route of Proposition 6.2 (Singular not found on the PATH); the first route above is complete")
else:
    t0=time.time(); print("      running Singular ...", flush=True)
    out=subprocess.run([exe,'-q',fn],stdin=subprocess.DEVNULL,capture_output=True,text=True).stdout.split()
    check("second route: the equations of the normalised system (S1)-(S2) generate the unit ideal of the polynomial ring over Q (Groebner basis = {1})",
          out==['SIZE','1','FIRST','1'])
print("%d checks"%count)
print("ALL CHECKS PASSED" if ok else "SOME CHECK FAILED")
