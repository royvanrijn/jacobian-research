"""
verify_7_35.py -- ancillary file of the note
  "The starting corner (7,35) in the plane Jacobian problem: the point (18/7,4)
   is not a regular corner"
Author : David Niedbala Giraudin (Independent researcher, France)
ORCID  : 0009-0009-1526-1178
Prepared with AI assistance (Claude, Anthropic).

Exact rational arithmetic, Python standard library only (module fractions).
It checks the arithmetic used in the note, for (m,n) = (2,3):
  * type_I(a,b,l)  : for a corner (a/l,b), the direction (rho,sigma) forced by
        m*v(A) = m/(m+n)*(rho+sigma)   (v(P)+v(Q)=rho+sigma, v(P)/v(Q)=m/n, en(P)=m*A)
    and the starting points allowed by [GGV1, Proposition 5.13]:
        I.a)  (1/m) st(P) = (a'/l,0),  a' a positive integer;
        I.b)  {st(P),st(Q)} = {(k/l,0),(1-k/l,1)},  k a positive integer.
  * type_II(a,b,l,below) : the directions allowed by [GGV1, Proposition 5.14(2),(3),(4)]
    for a corner of type II, in the interval I = ](1,-1),(1,0)], strictly smaller than the
    direction `below` (no restriction if below is None).
It does not prove the propositions quoted in the note.
Run:  python3 verify_7_35.py      (immediate)
"""
from fractions import Fraction as Fr
from math import gcd
m,n=2,3
ok=True
count=0
def check(name,cond):
    global ok,count
    count+=1
    print(("PASS  " if cond else "FAIL  ")+name, flush=True); ok = ok and bool(cond)
def type_I(a,b,l):
    c1=Fr(a,l)-Fr(1,m+n); c2=Fr(b)-Fr(1,m+n)        # c1*rho + c2*sigma = 0
    r,s=c2,-c1
    den=r.denominator*s.denominator//gcd(r.denominator,s.denominator)
    R,S=int(r*den),int(s*den); g=gcd(abs(R),abs(S)); R//=g; S//=g
    assert R>0 and S<0 and R+S>0
    vP=Fr(m,m+n)*(R+S); vQ=Fr(n,m+n)*(R+S)
    out=[]
    ap=vP*l/(m*R)
    if ap.denominator==1 and ap>0: out.append(('I.a',int(ap)))
    for nm,val in (('I.b, st(Q)=(k/l,0)',vQ),('I.b, st(P)=(k/l,0)',vP)):
        k=val*l/R
        if k.denominator==1 and k>0: out.append((nm,int(k)))
    return (R,S),out
def type_II(a,b,l,below):
    d=gcd(a,b)
    if d==1: return []
    ab,bb=a//d,b//d; res=[]; mu=1
    while mu<=l*(b*l-a)+Fr(1,bb):          # bound of [GGV1, Prop. 5.14(4)], with bb = b/d
        if mu%d!=0:
            X,Y=mu*ab-l,mu*bb*l-l                   # (rho,sigma) = dir(X,Y): rho*X+sigma*Y=0
            R,S=Y,-X
            g=gcd(abs(R),abs(S))
            if g:
                R//=g; S//=g
                if R>0 and S<=0 and R+S>0 and R//gcd(R,l)<=b and (below is None or Fr(S,R)<Fr(below[1],below[0])):
                    res.append((mu,(R,S)))
        mu+=1
    return res
def dirI(a,b,l): return type_I(a,b,l)[0]
def noI(a,b,l): return type_I(a,b,l)[1]==[]
def thr(a,b,l,R,S): return Fr(m,l)*Fr(a*R+b*l*S,R+S)
# --- the point A = (18/7,4), l = 7 ---------------------------------------------------------
check("A=(18/7,4): Case I impossible (direction %s)"%(dirI(18,4,7),), noI(18,4,7) and dirI(18,4,7)==(133,-83))
check("A: Case II directions, among all of I: (7,-4) [mu=3] and (7,-2) [mu=1]",
      sorted(type_II(18,4,7,None))==[(1,(7,-2)),(3,(7,-4))])
# --- direction (7,-4) -----------------------------------------------------------------------
check("direction (7,-4): the edge line meets the first axis at (2/7,0); right-hand side of (5.9) is 4/3 <= 2",
      Fr(18,7)-4*Fr(4,7)==Fr(2,7) and thr(18,4,7,7,-4)==Fr(4,3))
check("C_1=(6/7,1): l-a/b = 1 is not > 1 and gcd(6,1)=1; it lies above the diagonal side (6/7 < 1)",
      7-Fr(6,1)==1 and gcd(6,1)==1 and Fr(6,7)<1)
check("C_2=(10/7,2): Case I impossible (direction %s); Case II below (7,-4): only (14,-9)"%(dirI(10,2,7),),
      noI(10,2,7) and dirI(10,2,7)==(63,-43) and [d for mu,d in type_II(10,2,7,(7,-4))]==[(14,-9)])
check("C_2, direction (14,-9): A' = C_2 - h(9/14,1) in (1/7)Z x N_0 only for h=2: A'=(1/7,0)",
      [h for h in (1,2) if ((Fr(10,7)-h*Fr(9,14))*7).denominator==1]==[2] and Fr(10,7)-2*Fr(9,14)==Fr(1,7))
check("C_2, direction (14,-9): right-hand side of (5.9) is 4/5 <= 2", thr(10,2,7,14,-9)==Fr(4,5))
check("next corner (11/14,1), l=14: Case I impossible (direction %s); gcd(11,1)=1"%(dirI(11,1,14),),
      Fr(1,7)+Fr(9,14)==Fr(11,14) and noI(11,1,14) and dirI(11,1,14)==(56,-41) and gcd(11,1)==1)
def parts(S,mx):
    if S==0: yield (); return
    for q in range(min(S,mx),0,-1):
        for rest in parts(S-q,q): yield (q,)+rest
def caseII(bp,part): return (bp>0) + len(part) >= 2      # at least two distinct linear factors, z included
good=[(bp,part) for bp in range(0,4) for part in parts(4-bp,4) if caseII(bp,part) and all(q==3 for q in part)]
check("direction (7,-4): Case II configurations (b', multiplicities) with every mu_i = 3: only b'=1, one root", good==[(1,(3,))])
check("direction (7,-4): a root with mu=4 means b'=0 and a single linear factor (not Case II)", not caseII(0,(4,)))
check("exponents: l(P) = x^(4/7) p(z) for (7,-4), x^(20/7) p(z) for (7,-2), deg p = 8; Lemma 3.2: x^(2/7) p(z), deg p = 4",
      m*Fr(2,7)==Fr(4,7) and m*Fr(10,7)==Fr(20,7) and m*4==8 and m*Fr(1,7)==Fr(2,7) and m*2==4)
check("Lemma 3.2: x^(1/7) z^i = x^((2+9i)/14) y^i lies in L^(7) exactly for i even (i = 0,1,2)",
      [i for i in range(0,3) if ((Fr(1,7)+i*Fr(9,14))*7).denominator==1]==[0,2])
# --- direction (7,-2) -----------------------------------------------------------------------
check("direction (7,-2): the edge line meets the first axis at (10/7,0); right-hand side of (5.9) is 4",
      Fr(18,7)-4*Fr(2,7)==Fr(10,7) and thr(18,4,7,7,-2)==4)
check("D_2=(2,2) is on the diagonal; D_0, D_1 have v_{1,-1}>0; D_3=(16/7,3) has v_{1,-1}<0",
      Fr(10,7)+2*Fr(2,7)==2 and Fr(10,7)>0 and Fr(12,7)>1 and Fr(16,7)<3)
check("D_3=(16/7,3): Case I impossible (direction %s); gcd(16,3)=1"%(dirI(16,3,7),),
      noI(16,3,7) and dirI(16,3,7)==(98,-73) and gcd(16,3)==1)
# --- the corollary ----------------------------------------------------------------------------
check("corner (7,35), direction (7,-1), l=1: right-hand side of (5.9) is 14/3, so 2k >= 14/3 means k >= 3",
      thr(7,35,1,7,-1)==Fr(14,3) and 2*2<Fr(14,3)<=2*3)
check("(2,0)+k(1/7,1) = (17/7,3), (18/7,4), (19/7,5) for k = 3, 4, 5",
      [2+Fr(k,7) for k in (3,4,5)]==[Fr(17,7),Fr(18,7),Fr(19,7)])
check("(17/7,3): Case I impossible (direction %s); gcd(17,3)=1"%(dirI(17,3,7),),
      noI(17,3,7) and dirI(17,3,7)==(49,-39) and gcd(17,3)==1)
# --- controls ---------------------------------------------------------------------------------
check("control: the final corner (19/7,5) of the note on (84,126) is recognised as possible in Case I",
      type_I(19,5,7)[0]==(21,-11) and type_I(19,5,7)[1]!=[])
check("control: the point (2,3) = C_3 is recognised as possible in Case I", type_I(14,3,7)[1]!=[])
print("%d checks"%count)
print("ALL CHECKS PASSED" if ok else "SOME CHECK FAILED")
