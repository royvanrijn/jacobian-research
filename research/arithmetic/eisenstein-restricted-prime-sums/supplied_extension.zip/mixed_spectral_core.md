# Mixed Eisenstein theorem: exact ramified-prime count and odd-norm refinement

Working derivation, 17 November 2026. This note extends the established
discriminant-3 quaternion setup; it uses no conjectural theta-series identity.

Write R=Z[omega], omega^2+omega+1=0, O=R+Rj, j^2=-1, jz=bar(z)j.
The reduced norm is Q(z)+Q(w), and |{alpha in O:nrd(alpha)=n}|=12 sigma(n)
for 3 not dividing n. All Hecke operators below use the all-integral-ideal
normalization, equivalently averaging the norm-n generators with factor 1/12.

## 1. The six-point quotient at the ramified prime

The residue ring O/3O has 81 elements. An element z+w j is invertible exactly
when its reduced norm is nonzero modulo 3. If z=a+b omega and w=c+d omega,

    nrd(z+w j) = (a+b)^2+(c+d)^2 (mod 3).

Over F3 this vanishes exactly when a+b=c+d=0. There are 9 nonunits and 72
units. Therefore

    G=(O/3O)^*/F3^* has order 36.

The image Gamma of O^* has order 6; only +/-1 reduce to scalars. Its six
elements are the projective classes of 1, omega, omega^2, j, omega j, omega^2 j.
Set Y=Gamma\G. Then |Y|=6. The reduced-norm character chi:Y->{+1,-1} is
well-defined; each sign occurs at three points. Use counting measure on Y.

The standard operators T_n are well-defined for 3 not dividing n, commute
with right translation by G, have degree sigma(n), and satisfy

    T_n 1 = sigma(n) 1;
    T_n chi = chi(n) sigma(n) chi;
    T_(ell^(e+2)) = T_ell T_(ell^(e+1)) - ell T_(ell^e);
    T_ab = T_a T_b when gcd(a,b)=1.

The same ideal-principalization argument as in the unrestricted proof gives
these operators directly on Y. Alternatively the recurrences follow by
counting chains of sublattices at the unramified Hecke prime ell!=3.

### Transitivity lemma

The right action of Gamma is transitive on the three points of Y with chi=-1.

Proof: let alpha=1+j, of norm 2. Its three cosets
Gamma alpha, Gamma alpha omega, Gamma alpha omega^2 are distinct. Indeed,
modulo 3,

    alpha omega alpha^(-1) = 1+(1-omega)j.

Its square is 1+2(1-omega)j, since N(1-omega)=3. Both elements have nonzero
R and Rj components modulo 3, whereas every element of Gamma has one component
zero. Neither belongs to Gamma, proving that the orbit has length three.

### Consequence for inert Hecke indices

If n=2 (mod3), every nonzero entry in the base row of T_n lies in the opposite
norm class. The row is invariant under the right stabilizer Gamma. The
transitivity lemma forces its three entries to be equal, each sigma(n)/3.
Right G-invariance then gives the same assertion in every row. Thus T_n is
the weighted complete-bipartite operator on the two norm classes.

In particular, on W={1,chi}^perp,

    T_ell|W=0 for every inert prime ell=2 (mod3).

By the Hecke recurrence,

    T_(ell^(2k))|W=(-ell)^k I,
    T_(ell^(2k+1))|W=0.

Consequently, if every prime factor of n is inert, then

    T_n|W=lambda_n I,

where lambda_n=0 when n is not a square, and
lambda_n=(-1)^(Omega(n)/2) sqrt(n) when n is a square.
Omega counts prime factors with multiplicity. No spectral estimate or
modularity theorem is needed for this specific identity.

## 2. Exact count of the unwanted ramified divisibility

Assume n=1 (mod3). Exactly one of the two component norms in every norm-n
quaternion is divisible by 3. Its 3-adic valuation is at least two precisely
when its Eisenstein component is divisible by 3: the ramified prime pi=1-omega
has norm 3 and pi^2 is associated to 3.

Let B_3(n) count norm-n quaternions with either component divisible by 3,
including zero components. In O/3O the relevant units have one component
zero. There are 12 such units, and their projective classes are precisely
Gamma: a component in R/3R is a unit exactly when its coefficient sum is
nonzero, and its six units are the reductions of R^*.

Writing delta for the indicator of the identity point Gamma in Y gives

    B_3(n)=12(T_n delta)(Gamma).

The projection of delta onto span{1,chi} is (1+chi)/6. The orthogonal
remainder h has squared norm 2/3. For inert-supported n=1 (mod3), therefore,

    B_3(n)=4 sigma(n)+8 lambda_n.                         (1)

This proves the exact formula that is also suggested by the CM newform
eta(3z)^2 eta(9z)^2; that identity is not required here.

For arbitrary n prime to 3, the classical weight-two bound on the six-point
quotient would instead give B_3(n)/r(n)<=1/3+(2/3)tau(n)sqrt(n)/sigma(n),
but the reduced inert-supported case (1) is sharper and elementary.

## 3. Remove even component norms before sieving

Let n=2^e m be an even target with 3 not dividing n, e>=1 and m odd. Since 2
is inert, an Eisenstein norm is even exactly when both its coordinates are
even. The two component norms have the same parity. Thus representations
with odd component norms are exactly the norm-n quaternions not divisible
by 2. Their number is

    r_odd(n)=12 S(n),
    S(n)=sigma(n)-sigma(n/4)=3*2^(e-1)*sigma(m)>=3n/2,    (2)

where sigma(n/4)=0 if 4 does not divide n. This removes all zero components
as well, avoiding an infinite odd-prime union caused by divisibility of zero.

For every odd-prime quotient, including the six-point quotient above, the
operator counting these representations is

    D_n=T_n-T_(n/4),                                    (3)

with the second term zero when 4 does not divide n. Multiplication by 2 is
projectively scalar at every such prime. Consequently the subtracted
representations have exactly the same residue point as their quotient by 2.

### Spectral refinement of D_n

At an odd inert sieving prime p not dividing n, the usual noncharacter
eigenvalues can be written with Satake parameters u,v at 2, |u|=|v|=1,
uv=1. For e>=1,

    a_(2^e)-a_(2^(e-2))
      =2^(e/2)[u^e+v^e+(1/2)sum_(r=1)^(e-1)u^r v^(e-r)].

For e=1 the interior sum and the subtracted term are absent. Thus on the
noncharacter subspace,

    ||D_n|| <= ((e+3)/2)*2^(e/2)*tau(m)*sqrt(m).          (4)

The constant and determinant characters have eigenvalues S(n) and
chi(n)S(n), because 4 is a square. Normalizing (4) by (2) gives the local
factor

    ((e+3)/3)*2^(-e/5)

after extracting n^(-3/10). Its maximum for e>=1 is at e=4. Combining it
with the odd inert-prime local factors from the unrestricted divisor bound
gives the proposed uniform constant 9/4 (to be checked by the exact constants
verifier). The algebraic identity (4) and the maximizing exponent are exact.

### Ramified bad count among odd-norm representations

By (1) and (3), for inert-supported n=1 (mod3),

    B_3,odd(n)=4S(n)+8(lambda_n-lambda_(n/4)).            (5)

If n is nonsquare then both lambda terms are zero. If n is square then e>=2
and lambda_(n/4)=-lambda_n/2. Therefore

    B_3,odd(n)/(12S(n))
        =1/3                                   if n nonsquare;
        =1/3+lambda_n/S(n)                      if n square;
        <=1/3+2/(3sqrt(n))                      in either case.   (6)

The factor 2/(3sqrt(n)) follows from S(n)>=3n/2 and
|lambda_n|=sqrt(n). No factor tau(n) remains in this error.

## 4. Constants and large primes after this refinement

All remaining component norms are positive and odd. Dividing a component
by an odd inert p gives at most 6n/p^2 possibilities for its nonzero
Eisenstein quotient; the other component has at most 6M(n) possibilities.
Using (2), the normalized two-component union bound is therefore

    b_p,odd(n)/(12S(n)) <=4 M(n)/p^2.

With E(n)<=9/4 n^(-3/10), M(n)<=15/8 n^(1/5), and P=2X, X=n^(1/4),
the previously established elementary prime estimates give total odd-inert
bad fraction less than

    3/20+(11/10)X^(-1/5)+(111/20)X^(-6/5).

Adding (6) gives

    29/60+(11/10)X^(-1/5)+(111/20)X^(-6/5)+2/(3X^2).

For X>=100, the rational bounds X^(-1/5)<2/5 and X^(-6/5)<1/250 imply
that this is strictly below

    29/60+11/25+111/5000+1/15000=591/625<1.

Thus the mixed infinite range closes at n>=100^4, subject to the existing
odd-prime spectral lemma, the exact 9/4 divisor-constant check, and the
already established elementary prime/lattice estimates.
