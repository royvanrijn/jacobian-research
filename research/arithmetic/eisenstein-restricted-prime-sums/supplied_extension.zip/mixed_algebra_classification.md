# Primitive Eisenstein norms and all higher sumsets

17 November 2026. The algebraic deductions below assume the two binary
statements established in the companion proof drafts:

\[
A+A=\{n>0:n\equiv2\pmod6\},\qquad
A+3A=\{n>0:n\equiv4\pmod6\},
\]

where \(A=\{1\}\cup\{n>1:p\mid n\Rightarrow p\equiv1\pmod3\}\).
The second assertion is the new input needed for the full primitive
classification. These deductions do not assert that the literature has
not previously established them.

## 1. Classical characterization of primitive Eisenstein norms

Let \(R=\mathbb Z[\omega]\), \(\omega^2+\omega+1=0\), and
\(Q(x,y)=x^2-xy+y^2\). Put

\[
\mathcal P=\{Q(x,y)>0:\gcd(x,y)=1\}.
\]

Then

\[
\boxed{\mathcal P=A\sqcup3A.}
\]

**Necessity.** An inert rational prime \(p\equiv2\pmod3\) divides
\(Q(x,y)\) only if it divides both coordinates. Hence it cannot divide a
primitive norm. At the ramified prime, \(3\) is associated in R to
\((1-\omega)^2\). If the norm is divisible by 9, then \(x+y\omega\)
is divisible by \((1-\omega)^2\), hence by the rational integer 3;
both coordinates are divisible by 3. Thus the exponent of 3 is at most
one. All other factors are split primes 1 modulo 3.

**Sufficiency.** Given \(a=\prod p_i^{e_i}\in A\), choose one prime
\(\pi_i\) above each split \(p_i\), and set
\(z=(1-\omega)^\epsilon\prod\pi_i^{e_i}\), \(\epsilon\in\{0,1\}\).
Its norm is \(3^\epsilon a\). No rational prime divides z: at a split
prime this would require both conjugate factors, at 3 it would require
two ramified factors, and no inert factor occurs. Therefore the two
coordinates of z are coprime.

This is a standard UFD consequence, not a new classification of individual
norms.

## 2. Exact two-norm classification

Combining the binary theorems gives

\[
\mathcal P+\mathcal P
=(A+A)\cup(A+3A)\cup3(A+A).
\]

The three pieces have residues respectively

\[
\{2,8,14\},\quad\{4,10,16\},\quad\{6\}\pmod{18}.
\]

Consequently a positive integer n is a sum of two positive primitive
Eisenstein norms if and only if

\[
\boxed{n\text{ is even and }n\not\equiv0,12\pmod{18}.}
\]

Equivalently, the equation

\[
n=x^2-xy+y^2+u^2-uv+v^2,
\qquad \gcd(x,y)=\gcd(u,v)=1
\]

has an integral solution exactly in those congruence classes. Zeros in an
individual coordinate are permitted; the norm of a primitive pair is
always positive. Replacing y and v by their negatives gives the identical
classification for the plus-sign version of the Eisenstein form.

The excluded classes are genuine local obstructions. Both primitive norms
are odd. If their sum is divisible by 3, both norms must lie in 3A, and
each is 3 modulo 18; their sum must be 6 modulo 18.

## 3. Higher sumsets of A and the sharp seven-term bound

For each integer \(k\ge2\),

\[
\boxed{kA=\{n\ge k:n\equiv k\pmod6\}.}
\]

Necessity follows from every summand being positive and 1 modulo 6.
For sufficiency, subtract \(k-2\) ones and apply the binary A+A theorem
to the remaining integer, which is at least 2 and 2 modulo 6.

Every positive integer is therefore a sum of at most seven members of A.
For residues 2 through 5 choose that number of summands; use six for residue
0. For residue 1, use one summand if the integer lies in A, and otherwise
seven. The latter integer is necessarily at least 7.

Seven is optimal: 25 is not in A, while a representation of 25 has a
number of terms congruent to 1 modulo 6. Fewer than seven terms would force
one term, which is impossible. A seven-term representation is

\[
25=13+7+1+1+1+1+1.
\]

This is an at-most-seven assertion. For a fixed k, kA lies in one residue
class, so A itself is not a fixed-order additive basis of all integers
under the convention requiring exactly k summands. Adjoining zero gives
an additive basis of order seven.

The shifted set \(B=\{(a-1)/6:a\in A\}\) contains zero and satisfies
\(B+B=\mathbb N_0\), a convenient equivalent formulation of the binary
theorem.

## 4. All higher sumsets of primitive norms

A further consequence of the mixed theorem is

\[
\boxed{k\mathcal P=\{n\ge k:n\equiv k\pmod2\}\quad(k\ge3).}
\]

It suffices to prove the case k=3. For an odd n>=3, distinguish its residue
modulo 6:

- If n=3 modulo 6, the three-summand A theorem applies.
- If n=5 modulo 6, write n=3+(n-3), using A+A for the second part.
- If n=1 modulo 6, then n>=7; write n=3+(n-3), using A+3A for the second
  part.

These are all three-term representations in P. For k>=3 and an integer
n>=k of the required parity, n-(k-3) is an odd integer at least 3. Apply
the three-term case and add k-3 ones. Necessity is positivity and the
oddness of every primitive norm.

It follows that every positive integer is a sum of at most **four**
primitive Eisenstein norms: 1 is a single norm, 2=1+1, every odd n>=3
uses three, and every even n>=4 uses four. Four is optimal because 12 is excluded from
P+P, and an even integer requires an even number of odd summands; indeed
12=3+3+3+3. These are corollaries of the two binary theorems, not independent
analytic breakthroughs.

## 5. No constant-size summand menu

The finite certificate's small first summands cannot remain uniformly
bounded for all targets. For any finite S contained in A, choose distinct
odd inert primes q_s and impose

\[
N\equiv s\pmod{q_s}\ (s\in S),\qquad N\equiv2\pmod6.
\]

CRT gives arbitrarily large solutions. For N>max S, every N-s is positive
and contains a forbidden prime factor. Therefore no representation can
use a summand in S. Taking S to contain all allowed integers below a fixed
bound proves that the least valid summand is unbounded across targets.
