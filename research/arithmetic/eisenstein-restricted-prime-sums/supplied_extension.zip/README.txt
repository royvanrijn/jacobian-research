RESTRICTED-PRIME SUMS AND PRIMITIVE EISENSTEIN NORMS
Extended research package, 17 November 2026

Main statements
Let A be the positive integers whose prime factors are all 1 (mod 3),
including 1. The proof note establishes:
  n=a+b, a,b in A, exactly when n=2 (mod 6).
  n=a+3b, a,b in A, exactly when n=4 (mod 6).
If P is the set of positive primitive Eisenstein norm values, then
P=A union {3a:a in A}. Its binary sumset is exactly the positive even
integers outside residue classes 0 and 12 modulo 18.

For k>=2, the k-fold sumset of A is {n>=k:n=k (mod 6)}.
Every positive integer is a sum of at most seven members of A; 25
requires seven. For k>=3, the k-fold sumset of P is
{n>=k:n=k (mod 2)}. At most four primitive norms suffice, and 12
requires four. The final section gives an abstract orbit-sieve theorem
with all transfer hypotheses explicit.

Status
The accompanying note is a complete proof draft, using the classical
Jacquet-Langlands correspondence and the weight-two Ramanujan bound.
The algebra, normalization, constants, and finite checks were reviewed
within this research session. External specialist review and a full
novelty audit remain outstanding. Do not describe this as a refereed
result or claim priority from this package alone.

The updated argument filters even component norms before sieving and
uses an exact six-point quotient at 3 for the mixed case. Its analytic
bound applies to reduced targets at least 100,000,000. The excluded
fraction is strictly below 591/625, so a valid representation survives.
The finite certificates cover 16,666,667 targets for A+A and 16,666,666
for the mixed problem, all below 100,000,000. There are no exceptions.
A smaller summand at most 211 suffices for A+A in this finite range;
the mixed equation needs b at most 199. These finite witness bounds
are not claimed for arbitrarily large targets.

The balanced assertion, n/3 <= a,b <= 2n/3 in A+A, remains conjectural
beyond the checked range. Its only exceptions below 100,000,000 are
8 and 44. The exploratory balanced notes do not constitute a proof.

Independent verification (Java 21, no external dependencies)
From this directory:
  java -Xmx512m VerifyEisenstein.java 100000000 rerun_original_java.json
  java -Xmx512m VerifyMixedEisenstein.java 100000000 rerun_mixed_java.json
These rebuild their sieves, check every target, and emit hashes and
coverage histograms. They do not read the Python results. The original
verifier also checks the balanced condition.

Python verification (Python 3 and NumPy)
  python compute_finite_certificate.py --limit 99999999 --output rerun_original
  python compute_mixed_certificate.py --limit 99999999 --output rerun_mixed
These emit receipts and compressed arrays containing all witnesses.
The generated arrays are omitted from this small source archive because
they can be reproduced. Java uses an exclusive bound, Python an inclusive
bound. See README_verification_addendum.md for endpoints and sieve proof.

Additional checks
  python compute_elementary_constants.py
  python compute_theta_checks.py
  python spectral_check.py
  python compute_mixed_ramified_checks.py
  python compute_mixed_odd_checks.py
  python compute_mixed_wheel_checks.py
  python mixed_spectral_check.py
Inspect command-line options before choosing output paths. The elementary
constants use exact rational arithmetic. Numerical eigenvalue checks are
diagnostics, not proofs of the spectral theorem. The finite target
certificates, coordinate identities, and constant comparisons are exact.

Files
  eisenstein_proof_note.tex: canonical full argument and references.
  VerifyEisenstein.java and VerifyMixedEisenstein.java: independent Java
                    target-by-target finite verifiers.
  compute_finite_certificate.py and compute_mixed_certificate.py: NumPy
                    finite sieves and witness verifiers.
  compute_elementary_constants.py: original local maxima and cutoff check.
  compute_mixed_odd_checks.py: updated exact constant and parity identities.
  compute_mixed_wheel_checks.py: all-real prime-count and tail bounds.
  *_receipt.json, finite_*/receipt.json: results and cross-language checks.
  spectral_core.md: earlier unfiltered spectral derivation; its final
                    work-status paragraph is historical.
  mixed_spectral_core.md: exact ramified count and filtered operator.
  mixed_algebra_*.md: algebraic consequences and the abstract criterion.
  literature_*.md: literature review and clearly marked unfinished work
                    on the balanced extension.

Credit and provenance
The research was prompted by Howe, Huffman, Kohlmeyer and Kruer's Euler
preprint (Hexagon 2611.00370v1). The torus-normalizer averaging method is
adapted from that work. The Eisenstein specialization, exact ramified
count, constants, certificates, and proof draft were developed with
ChatGPT for Roy van Rijn. Standard inputs are cited in the proof note.
