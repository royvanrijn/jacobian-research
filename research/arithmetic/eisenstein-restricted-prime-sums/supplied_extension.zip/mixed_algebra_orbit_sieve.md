# An abstract orbit-averaging sieve criterion

17 November 2026. This is a precise reusable implication. It does not
claim that arbitrary quadratic forms or number fields satisfy its
hypotheses, and no novelty claim is made for the operator lemma or the
union-bound criterion.

## 1. Finite-orbit operator lemma

Let a finite group G act transitively on a finite set Y, with base point
y0. Give C[Y] counting measure. Let K<=G, let O=y0 K, put f=1_O, and
let mu=|O|/|Y|. Suppose T is a self-adjoint operator commuting with the
G-action, with T1=d1, d>0. Suppose E is a T-invariant subspace containing
1 such that

\[
f-\mu1\perp E,\qquad \|T|_{E^\perp}\|\le\Lambda.
\]

Then

\[
\boxed{\frac{(Tf)(y_0)}d
\le\mu+\frac\Lambda d(1-\mu).}
\]

**Proof.** Since f is K-invariant and T commutes with K, Tf is constant
on O. Consequently

\[
(Tf)(y_0)=\frac{\langle f,Tf\rangle}{|O|}.
\]

Write f=mu*1+h. The constant and h terms are orthogonal, and
\(\|h\|^2=|O|(1-\mu)\). The constant contribution divided by |O| is
\(d\mu\), while the remaining quadratic form is at most
\(\Lambda(1-\mu)\). This proves the bound.

For Y=Gamma\\G and Gamma<=K, O=Gamma\\K. In the Eisenstein problem,
the prime-obstruction event is constant on unit classes, so its relative
representation count is exactly (Tf)(y0)/d. In other settings that
identification must be proved; it is not part of the abstract operator
lemma. The exceptional space E includes any norm-character constituents
with large eigenvalues, not merely the constants.

## 2. Explicit representation criterion

Fix a set of sieving primes \(\mathscr P\); every prime sum and count below
is over this same set. For each admissible target n, let R_n be a nonempty finite collection of
representations, with size R(n). Suppose that removing the exceptional
bad set E_n and all prime-indexed bad sets B_p(n) guarantees that every
remaining representation produces the required positive summands.
Assume, for a cutoff P,

\[
\frac{|E_n|}{R(n)}\le\eta(n),
\qquad
\frac{|B_p(n)|}{R(n)}\le\mu_p+\mathcal E(n)
\quad(p\le P),
\]

and

\[
\frac1{R(n)}\sum_{p>P}|B_p(n)|
\le C\,M(n)\sum_{p>P}p^{-2}.
\]

Then a good representation exists whenever

\[
\boxed{\eta(n)+\sum_{p\le P}\mu_p
 +\#\{p\le P\}\,\mathcal E(n)
 +C M(n)\sum_{p>P}p^{-2}<1.}
\]

**Proof.** Divide the union bound for
\(E_n\cup\bigcup_{p\in\mathscr P}B_p(n)\) by R(n), split the prime sum
at P, and insert the three displayed estimates. Its right side is less
than one, so that union cannot exhaust R_n. The tail hypothesis makes the
sum convergent; equivalently, since R_n is finite, one may first apply the
argument to finite subunions and pass to the union.

The finite-orbit lemma supplies small-prime
estimates that do not lose a factor growing with p. Independence of prime
obstructions is not required. Overlaps only improve the conclusion.

Filtering some local obstructions exactly before applying the criterion
can improve both R(n) and the spectral normalization. In the mixed
Eisenstein problem, T_n-T_(n/4) counts the representations with odd
component norms; treating 2 as an additional union-bound loss would give
weaker constants.

## 3. An effective eventual theorem under explicit hypotheses

Suppose all constants in the following bounds are nonnegative, and the
bounds hold uniformly for admissible n>=n_0 and real P>=P_0:

\[
\eta(n)\le\eta_0+\epsilon_0(n),\qquad
\sum_p\mu_p\le S_0,\qquad \eta_0+S_0<1,
\]

\[
\mathcal E(n)\le C_1 n^{-1/2+\varepsilon},\qquad
M(n)\le C_2 n^\varepsilon,\qquad 0\le\varepsilon<1/4,
\]

and

\[
\#\{p\le P\}\le\alpha P+\beta,\qquad
\sum_{p>P}p^{-2}\le\gamma/P+\delta/P^2.
\]

Assume epsilon0(n) has an effective modulus of convergence to zero: for
every u>0 we can compute N_0(u) such that epsilon0(n)<=u for all
admissible n>=N_0(u). Taking
\(P=t n^{1/4}\), for any fixed t>0 and n>=(P_0/t)^4,
gives the sufficient inequality

\[
\eta_0+S_0+\epsilon_0(n)
 +\left(\alpha t C_1+\frac{C C_2\gamma}{t}\right)
      n^{-1/4+\varepsilon}
 +\left(\beta C_1+\frac{C C_2\delta}{t^2}\right)
      n^{-1/2+\varepsilon}<1.
\]

**Proof and explicit cutoff.** Put
\(\Delta=1-\eta_0-S_0>0\),
\(a=1/4-\varepsilon>0\), \(b=1/2-\varepsilon>0\), and let L_1,L_2
denote the two parenthesized coefficients in the displayed inequality.
Then every admissible n at least

\[
\max\left\{n_0,(P_0/t)^4,N_0(\Delta/4),
 (4L_1/\Delta)^{1/a},(4L_2/\Delta)^{1/b}\right\}
\]

has total bad fraction at most
\(\eta_0+S_0+3\Delta/4=1-\Delta/4<1\). Terms with L_i=0 impose no
additional restriction. This proves an effective eventual theorem. A
smaller cutoff may be obtained by directly solving the preceding sufficient
inequality. If alpha*C1 and C*C2*gamma
are positive, the leading coefficient is minimized at

\[
t=\sqrt{\frac{C C_2\gamma}{\alpha C_1}}.
\]

An exact finite certificate for every remaining admissible target completes
the full theorem. If a multiplicative reduction is used, its lifting rule
must also be proved: for example, multiplying both summands by g in A
preserves A+A and A+3A. A failure at a reduced small target cannot simply
be declared a failure of all its multiples; alternative representations
can appear, so exception classification needs a separate argument.

## 4. What must be rebuilt in another arithmetic problem

To apply this framework to another norm form one must establish:

1. A correct admissible target set and exact characterization of the
   desired summands, including ramified primes and signs.
2. A nonempty representation family and its total count or a suitable
   uniform lower bound.
3. The bad-prime implication on coordinates and a large-prime lattice
   estimate with explicit constants.
4. The relevant finite quotient, obstruction orbit, unit-class counting
   factor, exceptional characters, and normalized spectral estimate.
5. A strict main-term margin eta0+S0<1, an effective cutoff, and a
   reproducible finite certificate.

Higher class number can introduce several ideal classes and a matrix of
representation counts. Different discriminants can create additional
congruence obstructions or a main-term loss too large for this simple
union bound. Those are genuine new obligations. The framework is a
theorem about verified inputs, not a universal representation theorem
for all primitive binary norms.
