# Reproducing the original and mixed finite certificates

The verifier sources are unchanged from the certificate runs. Commands
below run from the directory containing the source files. Java 21 needs no
external dependencies; Python needs Python 3 and NumPy. Neither implementation
reads an existing receipt or witness archive to establish coverage.

## Exact finite computations

These commands rebuild all membership information and check every target from
scratch. Output names below are new, so the supplied receipts remain intact.

```sh
java -Xmx512m VerifyEisenstein.java 100000000 rerun_original_java.json
python compute_finite_certificate.py --limit 99999999 --output rerun_original_python
java -Xmx512m VerifyMixedEisenstein.java 100000000 rerun_mixed_java.json
python compute_mixed_certificate.py --limit 99999999 --output rerun_mixed_python
```

The Java bound is **exclusive**; the Python bound is **inclusive**. Therefore
the displayed commands cover precisely the same targets in each problem.

| Problem | Targets | Last target below the cutoff | Result |
|---|---:|---:|---|
| `N=a+b`, `N=2 mod6` | 16,666,667 | 99,999,998 | Every target covered; least smaller summand at most 211 |
| `N=a+3b`, `N=4 mod6` | 16,666,666 | 99,999,994 | Every target covered; least `b` at most 199 |

The original verifier also checks `N/3 <= a <= b <= 2N/3`. Its exceptions
below the cutoff are exactly 8 and 44. This is a finite result and does not
establish the unrestricted balanced assertion.

For the original problem, Java tries every admissible smaller summand through
211; zero uncovered targets proves the finite existence statement. Python
finds the least smaller summand independently. For the mixed problem, both
programs search all required candidate indices until a witness is found;
Java has no preassigned cap on `b`. It would exhaust the entire permitted
range before reporting a genuine counterexample.

The Python programs emit compressed witness archives. These are **outputs**,
not required inputs. The Java programs stream witness hashes without storing
the archives. The two implementations agree on every membership bit and every
witness index, as well as their coverage histograms.

## Why the membership sieve and endpoints are exact

Index `j` denotes the positive integer `6j+1`. This automatically excludes
prime factors 2 and 3 and admits 1. Every product of primes `1 mod3` has this
form. An integer of this form containing a forbidden prime has an even number
of prime factors `2 mod3`, counted with multiplicity. Consequently one such
factor is at most its square root.

Every candidate summand here is below 100,000,000, so sieving primes through
9999 suffices. Both programs use precisely the odd forbidden primes
`p=5 mod6`. Python marks all indexed multiples, starting at `5p`. Java marks
from `p*p`; any smaller forbidden multiple was already removed by a smaller
forbidden prime. These constructions yield identical membership bits.

The original equation on indices is `i+j=k` for `N=6k+2`; the mixed equation
is `i+3j=k` for `N=6k+4`. All indices are nonnegative, so both summands are
strictly positive. The initial targets are 2 and 4, respectively, and the
summand 1 is available in both computations.

To join the finite and analytic ranges, write an arbitrary admissible target
as `N=g*N0`, removing all prime powers with primes `1 mod3` into `g`.
Then `g` belongs to the allowed set and is `1 mod6`, so `N0` retains the
required residue class. If `N0<100000000`, the finite certificate covers it;
otherwise the analytic theorem covers it. Multiplying its summands by `g`
preserves both the allowed set and either equation. A large original target
whose reduced target is small is therefore covered as well. The mixed target
100,000,000 itself belongs to the analytic range, so there is no boundary gap.

## Supplied receipts

The following are the final receipts for the full finite ranges:

- `finite_below_100000000/receipt.json`
- `java_finite_receipt.json`
- `cross_language_verification_receipt.json`
- `mixed_finite_below_100000000/receipt.json`
- `mixed_java_below_100000000_receipt.json`
- `mixed_cross_language_below_100000000_receipt.json`

Supporting exact arithmetic and finite identity receipts are:

- `elementary_constants_receipt.json`
- `theta_checks_3000.json`
- `mixed_ramified_checks_3000.json`
- `mixed_odd_checks_receipt.json`
- `mixed_wheel_checks_receipt.json`

Additional `2000000` receipts retain the initial smaller runs. They are not
needed to complete the full finite certificate.

## Elementary constants and the wheel estimates

The corresponding source checks are:

```sh
python compute_elementary_constants.py
python compute_theta_checks.py --limit 3000 --max-prime 53 --output rerun_theta.json
python compute_mixed_ramified_checks.py --limit 3000 --output rerun_mixed_ramified.json
python compute_mixed_odd_checks.py
python compute_mixed_wheel_checks.py
```

The constants scripts regenerate their named receipts. They compare rational
fifth powers exactly. For the original divisor constant, the maximizing
exponents at inert primes `2,5,11,17,23,29` are `6,2,1,1,1,0`; for the mixed
constant the exponent at 2 changes to 4. For the norm multiplicity constant,
the exponents at split primes `7,13,19,31` are `2,1,1,1`. All subsequent
exponents are controlled by decreasing next-term ratios. Primes at least 32
contribute at most one because `e+1 <= 2^e`. Thus the finite tables establish
global constant bounds, rather than merely testing a chosen exponent range.

The wheel comprises residues `11,17,23,29 mod30`, together with the exceptional
prime 5. Its discrepancy from `2t/15` lies between `-22/15` and `2/15`, as
proved by its four jumps in one period. Therefore, for every real `P>=5`,

\[
\#\{p\le P:p\text{ odd prime},\ p\equiv2\pmod3\}
\le\frac{2P}{15}+\frac{17}{15},\qquad
\sum_{\substack{p>P\\p\text{ odd prime},\ p\equiv2\pmod3}}p^{-2}
\le\frac{2}{15P}+\frac{8}{5P^2}.
\]

Prime 5 supplies the extra 1 in the count and is absent from the tail because
`P>=5`. Prime 2 is separately handled in the original argument and exactly
filtered in the mixed argument. Prime 3 is ramified and is handled separately
in the mixed argument. There is no omitted exceptional prime.

The application takes `P=2*N^(1/4)>=200`, so the estimates apply without
integer rounding. The all-prime main term is bounded by

\[
\sum_{p\text{ odd},\ p\equiv2\ (3)}\frac{2}{p(p-1)}
\le\frac1{10}+\frac1{55}+\frac1{136}+\frac1{48}
=\frac{6569}{44880}<\frac3{20}.
\]

The last term bounds all remaining `6k-1` by a decreasing-function integral.
These elementary arguments justify the wheel estimates uniformly. The finite
theta, CM, and eigenvalue checks are diagnostics; they do not replace the
separate written proofs of the spectral and theta identities.
