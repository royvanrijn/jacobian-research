# Recovered original SFC worktree

This is a byte-preserving backup of the earlier SFC investigation workspace, made on 22 November 2026. It preserves actual proof documents, code, exact certificates, and recorded verification receipts. It is not a new proof audit and it is not the final 22 November continuation.

## What was recovered

| Item | Recorded value |
| --- | --- |
| Repository | `royvanrijn/jacobian-research` |
| Source worktree | `/workspace/scratch/01dcaf73b7a8/stepanov-investigation` |
| Source branch | `research/stepanov-auxiliary-audit` |
| Base / worktree HEAD | `19eb9912fb60142f8b620dac24896931d4ff3e46` |
| Locally available history | 10 commits; source clone is shallow |
| Uncommitted research files | 120 new files, marked intent-to-add in Git |
| Breakdown | 34 Markdown, 40 Python, 45 JSON, 1 compressed JSONL certificate |
| Uncommitted source bytes | 4,794,068 |
| Additional preserved local artifacts | 169 ignored research artifacts; 5 literature copies indexed separately |
| Truly untracked files | 0 |
| Reflog-only commits | 0 |

The primary companion worktree at `/workspace/scratch/01dcaf73b7a8/jacobian-research` was clean and detached at `402bd225f7dfe9ee2504ec27994ee466b180ce55`. The saved source repository's remote-tracking `origin/main` was at the newer base above. This records local state at recovery time; it is not a claim about the current live GitHub branch.

All 120 new files live under `research/factorial/image-rigidity/`. Their exact paths, byte sizes, SHA-256 checksums, modes, and original modification times are in `metadata/file-manifest.json`.

## Contents and restoration

- `working-tree-files.tar.gz`: the 120 actual new files, preserving repository-relative paths.
- `tracked-working-tree.patch`: Git binary patch from the recorded HEAD to the working tree, including the compressed certificate.
- `unstaged.patch`: the original unstaged Git binary diff. Here it has the same contents as the HEAD-to-working-tree patch.
- `staged.patch`: empty, because no content was staged; the index had intent-to-add entries.
- `ignored-research-artifacts.tar.gz`: 169 local SFC research artifacts, including exact replay material. Retrieved literature copies are represented by names and digests in `REFERENCE_COPY_INDEX.json`. Python caches were excluded.
- `untracked-files.tar.gz`: empty archive, recording that no ordinary untracked files were present.
- `metadata/`: original status, branches, refs, logs, reflogs, shallow boundary, index records, file manifest, and recovery validation.
- `SHA256SUMS`: checksums for the backup files themselves.

### Restore the research into a clean checkout

Use a fresh clone of the repository and check out the exact recorded base. In that clean checkout, apply `tracked-working-tree.patch` with `git apply --binary`. This recreates the 120 new files without making a commit. Alternatively, extract `working-tree-files.tar.gz` into that checkout; do not both extract and apply the patch.

Extract `ignored-research-artifacts.tar.gz` into the same checkout if local replay inputs or historical controls are needed. These paths were intentionally ignored in the original repository and need not be committed merely because they have been backed up.

Do not overwrite an active dirty worktree. Do not copy `metadata/original-index` into an unrelated checkout: it is retained as forensic evidence of the original index state, not as a portable replacement for Git's index. Before preparing a new PR, compare these files with current `main` and with the later recovered SFC bundle so that newer research is not replaced by this earlier snapshot.

The full source Git bundle was also created and passed `git bundle verify`, but it is intentionally excluded from this compact backup because the base history is already repository-backed. Its recorded size is 256,675,789 bytes. Its scratch location and checksum appear in `metadata/recovery-validation.json`; that optional scratch copy is not itself a promise of durable availability. The source clone was shallow, so complete historical ancestry must not be inferred from that bundle.

## Mathematical checkpoint in the preserved files

The authoritative entry points in this particular snapshot are:

1. `SFC_STRUCTURAL_CLOSURE.md`: a 21 November synthesis separating proved structural families from the missing unrestricted implications.
2. `SFC_GENERAL_CLOSURE_RESEARCH_PROGRAMME.md`: the precise sharp monomial-linear and unrestricted-support targets.
3. `stepanov_investigation_manifest.json`: source inventory, recorded replay scopes, failed approaches, and explicit open-status flags.
4. `STEPANOV_SFC_PROGRESS_AND_LOWER_THREE_CLOSURE.md`: the two-support and earlier Stepanov synthesis.

The latest additions in this older worktree cover shifted-resultant positivity at binary starting orders one through five, the moving-caustic/common-factor certificate, and obstructions to two universal scalar-operator shortcuts. Their detailed sources are:

- `SFC_SHIFTED_RESULTANT_POSITIVITY_AUDIT.md`
- `SFC_POINTED_PENCIL_AND_CAUSTIC_DESCENT.md`
- `SFC_DIFFERENTIAL_BRANCH_OBSTRUCTIONS.md`

The retained notes explicitly state that **neither unrestricted SFC nor all two-support SFC is closed**. The general monomial-linear fixed-window theorem uses windows longer than the sharp SFC support-size window; the exact initial resultant and bounded shifted-window identities do not supply a universal all-order proof. Scalar-operator countercontrols refute the proposed shortcuts, not SFC itself.

These are descriptions of the preserved research record. The preservation task did not rerun its mathematical checkers or independently reprove its theorems.

## Integration blocker recorded by this snapshot

The original manifest records `registry_changed=false` and `generated_navigation_changed=false`. Its stated blocker is an existing supporting-checker mismatch in `FACTORIAL-UNIFORM-BOUNDED-QUARTIC-CUSP-EXCLUSION`, encountered before navigation generation. It reports additional stale source pins in several existing replays. These are preserved historical diagnostics, not newly rerun failures.

No commit containing these 120 new files exists in this local history. No PR URL is evidenced by this worktree. The newer final continuation recovered from the shared conversation must be assessed separately.

## Relationship to the complete conversation recovery

The actual SFC shared conversation is:

https://chatgpt.com/share/6b031511-3ce8-83ed-95da-e89618c18a97?ogimg=plain

The parent recovery process located a later item labeled **Complete proof and certificate bundle** in that conversation:

https://chatgpt.com/library?file_id=libfile_fde3_f-ca93da3441b88191bed98d358bb366f4_e0b696548c148191b3603f7a82f53995&account_id=personal

That later bundle is separate from this worktree snapshot. The final reachability/backward-recurrence work concerning the two density candidates `(11,10,11,1)` and `(11,5,6,1)` was not found among this snapshot's files. Do not equate the 120-file backup with complete coverage of the final conversation.

## Preservation checks actually performed

- The original recovery checked all 294 payloads. This combined package retains all 120 research files and 169 supplementary research payloads; the 5 retrieved literature copies are indexed separately.
- The binary patch passed `git apply --check` in an isolated empty directory.
- Applying the patch recreated all 120 changed files; every reconstructed SHA-256 matched the source manifest.
- Source Git status before and after recovery was identical.
- All preserved source contents were rechecked after the backup and remained unchanged.
- The optional repository bundle passed `git bundle verify`.

These checks establish faithful recovery of the recorded bytes. They do not establish mathematical correctness, external review, formal verification, successful PR creation, or complete recovery of the later continuation.
