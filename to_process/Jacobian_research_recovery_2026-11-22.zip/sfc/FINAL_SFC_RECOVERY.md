# Final SFC checkpoint recovered and replayed

**Recovery result: complete original checkpoint restored; all original checks pass.**

Source conversation: [Research Priority Recommendations](https://chatgpt.com/share/6b031511-3ce8-83ed-95da-e89618c18a97).

Original artifact: [sfc_obstruction_audit.zip](../original-checkpoints/sfc_obstruction_audit.zip).

This report concerns preservation and replay of the exact final artifact. It is not a new research result, external mathematical review, formal proof, or transcript export.

## 1. Archive identity and completeness

| Check | Result |
|---|---|
| Archive size | 33,410 bytes |
| SHA-256 | `a2306d3f1f3570d4af7b1ed9c0c1f801b3bee330adee2d4924fc26bbbe9e74aa` |
| ZIP CRC validation | Pass |
| Safe extraction | No absolute paths, parent traversal, or symbolic links |
| Package contents | Exactly 14 files |
| Manifest verification | All 13 listed content hashes and byte lengths match; the fourteenth file is the manifest itself |
| Missing manifest entries or unexpected files | None |
| Original archive and extracted source bytes | Preserved unchanged |

The recovered package is self-contained: it does not import code or require certificates from an earlier checkout. Its README distinguishes reconstructed final inputs from earlier receipts that were unavailable when the package was prepared.

## 2. Research preserved

The package contains three proof notes, complete finite certificates, four verification scripts, their original receipts, a README, and a manifest.

### Canonical density exclusion

`canonical_density_exclusion.md` excludes the two retained degree-eleven/degree-ten obstruction pairs as canonical density pairs at represented degree ten, for every nonnegative integer profile, terminal order, and depth. It also excludes either current density individually and covers reflection.

The degree and endpoint constraints leave the sole current-density candidates

- `(n,r,u,ell)=(11,10,11,1)`;
- `(n,r,u,ell)=(11,5,6,1)`.

Their actual first multipliers are positive, while the constructed current densities have the wrong leading sign. The complete pairs also fail degree and initial-moment conditions.

This conclusion concerns the literal canonical densities. It does not identify a density uniquely from finitely many moments.

### Exact moment-polynomial diagnosis

`moment_pair_obstructions.md` and `moment_pair_certificates.json` preserve explicit coefficients and modular Bézout witnesses proving that **both original obstruction moment-polynomial pairs are coprime**. The replay independently reconstructs their rational moments and verifies the identities modulo 65,537, with preserved degrees and invertible denominators.

The separate positive Beta-mixture family distinguishes a zero nominal Euclidean multiplier from a genuine polynomial collision:

- At `theta=9/20`, the nominal multiplier is zero but the remainder is the nonzero constant `9/5720`; the polynomials remain coprime.
- At `theta=72/85`, the independently chosen moment laws share the quadratic `y^2+3/20`, where `y=z-1/2`.

The latter is an exact collision in the larger independent-law class. It does not supply a fixed integer factorial profile or a single polynomial whose consecutive powers produce both laws.

### Finite inverse canonical reachability

`inverse_canonical_reachability.md` proves a finite necessary-and-sufficient membership test for a supplied normalized polynomial-density pair.

It combines exact degree and endpoint constraints with a unique backward coefficient cancellation and a final comparison against the two initial Beta laws. Signed intermediate densities and negative nonzero multipliers are allowed. A zero first normalization is explicitly rejected.

The note also preserves an exact example of two distinct positive densities producing the same represented quadratic, only one of which is canonical. This demonstrates why canonical-density exclusion alone cannot settle finite-moment reachability.

## 3. Precise remaining gap

The recovered package explicitly leaves **uniform actual-factorial-orbit coprimality open**.

An actual counterexample in the binary monomial-linear family would require the two linked polynomials `J_n(z;r,u)` and `J_(n+1)(z;r,u)`, with the same nonnegative integer profile, to share a root. Generic positive-law collisions and failures of a positivity method do not establish that.

Conversely, excluding the two supplied obstruction pairs does not exclude every possible bad reachable pair. The membership theorem starts with an already normalized supplied pair; it does not prove that every actual canonical chain avoids zero mass. Neither a zero nominal pivot nor its sign alone decides coprimality.

The archived status is therefore: **two exact exclusions, exact coprimality certificates, and a finite canonical membership theorem; unrestricted SFC remains unsolved.**

## 4. Verification performed during recovery

Environment: Python 3.12.14, SymPy 1.14.0. The original scripts were read before execution. No additional research computation or expanded mathematical search was run.

| Original checker | Fresh result |
|---|---|
| `verify_density_exclusion.py` | Pass; receipt byte-identical to original |
| `verify_moment_pairs.py` | Pass; receipt byte-identical to original |
| `verify_inverse_reachability.py` | Pass; all five original actual-chain controls and the noninjectivity control; receipt byte-identical |
| `verify_audit_controls.py` | Pass in a disposable copy; all three optimized replays agree and all seven deliberate corruptions are rejected |

The audit harness's new portable receipt is also byte-identical to the archived receipt. All original manifest hashes were checked again afterward.

Fresh verification files are in [replay-final](replay-final/), including [recovery-verification.json](replay-final/recovery-verification.json).

These exact checks validate the retained finite identities and implementation controls. The uniform claims rely on the written proofs, not extrapolation from those checks. All review remains internal, and no external peer review or formal verification is claimed.

## 5. Recovery limits

This is a complete recovery of the identified final 14-file artifact. It does not claim that all intermediate dialogue, tool output, abandoned scratch files, or attachments from the entire long conversation are included. Earlier recovered worktrees and checkpoints are separate supplementary material.

The original ZIP remains the byte-exact source. This report and the fresh receipts supplement it without rewriting its mathematical statements or verification history.

