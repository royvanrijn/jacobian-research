JACOBIAN RESEARCH RECOVERY — 22 NOVEMBER 2026

This recovery package preserves the actual artifacts recovered from Roy van Rijn's two long research conversations. It is a checkpoint for restoration and continuation; no new mathematical result is claimed here.

START HERE

1. original-checkpoints/Jacobian_research_unpublished_checkpoint_2026-11-22.zip
   The complete saved non-SFC continuation: 229 files, including all changed research files, exact evidence and the incremental non_sfc_continuation.bundle. The bundle preserves seven unpublished commits, ending at fde6f2b1dc4d55ee16a04a401474a177bf718f74, on research/non-sfc-continuation. Its prerequisite is public base 41f14391a65112c60fd8f7cafa5b8b45d956b8e1. Unzip it and follow RESTORE.txt in a clean repository clone containing that base. CHECKPOINT.json records scope, claims, tests and unresolved issues.

2. original-checkpoints/sfc_obstruction_audit.zip
   The complete final SFC proof package: 14 files, including three proof notes, exact certificates and four verification scripts. It is self-contained and does not depend on an earlier checkout. Its three mathematical checkers and the audit harness were replayed during recovery; receipts match byte-for-byte, including three optimized replays and seven deliberate-corruption controls.

3. sfc/actual-worktree/
   An additional recovery of 120 earlier uncommitted SFC research files: 34 Markdown documents, 40 Python files, 45 JSON records and one compressed certificate. It includes an exact Git binary patch, a source archive, local replay data and restoration instructions. Its base is 19eb9912fb60142f8b620dac24896931d4ff3e46 and original branch research/stepanov-auxiliary-audit. Every source file was recovered byte-for-byte; patch application was checked in an isolated directory. This older snapshot must not overwrite the newer final package.

4. non-sfc/NON_SFC_RECOVERED_HANDOFF.md and sfc/FINAL_SFC_RECOVERY.md
   These describe exactly what was recovered, what was verified during recovery, and the mathematical scope. Fresh verification records are included beside the reports.

WHAT IS PRESERVED

The non-SFC continuation includes the Jacobian one-generator and restart work, primitive-norm refinements and exact cases, Dixmier work, the all-odd-height stabilization and rational reflection quotient, and the final odd-return-core reduction/Cayley-family exclusion. The general low-height existence problem remains open; read the precise hypotheses and validation limits in the proof files.

The latest SFC package preserves the exclusion of two constructed canonical-density candidates, exact coprimality certificates for both moment-polynomial pairs, and a finite necessary-and-sufficient test for membership in the canonical density chain. Uniform coprimality on the actual factorial orbit remains open. A collision for independently chosen positive laws is explicitly not an SFC counterexample.

RECOVERY LIMITS

This is not a full transcript export. Some intermediate SFC proof files were already unavailable when the final package was prepared. They were not present in the recovered older workspace either. SFC_INTERMEDIATE_RECOVERY_GAP.txt records the known filenames and the statements visible in the shared conversation, without pretending that their missing proofs were recovered. The final SFC archive expressly documents that its inputs were reconstructed and made self-contained after the earlier packet disappeared.

The original two ZIPs are included unchanged. New reports and manifests supplement them. No remote branch or PR was created by this recovery task, and no active source worktree was modified. A failed publication is separate from the preserved local mathematics and Git history.

SOURCE CONVERSATIONS

Non-SFC — Research progress gaps:
https://chatgpt.com/share/6b03149d-5fc0-83ed-9c30-8d8da6a809ef

SFC — Research Priority Recommendations:
https://chatgpt.com/share/6b031511-3ce8-83ed-95da-e89618c18a97

The source-artifact identifiers and exact SHA-256 values are in original-checkpoint-records.json. SHA256SUMS covers every file in this combined recovery package except itself.

CONTINUATION ORDER

Restore the non-SFC Git bundle into a clean clone, keeping its seven commits and exact base. Integrate the final SFC package as a separate change with its explicit open problem. Compare the earlier SFC snapshot against current main before adding files, so older work cannot replace newer sources. Retain the existing navigation/checker-hash failure as a separate known issue rather than silently reporting all repository checks as passing.

For future work, create a downloadable checkpoint before attempting publication: proof sources, code, exact inputs/certificates, replay receipts, Git bundle or binary patch with all new files, and a short handoff distinguishing proved statements, checked examples, failed approaches and remaining gaps. Verify that the checkpoint can be restored. Open the PR after that preservation step succeeds.
