# Non-SFC research: recovered exact checkpoint

Recovery date: 22 November 2026.

**The original proof-and-history checkpoint has been recovered.** This supersedes the earlier partial conversation reconstruction. The complete preserved archive contains the actual proof files, checkers, receipts, continuation scripts, and incremental Git history for all seven unpublished commits.

## Preserved artifact

- Archive: `../original-checkpoints/Jacobian_research_unpublished_checkpoint_2026-11-22.zip`
- Recovered saved version: 9.
- Size: 18,990,936 bytes.
- SHA-256: `2e90cd55f060c7a3ac51af52676451f4282e401fbe1ebb7b51e803c231d48ab6`.
- Contents: 229 files: 118 research files, 74 verification/review files, 34 continuation scripts, plus `non_sfc_continuation.bundle`, `CHECKPOINT.json`, and `RESTORE.txt`.
- Public base: `41f14391a65112c60fd8f7cafa5b8b45d956b8e1`.
- Saved head: `fde6f2b1dc4d55ee16a04a401474a177bf718f74`.
- Saved branch: `research/non-sfc-continuation`.

The original ZIP remains unchanged. Its research tree preserves every changed file since the recorded public base; the incremental Git bundle requires that base. No `research/factorial/` files occur in this packet.

Source conversation: https://chatgpt.com/share/6b03149d-5fc0-83ed-9c30-8d8da6a809ef . The other supplied share is the separate SFC stream.

## Recovery verification completed

1. The original archive SHA-256 matches. All ZIP CRC checks passed. No absolute paths, parent-directory traversals, or symlink entries were found.
2. `git bundle verify` passed in an isolated repository containing the prerequisite commit. `git bundle list-heads` confirms the saved branch and head.
3. The bundle pack checksum passed. All seven embedded commit objects were independently hashed; their exact parent chain from the public base to the saved head agrees with `CHECKPOINT.json`.
4. The latest odd-return proof matches its embedded Git blob exactly: `e024f62130ac05e59a574c7a5dd4b66e942c155e`, SHA-256 `219923e50bb7a1274c2be9b022bc642822b5b43aae9e8540c49092511953827a`.
5. The odd-return checker was inspected and replayed successfully in 3.61 seconds. All five source pins matched. Its verification payload and packet pins match the original retained receipt. It reported 44 rational-divisor cases, 91 integer roots, zero admissible candidates in the stated domain, six polynomial-pair controls, and ten negative controls.

These verify preservation, commit provenance, and that exact replay. They are not a fresh mathematical audit of every theorem, formal verification, external review, or a priority claim.

### Precise restoration-test limit

A complete isolated Git import was **not** finished. The available base clone was partial. Seven missing public-base delta blobs were fetched and hash-verified; the last, `research/MATH_STATUS.json` (blob `5c7b7c5541444d064b7f08065ad5403ea9065c87`), was too large for the connected retrieval route. This is a missing public-base dependency in this execution environment, not a missing unpublished proof or commit from the checkpoint. Use a complete clone containing the recorded base for restoration. Do not describe the full checkout as tested end to end.

Completed evidence and the exact checker replay are retained under `recovery-verification/`.

## Exact seven-commit history

| Commit | Subject |
|---|---|
| `a372de59e0cb812dce9b725a0631b2061ff28b8d` | Extend non-SFC research with mixed-field counts and cubic Engel boundary |
| `849808146ea090517da4965d1a1380c1cbe7a5ee` | Classify orbit spectra and sharpen cubic inverse and norm-count bounds |
| `ef6bd702c91101150e82d61d5665ee7b071ef986` | Classify primitive minus19 norms and non-SFC structural families |
| `51278fabdd736fa677e1ce049974282d1cf5d118` | Close minus43 sumset and extend non-SFC rigidity classifications |
| `81e60f0593c2d9ff7d7f8d406585e7f3be820c60` | Classify infinite rational endpoint fibres and audit proof dependencies |
| `d4de18afd754b69b9fdc206aba765c21f90d147d` | Prove rational reflection quotient and sharp odd-height stabilization |
| `fde6f2b1dc4d55ee16a04a401474a177bf718f74` | research: reduce no-direction pairs to odd-return cores |

The first commit has the public base as its sole parent; each following commit has the preceding row as its sole parent. This was checked directly against the embedded commit objects.

## Latest result and exact boundary

Latest proof:

`research/foundations/extended-geometry/ODD_RETURN_CORE_AND_CAYLEY_OBSTRUCTION.md`

The same directory contains `verify_odd_return_cores.py`, `odd_return_cores_source_ledger.json`, and `odd_return_cores_verification.json`.

The written proof supplies same-height descent to a polynomial pair with literal return `z -> -z`, the polynomial-or-trivial inner-map dichotomy, restrictions at infinity, a height-one rational-residue criterion, and exclusion of the entire family

\[
U(z)=\frac{z}{(1-\lambda z^2)^m},\qquad \lambda\ne0,\quad m\ge1,
\]

at every positive odd height. The last exclusion uses the root-of-unity trace `2(m-1)/m` and an exact reciprocal-exponent cap.

For a single normalized endpoint pole pair at height one, the Cayley criterion requires a monic reciprocal divisor `A(r)` of `r^n+1`, with `A(-1) != 0`, degree `2s`, and

\[
m\ge s,\qquad [r^m](r+1)^{2m-2s}A(r)=0,\qquad m\ge3(n-1).
\]

The mathematical criterion allows divisors over the chosen characteristic-zero field. The computational diagnostic covers **only** rational-coefficient divisors for `n = 12, 15, 18, 20, 24, 30`: exactly 44 divisors, with every integer pole order tested via exact polynomial factorization.

**Still open:** general existence of nontrivial odd-return cores, the unrestricted transient branch, and the general residue/coefficient obstruction. No admissible transient counterexample was obtained. The diagnostic does not cover arbitrary exponents, nonrational divisors, several pole pairs, or other heights. Cancellation in `U'` means one endpoint pole pair need not be one coefficient-root pair.

## Earlier work and validation retained

The archive also retains cubic Engel/Jacobian results, mixed-field norm counts, exact -19 and -43 packets, refined Heegner bounds, operator/string work, Davenport–Zannier fibres, global cyclotomic and elementary exponent classifications, the rational reflection quotient/extractor, finite-fibre bounds, and odd-height stabilization/atlas. `CHECKPOINT.json`, the individual proofs, and retained receipts preserve their precise scopes.

The arbitrary-number-field classifier remains a proved terminating procedure rather than a fully implemented end-to-end classifier. The packet says an earlier lost draft had been reconstructed and rechecked, without asserting byte-identity with that older draft. The seven commits preserved here are now exact.

Retained scoped validation reports `PASS_WITH_UNCHANGED_EXCLUDED_SFC_BASELINE`. Normal navigation remained blocked by the existing checker mismatch `FACTORIAL-UNIFORM-BOUNDED-QUARTIC-CUSP-EXCLUSION`; the archive records the unchanged excluded SFC and earlier graph material. Recovery did not rerun or repair the complete repository validation suite.

The archive states no push or PR had been completed when saved. Prior conversation retrieval reports missing shell push credentials. No successful PR URL was recovered in this task.

## Restore and continue

Use a complete clone containing public base `41f14391a65112c60fd8f7cafa5b8b45d956b8e1`. Extract the ZIP, then follow its preserved `RESTORE.txt` from inside that clone:

```sh
git bundle verify /absolute/path/non_sfc_continuation.bundle
git fetch /absolute/path/non_sfc_continuation.bundle research/non-sfc-continuation:research/non-sfc-restored
git switch research/non-sfc-restored
```

Expected head: `fde6f2b1dc4d55ee16a04a401474a177bf718f74`. Review the seven-commit diff against the recorded base before resuming the PR. All changed research files also remain directly accessible in the ZIP, independently of Git import.

The original workspace `/workspace/scratch/ed843fc82206/jacobian-research` is no longer required to recover this checkpoint.
